import gspread
from oauth2client.service_account import ServiceAccountCredentials
import operator
import time

# use creds to create a client to interact with the Google Drive API
scope = ['https://spreadsheets.google.com/feeds','https://www.googleapis.com/auth/drive']
creds = ServiceAccountCredentials.from_json_keyfile_name('Team_Analytics.json', scope)
client = gspread.authorize(creds)

# Find a workbook by name and open the first sheet
# Make sure you use the right name here.
ALCentral = client.open("AL Central Division Team Analytics")
ALEast = client.open("AL East Division Team Analytics")
ALWest = client.open("AL West Division Team Analytics")
NLCentral = client.open("NL Central Division Team Analytics")
NLEast = client.open("NL East Division Team Analytics")
NLWest = client.open("NL West Division Team Analytics")

#AL CENTRAL TEAMS

MLBChicagoWhiteSoxList = ALCentral.worksheet("Chicago White Sox").get_all_values()
MLBChicagoWhiteSox = MLBChicagoWhiteSoxList[2]
CWSSuperRL = MLBChicagoWhiteSox[5]
CWSRL = MLBChicagoWhiteSox[7]
CWSML = MLBChicagoWhiteSox[9]
CWSOU = MLBChicagoWhiteSox[11]
CWSSoloOU = MLBChicagoWhiteSox[13]
CWSFirstInning = MLBChicagoWhiteSox[16]
CWSHalftime = MLBChicagoWhiteSox[19]
CWSHalftimeOU = MLBChicagoWhiteSox[22]


MLBClevelandIndiansList = ALCentral.worksheet("Cleveland Indians").get_all_values()
MLBClevelandIndians = MLBClevelandIndiansList[2]
CLESuperRL = MLBClevelandIndians[5]
CLERL = MLBClevelandIndians[7]
CLEML = MLBClevelandIndians[9]
CLEOU = MLBClevelandIndians[11]
CLESoloOU = MLBClevelandIndians[13]
CLEFirstInning = MLBClevelandIndians[16]
CLEHalftime = MLBClevelandIndians[19]
CLEHalftimeOU = MLBClevelandIndians[22]


MLBDetroitTigersList = ALCentral.worksheet("Detroit Tigers").get_all_values()
MLBDetroitTigers = MLBDetroitTigersList[2]
DETSuperRL = MLBDetroitTigers[5]
DETRL = MLBDetroitTigers[7]
DETML = MLBDetroitTigers[9]
DETOU = MLBDetroitTigers[11]
DETSoloOU = MLBDetroitTigers[13]
DETFirstInning = MLBDetroitTigers[16]
DETHalftime = MLBDetroitTigers[19]
DETHalftimeOU = MLBDetroitTigers[22]

MLBKansasCityRoyalsList = ALCentral.worksheet("Kansas City Royals").get_all_values()
MLBKansasCityRoyals = MLBKansasCityRoyalsList[2]
KANSuperRL = MLBKansasCityRoyals[5]
KANRL = MLBKansasCityRoyals[7]
KANML = MLBKansasCityRoyals[9]
KANOU = MLBKansasCityRoyals[11]
KANSoloOU = MLBKansasCityRoyals[13]
KANFirstInning = MLBKansasCityRoyals[16]
KANHalftime = MLBKansasCityRoyals[19]
KANHalftimeOU = MLBKansasCityRoyals[22]

MLBMinnesotaTwinsList = ALCentral.worksheet("Minnesota Twins").get_all_values()
MLBMinnesotaTwins = MLBMinnesotaTwinsList[2]
MINSuperRL = MLBMinnesotaTwins[5]
MINRL = MLBMinnesotaTwins[7]
MINML = MLBMinnesotaTwins[9]
MINOU = MLBMinnesotaTwins[11]
MINSoloOU = MLBMinnesotaTwins[13]
MINFirstInning = MLBMinnesotaTwins[16]
MINHalftime = MLBMinnesotaTwins[19]
MINHalftimeOU = MLBMinnesotaTwins[22]

# #AL East Teams

MLBBaltimoreOriolesList = ALEast.worksheet("Baltimore Orioles").get_all_values()
MLBBaltimoreOrioles = MLBBaltimoreOriolesList[2]
BALSuperRL = MLBBaltimoreOrioles[5]
BALRL = MLBBaltimoreOrioles[7]
BALML = MLBBaltimoreOrioles[9]
BALOU = MLBBaltimoreOrioles[11]
BALSoloOU = MLBBaltimoreOrioles[13]
BALFirstInning = MLBBaltimoreOrioles[16]
BALHalftime = MLBBaltimoreOrioles[19]
BALHalftimeOU = MLBBaltimoreOrioles[22]

MLBBostonRedSoxList = ALEast.worksheet("Boston Red Sox").get_all_values()
MLBBostonRedSox = MLBBostonRedSoxList[2]
MLBBOSSuperRL = MLBBostonRedSox[5]
MLBBOSRL = MLBBostonRedSox[7]
MLBBOSML = MLBBostonRedSox[9]
MLBBOSOU = MLBBostonRedSox[11]
MLBBOSSoloOU = MLBBostonRedSox[13]
MLBBOSFirstInning = MLBBostonRedSox[16]
MLBBOSHalftime = MLBBostonRedSox[19]
MLBBOSHalftimeOU = MLBBostonRedSox[22]

MLBNewYorkYankeesList = ALEast.worksheet("New York Yankees").get_all_values()
MLBNewYorkYankees = MLBNewYorkYankeesList[2]
NYYSuperRL = MLBNewYorkYankees[5]
NYYRL = MLBNewYorkYankees[7]
NYYML = MLBNewYorkYankees[9]
NYYOU = MLBNewYorkYankees[11]
NYYSoloOU = MLBNewYorkYankees[13]
NYYFirstInning = MLBNewYorkYankees[16]
NYYHalftime = MLBNewYorkYankees[19]
NYYHalftimeOU = MLBNewYorkYankees[22]

MLBTorontoBlueJaysList = ALEast.worksheet("Toronto Blue Jays").get_all_values()
MLBTorontoBlueJays = MLBTorontoBlueJaysList[2]
MLBTORSuperRL = MLBTorontoBlueJays[5]
MLBTORRL = MLBTorontoBlueJays[7]
MLBTORML = MLBTorontoBlueJays[9]
MLBTOROU = MLBTorontoBlueJays[11]
MLBTORSoloOU = MLBTorontoBlueJays[13]
MLBTORFirstInning = MLBTorontoBlueJays[16]
MLBTORHalftime = MLBTorontoBlueJays[19]
MLBTORHalftimeOU = MLBTorontoBlueJays[22]

MLBTampaBayRaysList = ALEast.worksheet("Tampa Bay Rays").get_all_values()
MLBTampaBayRays = MLBTampaBayRaysList[2]
TBSuperRL = MLBTampaBayRays[5]
TBRL = MLBTampaBayRays[7]
TBML = MLBTampaBayRays[9]
TBOU = MLBTampaBayRays[11]
TBSoloOU = MLBTampaBayRays[13]
TBFirstInning = MLBTampaBayRays[16]
TBHalftime = MLBTampaBayRays[19]
TBHalftimeOU = MLBTampaBayRays[22]

# # AL West Teams

MLBLosAngelesAngelsList = ALWest.worksheet("Los Angeles Angels").get_all_values()
MLBLosAngelesAngels = MLBLosAngelesAngelsList[2]
LAASuperRL = MLBLosAngelesAngels[5]
LAARL = MLBLosAngelesAngels[7]
LAAML = MLBLosAngelesAngels[9]
LAAOU = MLBLosAngelesAngels[11]
LAASoloOU = MLBLosAngelesAngels[13]
LAAFirstInning = MLBLosAngelesAngels[16]
LAAHalftime = MLBLosAngelesAngels[19]
LAAHalftimeOU = MLBLosAngelesAngels[22]

MLBOaklandAthleticsList = ALWest.worksheet("Oakland Athletics").get_all_values()
MLBOaklandAthletics = MLBOaklandAthleticsList[2]
OAKSuperRL = MLBOaklandAthletics[5]
OAKRL = MLBOaklandAthletics[7]
OAKML = MLBOaklandAthletics[9]
OAKOU = MLBOaklandAthletics[11]
OAKSoloOU = MLBOaklandAthletics[13]
OAKFirstInning = MLBOaklandAthletics[16]
OAKHalftime = MLBOaklandAthletics[19]
OAKHalftimeOU = MLBOaklandAthletics[22]

MLBSeattleMarinersList = ALWest.worksheet("Seattle Mariners").get_all_values()
MLBSeattleMariners = MLBSeattleMarinersList[2]
SEASuperRL = MLBSeattleMariners[5]
SEARL = MLBSeattleMariners[7]
SEAML = MLBSeattleMariners[9]
SEAOU = MLBSeattleMariners[11]
SEASoloOU = MLBSeattleMariners[13]
SEAFirstInning = MLBSeattleMariners[16]
SEAHalftime = MLBSeattleMariners[19]
SEAHalftimeOU = MLBSeattleMariners[22]

MLBTexasRangersList = ALWest.worksheet("Texas Rangers").get_all_values()
MLBTexasRangers = MLBTexasRangersList[2]
TEXSuperRL = MLBTexasRangers[5]
TEXRL = MLBTexasRangers[7]
TEXML = MLBTexasRangers[9]
TEXOU = MLBTexasRangers[11]
TEXSoloOU = MLBTexasRangers[13]
TEXFirstInning = MLBTexasRangers[16]
TEXHalftime = MLBTexasRangers[19]
TEXHalftimeOU = MLBTexasRangers[22]

MLBHoustonAstrosList = ALWest.worksheet("Houston Astros").get_all_values()
MLBHoustonAstros = MLBHoustonAstrosList[2]
MLBHOUSuperRL = MLBHoustonAstros[5]
MLBHOURL = MLBHoustonAstros[7]
MLBHOUML = MLBHoustonAstros[9]
MLBHOUOU = MLBHoustonAstros[11]
MLBHOUSoloOU = MLBHoustonAstros[13]
MLBHOUFirstInning = MLBHoustonAstros[16]
MLBHOUHalftime = MLBHoustonAstros[19]
MLBHOUHalftimeOU = MLBHoustonAstros[22]

# #NL Central Teams

MLBMilwaukeeBrewersList = NLCentral.worksheet("Milwaukee Brewers").get_all_values()
MLBMilwaukeeBrewers = MLBMilwaukeeBrewersList[2]
MILSuperRL = MLBMilwaukeeBrewers[5]
MILRL = MLBMilwaukeeBrewers[7]
MILML = MLBMilwaukeeBrewers[9]
MILOU = MLBMilwaukeeBrewers[11]
MILSoloOU = MLBMilwaukeeBrewers[13]
MILFirstInning = MLBMilwaukeeBrewers[16]
MILHalftime = MLBMilwaukeeBrewers[19]
MILHalftimeOU = MLBMilwaukeeBrewers[22]

MLBChicagoCubsList = NLCentral.worksheet("Chicago Cubs").get_all_values()
MLBChicagoCubs = MLBChicagoCubsList[2]
CHCSuperRL = MLBChicagoCubs[5]
CHCRL = MLBChicagoCubs[7]
CHCML = MLBChicagoCubs[9]
CHCOU = MLBChicagoCubs[11]
CHCSoloOU = MLBChicagoCubs[13]
CHCFirstInning = MLBChicagoCubs[16]
CHCHalftime = MLBChicagoCubs[19]
CHCHalftimeOU = MLBChicagoCubs[22]

MLBCincinnatiRedsList = NLCentral.worksheet("Cincinnati Reds").get_all_values()
MLBCincinnatiReds = MLBCincinnatiRedsList[2]
CINSuperRL = MLBCincinnatiReds[5]
CINRL = MLBCincinnatiReds[7]
CINML = MLBCincinnatiReds[9]
CINOU = MLBCincinnatiReds[11]
CINSoloOU = MLBCincinnatiReds[13]
CINFirstInning = MLBCincinnatiReds[16]
CINHalftime = MLBCincinnatiReds[19]
CINHalftimeOU = MLBCincinnatiReds[22]

MLBPittsburghPiratesList = NLCentral.worksheet("Pittsburgh Pirates").get_all_values()
MLBPittsburghPirates = MLBPittsburghPiratesList[2]
PITSuperRL = MLBPittsburghPirates[5]
PITRL = MLBPittsburghPirates[7]
PITML = MLBPittsburghPirates[9]
PITOU = MLBPittsburghPirates[11]
PITSoloOU = MLBPittsburghPirates[13]
PITFirstInning = MLBPittsburghPirates[16]
PITHalftime = MLBPittsburghPirates[19]
PITHalftimeOU = MLBPittsburghPirates[22]

MLBStLouisCardinalsList = NLCentral.worksheet("St. Louis Cardinals").get_all_values()
MLBStLouisCardinals = MLBStLouisCardinalsList[2]
STLSuperRL = MLBStLouisCardinals[5]
STLRL = MLBStLouisCardinals[7]
STLML = MLBStLouisCardinals[9]
STLOU = MLBStLouisCardinals[11]
STLSoloOU = MLBStLouisCardinals[13]
STLFirstInning = MLBStLouisCardinals[16]
STLHalftime = MLBStLouisCardinals[19]
STLHalftimeOU = MLBStLouisCardinals[22]
#
# # NL East Teams

MLBAtlantaBravesList = NLEast.worksheet("Atlanta Braves").get_all_values()
MLBAtlantaBraves = MLBAtlantaBravesList[2]
ATLSuperRL = MLBAtlantaBraves[5]
ATLRL = MLBAtlantaBraves[7]
ATLML = MLBAtlantaBraves[9]
ATLOU = MLBAtlantaBraves[11]
ATLSoloOU = MLBAtlantaBraves[13]
ATLFirstInning = MLBAtlantaBraves[16]
ATLHalftime = MLBAtlantaBraves[19]
ATLHalftimeOU = MLBAtlantaBraves[22]

MLBWashingtonNationalsList = NLEast.worksheet("Washington Nationals").get_all_values()
MLBWashingtonNationals = MLBWashingtonNationalsList[2]
WASSuperRL = MLBWashingtonNationals[5]
WASRL = MLBWashingtonNationals[7]
WASML = MLBWashingtonNationals[9]
WASOU = MLBWashingtonNationals[11]
WASSoloOU = MLBWashingtonNationals[13]
WASFirstInning = MLBWashingtonNationals[16]
WASHalftime = MLBWashingtonNationals[19]
WASHalftimeOU = MLBWashingtonNationals[22]

MLBNewYorkMetsList = NLEast.worksheet("New York Mets").get_all_values()
MLBNewYorkMets = MLBNewYorkMetsList[2]
NYMSuperRL = MLBNewYorkMets[5]
NYMRL = MLBNewYorkMets[7]
NYMML = MLBNewYorkMets[9]
NYMOU = MLBNewYorkMets[11]
NYMSoloOU = MLBNewYorkMets[13]
NYMFirstInning = MLBNewYorkMets[16]
NYMHalftime = MLBNewYorkMets[19]
NYMHalftimeOU = MLBNewYorkMets[22]

MLBPhiladelphiaPhilliesList = NLEast.worksheet("Philadelphia Phillies").get_all_values()
MLBPhiladelphiaPhillies = MLBPhiladelphiaPhilliesList[2]
MLBPHISuperRL = MLBPhiladelphiaPhillies[5]
MLBPHIRL = MLBPhiladelphiaPhillies[7]
MLBPHIML = MLBPhiladelphiaPhillies[9]
MLBPHIOU = MLBPhiladelphiaPhillies[11]
MLBPHISoloOU = MLBPhiladelphiaPhillies[13]
MLBPHIFirstInning = MLBPhiladelphiaPhillies[16]
MLBPHIHalftime = MLBPhiladelphiaPhillies[19]
MLBPHIHalftimeOU = MLBPhiladelphiaPhillies[22]

MLBMiamiMarlinsList = NLEast.worksheet("Miami Marlins").get_all_values()
MLBMiamiMarlins = MLBMiamiMarlinsList[2]
MIASuperRL = MLBMiamiMarlins[5]
MIARL = MLBMiamiMarlins[7]
MIAML = MLBMiamiMarlins[9]
MIAOU = MLBMiamiMarlins[11]
MIASoloOU = MLBMiamiMarlins[13]
MIAFirstInning = MLBMiamiMarlins[16]
MIAHalftime = MLBMiamiMarlins[19]
MIAHalftimeOU = MLBMiamiMarlins[22]

# #NL West Teams

MLBLosAngelesDodgersList = NLWest.worksheet("Los Angeles Dodgers").get_all_values()
MLBLosAngelesDodgers = MLBLosAngelesDodgersList[2]
LADSuperRL = MLBLosAngelesDodgers[5]
LADRL = MLBLosAngelesDodgers[7]
LADML = MLBLosAngelesDodgers[9]
LADOU = MLBLosAngelesDodgers[11]
LADSoloOU = MLBLosAngelesDodgers[13]
LADFirstInning = MLBLosAngelesDodgers[16]
LADHalftime = MLBLosAngelesDodgers[19]
LADHalftimeOU = MLBLosAngelesDodgers[22]

MLBSanDiegoPadresList = NLWest.worksheet("San Diego Padres").get_all_values()
MLBSanDiegoPadres = MLBSanDiegoPadresList[2]
SDSuperRL = MLBSanDiegoPadres[5]
SDRL = MLBSanDiegoPadres[7]
SDML = MLBSanDiegoPadres[9]
SDOU = MLBSanDiegoPadres[11]
SDSoloOU = MLBSanDiegoPadres[13]
SDFirstInning = MLBSanDiegoPadres[16]
SDHalftime = MLBSanDiegoPadres[19]
SDHalftimeOU = MLBSanDiegoPadres[22]

MLBSanFranciscoGiantsList = NLWest.worksheet("San Francisco Giants").get_all_values()
MLBSanFranciscoGiants = MLBSanFranciscoGiantsList[2]
SFSuperRL = MLBSanFranciscoGiants[5]
SFRL = MLBSanFranciscoGiants[7]
SFML = MLBSanFranciscoGiants[9]
SFOU = MLBSanFranciscoGiants[11]
SFSoloOU = MLBSanFranciscoGiants[13]
SFFirstInning = MLBSanFranciscoGiants[16]
SFHalftime = MLBSanFranciscoGiants[19]
SFHalftimeOU = MLBSanFranciscoGiants[22]

MLBColoradoRockiesList = NLWest.worksheet("Colorado Rockies").get_all_values()
MLBColoradoRockies = MLBColoradoRockiesList[2]
COLSuperRL = MLBColoradoRockies[5]
COLRL = MLBColoradoRockies[7]
COLML = MLBColoradoRockies[9]
COLOU = MLBColoradoRockies[11]
COLSoloOU = MLBColoradoRockies[13]
COLFirstInning = MLBColoradoRockies[16]
COLHalftime = MLBColoradoRockies[19]
COLHalftimeOU = MLBColoradoRockies[22]

MLBArizonaDiamondbacksList = NLWest.worksheet("Arizona Diamondbacks").get_all_values()
MLBArizonaDiamondbacks = MLBArizonaDiamondbacksList[2]
ARISuperRL = MLBArizonaDiamondbacks[5]
ARIRL = MLBArizonaDiamondbacks[7]
ARIML = MLBArizonaDiamondbacks[9]
ARIOU = MLBArizonaDiamondbacks[11]
ARISoloOU = MLBArizonaDiamondbacks[13]
ARIFirstInning = MLBArizonaDiamondbacks[16]
ARIHalftime = MLBArizonaDiamondbacks[19]
ARIHalftimeOU = MLBArizonaDiamondbacks[22]
