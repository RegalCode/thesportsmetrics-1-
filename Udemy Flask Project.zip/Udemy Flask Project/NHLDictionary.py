import NHL
import operator

#Atlantic Division Teams

BOSDict = {
    'NHLBOSSuperRL' : NHL.BostonBruinsSuperRL,
    'NHLBOSRL' : NHL.BostonBruinsRL,
    'NHLBOSML' : NHL.BostonBruinsML,
    'NHLBOSOU' : NHL.BostonBruinsOU,
    'NHLBOSSoloOU' : NHL.BostonBruinsSoloOU,
    'NHLBOS1Q' : NHL.BostonBruins1Q,
    'NHLBOS1QOU' : NHL.BostonBruins1QOU,
    'NHLBOS2Q' : NHL.BostonBruins2Q,
    'NHLBOS2QOU' : NHL.BostonBruins2QOU,
    'NHLBOS3Q' : NHL.BostonBruins3Q,
    'NHLBOS3QOU' : NHL.BostonBruins3QOU,
}

TBLDict = {
    'NHLTBLSuperRL' : NHL.TampaBayLightningSuperRL,
    'NHLTBLRL' : NHL.TampaBayLightningRL,
    'NHLTBLML' : NHL.TampaBayLightningML,
    'NHLTBLOU' : NHL.TampaBayLightningOU,
    'NHLTBLSoloOU' : NHL.TampaBayLightningSoloOU,
    'NHLTBL1Q' : NHL.TampaBayLightning1Q,
    'NHLTBL1QOU' : NHL.TampaBayLightning1QOU,
    'NHLTBL2Q' : NHL.TampaBayLightning2Q,
    'NHLTBL2QOU' : NHL.TampaBayLightning2QOU,
    'NHLTBL3Q' : NHL.TampaBayLightning3Q,
    'NHLTBL3QOU' : NHL.TampaBayLightning3QOU,
}

TORDict = {
    'NHLTORSuperRL' : NHL.TorontoMapleLeafsSuperRL,
    'NHLTORRL' : NHL.TorontoMapleLeafsRL,
    'NHLTORML' : NHL.TorontoMapleLeafsML,
    'NHLTOROU' : NHL.TorontoMapleLeafsOU,
    'NHLTORSoloOU' : NHL.TorontoMapleLeafsSoloOU,
    'NHLTOR1Q' : NHL.TorontoMapleLeafs1Q,
    'NHLTOR1QOU' : NHL.TorontoMapleLeafs1QOU,
    'NHLTOR2Q' : NHL.TorontoMapleLeafs2Q,
    'NHLTOR2QOU' : NHL.TorontoMapleLeafs2QOU,
    'NHLTOR3Q' : NHL.TorontoMapleLeafs3Q,
    'NHLTOR3QOU' : NHL.TorontoMapleLeafs3QOU,
}

FLADict = {
    'NHLFLASuperRL' : NHL.FloridaPanthersSuperRL,
    'NHLFLARL' : NHL.FloridaPanthersRL,
    'NHLFLAML' : NHL.FloridaPanthersML,
    'NHLFLAOU' : NHL.FloridaPanthersOU,
    'NHLFLASoloOU' : NHL.FloridaPanthersSoloOU,
    'NHLFLA1Q' : NHL.FloridaPanthers1Q,
    'NHLFLA1QOU' : NHL.FloridaPanthers1QOU,
    'NHLFLA2Q' : NHL.FloridaPanthers2Q,
    'NHLFLA2QOU' : NHL.FloridaPanthers2QOU,
    'NHLFLA3Q' : NHL.FloridaPanthers3Q,
    'NHLFLA3QOU' : NHL.FloridaPanthers3QOU,
}

MTLDict = {
    'NHLMTLSuperRL' : NHL.MontrealCanadiansSuperRL,
    'NHLMTLRL' : NHL.MontrealCanadiansRL,
    'NHLMTLML' : NHL.MontrealCanadiansML,
    'NHLMTLOU' : NHL.MontrealCanadiansOU,
    'NHLMTLSoloOU' : NHL.MontrealCanadiansSoloOU,
    'NHLMTL1Q' : NHL.MontrealCanadians1Q,
    'NHLMTL1QOU' : NHL.MontrealCanadians1QOU,
    'NHLMTL2Q' : NHL.MontrealCanadians2Q,
    'NHLMTL2QOU' : NHL.MontrealCanadians2QOU,
    'NHLMTL3Q' : NHL.MontrealCanadians3Q,
    'NHLMTL3QOU' : NHL.MontrealCanadians3QOU,
}

BUFDict = {
    'NHLBUFSuperRL' : NHL.BuffaloSabresSuperRL,
    'NHLBUFRL' : NHL.BuffaloSabresRL,
    'NHLBUFML' : NHL.BuffaloSabresML,
    'NHLBUFOU' : NHL.BuffaloSabresOU,
    'NHLBUFSoloOU' : NHL.BuffaloSabresSoloOU,
    'NHLBUF1Q' : NHL.BuffaloSabres1Q,
    'NHLBUF1QOU' : NHL.BuffaloSabres1QOU,
    'NHLBUF2Q' : NHL.BuffaloSabres2Q,
    'NHLBUF2QOU' : NHL.BuffaloSabres2QOU,
    'NHLBUF3Q' : NHL.BuffaloSabres3Q,
    'NHLBUF3QOU' : NHL.BuffaloSabres3QOU,
}

OTTDict = {
    'NHLOTTSuperRL' : NHL.OttawaSenatorsSuperRL,
    'NHLOTTRL' : NHL.OttawaSenatorsRL,
    'NHLOTTML' : NHL.OttawaSenatorsML,
    'NHLOTTOU' : NHL.OttawaSenatorsOU,
    'NHLOTTSoloOU' : NHL.OttawaSenatorsSoloOU,
    'NHLOTT1Q' : NHL.OttawaSenators1Q,
    'NHLOTT1QOU' : NHL.OttawaSenators1QOU,
    'NHLOTT2Q' : NHL.OttawaSenators2Q,
    'NHLOTT2QOU' : NHL.OttawaSenators2QOU,
    'NHLOTT3Q' : NHL.OttawaSenators3Q,
    'NHLOTT3QOU' : NHL.OttawaSenators3QOU,
}

DETDict = {
    'NHLDETSuperRL' : NHL.DetroitRedWingsSuperRL,
    'NHLDETRL' : NHL.DetroitRedWingsRL,
    'NHLDETML' : NHL.DetroitRedWingsML,
    'NHLDETOU' : NHL.DetroitRedWingsOU,
    'NHLDETSoloOU' : NHL.DetroitRedWingsSoloOU,
    'NHLDET1Q' : NHL.DetroitRedWings1Q,
    'NHLDET1QOU' : NHL.DetroitRedWings1QOU,
    'NHLDET2Q' : NHL.DetroitRedWings2Q,
    'NHLDET2QOU' : NHL.DetroitRedWings2QOU,
    'NHLDET3Q' : NHL.DetroitRedWings3Q,
    'NHLDET3QOU' : NHL.DetroitRedWings3QOU,
}

#Central Division Teams

STLDict = {
    'NHLSTLSuperRL' : NHL.StLouisBluesSuperRL,
    'NHLSTLRL' : NHL.StLouisBluesRL,
    'NHLSTLML' : NHL.StLouisBluesML,
    'NHLSTLOU' : NHL.StLouisBluesOU,
    'NHLSTLSoloOU' : NHL.StLouisBluesSoloOU,
    'NHLSTL1Q' : NHL.StLouisBlues1Q,
    'NHLSTL1QOU' : NHL.StLouisBlues1QOU,
    'NHLSTL2Q' : NHL.StLouisBlues2Q,
    'NHLSTL2QOU' : NHL.StLouisBlues2QOU,
    'NHLSTL3Q' : NHL.StLouisBlues3Q,
    'NHLSTL3QOU' : NHL.StLouisBlues3QOU,
}

COLDict = {
    'NHLCOLSuperRL' : NHL.ColoradoAvalancheSuperRL,
    'NHLCOLRL' : NHL.ColoradoAvalancheRL,
    'NHLCOLML' : NHL.ColoradoAvalancheML,
    'NHLCOLOU' : NHL.ColoradoAvalancheOU,
    'NHLCOLSoloOU' : NHL.ColoradoAvalancheSoloOU,
    'NHLCOL1Q' : NHL.ColoradoAvalanche1Q,
    'NHLCOL1QOU' : NHL.ColoradoAvalanche1QOU,
    'NHLCOL2Q' : NHL.ColoradoAvalanche2Q,
    'NHLCOL2QOU' : NHL.ColoradoAvalanche2QOU,
    'NHLCOL3Q' : NHL.ColoradoAvalanche3Q,
    'NHLCOL3QOU' : NHL.ColoradoAvalanche3QOU,
}

DALDict = {
    'NHLDALSuperRL' : NHL.DallasStarsSuperRL,
    'NHLDALRL' : NHL.DallasStarsRL,
    'NHLDALML' : NHL.DallasStarsML,
    'NHLDALOU' : NHL.DallasStarsOU,
    'NHLDALSoloOU' : NHL.DallasStarsSoloOU,
    'NHLDAL1Q' : NHL.DallasStars1Q,
    'NHLDAL1QOU' : NHL.DallasStars1QOU,
    'NHLDAL2Q' : NHL.DallasStars2Q,
    'NHLDAL2QOU' : NHL.DallasStars2QOU,
    'NHLDAL3Q' : NHL.DallasStars3Q,
    'NHLDAL3QOU' : NHL.DallasStars3QOU,
}


WPGDict = {
    'NHLWPGSuperRL' : NHL.WinnipegJetsSuperRL,
    'NHLWPGRL' : NHL.WinnipegJetsRL,
    'NHLWPGML' : NHL.WinnipegJetsML,
    'NHLWPGOU' : NHL.WinnipegJetsOU,
    'NHLWPGSoloOU' : NHL.WinnipegJetsSoloOU,
    'NHLWPG1Q' : NHL.WinnipegJets1Q,
    'NHLWPG1QOU' : NHL.WinnipegJets1QOU,
    'NHLWPG2Q' : NHL.WinnipegJets2Q,
    'NHLWPG2QOU' : NHL.WinnipegJets2QOU,
    'NHLWPG3Q' : NHL.WinnipegJets3Q,
    'NHLWPG3QOU' : NHL.WinnipegJets3QOU,
}

NSHDict = {
    'NHLNSHSuperRL' : NHL.NashvillePredatorsSuperRL,
    'NHLNSHRL' : NHL.NashvillePredatorsRL,
    'NHLNSHML' : NHL.NashvillePredatorsML,
    'NHLNSHOU' : NHL.NashvillePredatorsOU,
    'NHLNSHSoloOU' : NHL.NashvillePredatorsSoloOU,
    'NHLNSH1Q' : NHL.NashvillePredators1Q,
    'NHLNSH1QOU' : NHL.NashvillePredators1QOU,
    'NHLNSH2Q' : NHL.NashvillePredators2Q,
    'NHLNSH2QOU' : NHL.NashvillePredators2QOU,
    'NHLNSH3Q' : NHL.NashvillePredators3Q,
    'NHLNSH3QOU' : NHL.NashvillePredators3QOU,
}

MINDict = {
    'NHLMINSuperRL' : NHL.MinnesotaWildSuperRL,
    'NHLMINRL' : NHL.MinnesotaWildRL,
    'NHLMINML' : NHL.MinnesotaWildML,
    'NHLMINOU' : NHL.MinnesotaWildOU,
    'NHLMINSoloOU' : NHL.MinnesotaWildSoloOU,
    'NHLMIN1Q' : NHL.MinnesotaWild1Q,
    'NHLMIN1QOU' : NHL.MinnesotaWild1QOU,
    'NHLMIN2Q' : NHL.MinnesotaWild2Q,
    'NHLMIN2QOU' : NHL.MinnesotaWild2QOU,
    'NHLMIN3Q' : NHL.MinnesotaWild3Q,
    'NHLMIN3QOU' : NHL.MinnesotaWild3QOU,
}

CHIDict = {
    'NHLCHISuperRL' : NHL.ChicagoBlackhawksSuperRL,
    'NHLCHIRL' : NHL.ChicagoBlackhawksRL,
    'NHLCHIML' : NHL.ChicagoBlackhawksML,
    'NHLCHIOU' : NHL.ChicagoBlackhawksOU,
    'NHLCHISoloOU' : NHL.ChicagoBlackhawksSoloOU,
    'NHLCHI1Q' : NHL.ChicagoBlackhawks1Q,
    'NHLCHI1QOU' : NHL.ChicagoBlackhawks1QOU,
    'NHLCHI2Q' : NHL.ChicagoBlackhawks2Q,
    'NHLCHI2QOU' : NHL.ChicagoBlackhawks2QOU,
    'NHLCHI3Q' : NHL.ChicagoBlackhawks3Q,
    'NHLCHI3QOU' : NHL.ChicagoBlackhawks3QOU,
}

#Metropolitan Division Teams

WASDict = {
    'NHLWASSuperRL' : NHL.WashingtonCapitalsSuperRL,
    'NHLWASRL' : NHL.WashingtonCapitalsRL,
    'NHLWASML' : NHL.WashingtonCapitalsML,
    'NHLWASOU' : NHL.WashingtonCapitalsOU,
    'NHLWASSoloOU' : NHL.WashingtonCapitalsSoloOU,
    'NHLWAS1Q' : NHL.WashingtonCapitals1Q,
    'NHLWAS1QOU' : NHL.WashingtonCapitals1QOU,
    'NHLWAS2Q' : NHL.WashingtonCapitals2Q,
    'NHLWAS2QOU' : NHL.WashingtonCapitals2QOU,
    'NHLWAS3Q' : NHL.WashingtonCapitals3Q,
    'NHLWAS3QOU' : NHL.WashingtonCapitals3QOU,
}

PHIDict = {
    'NHLPHISuperRL' : NHL.PhiladelphiaFlyersSuperRL,
    'NHLPHIRL' : NHL.PhiladelphiaFlyersRL,
    'NHLPHIML' : NHL.PhiladelphiaFlyersML,
    'NHLPHIOU' : NHL.PhiladelphiaFlyersOU,
    'NHLPHISoloOU' : NHL.PhiladelphiaFlyersSoloOU,
    'NHLPHI1Q' : NHL.PhiladelphiaFlyers1Q,
    'NHLPHI1QOU' : NHL.PhiladelphiaFlyers1QOU,
    'NHLPHI2Q' : NHL.PhiladelphiaFlyers2Q,
    'NHLPHI2QOU' : NHL.PhiladelphiaFlyers2QOU,
    'NHLPHI3Q' : NHL.PhiladelphiaFlyers3Q,
    'NHLPHI3QOU' : NHL.PhiladelphiaFlyers3QOU,
}

PITDict = {
    'NHLPITSuperRL' : NHL.PittsburghPenguinsSuperRL,
    'NHLPITRL' : NHL.PittsburghPenguinsRL,
    'NHLPITML' : NHL.PittsburghPenguinsML,
    'NHLPITOU' : NHL.PittsburghPenguinsOU,
    'NHLPITSoloOU' : NHL.PittsburghPenguinsSoloOU,
    'NHLPIT1Q' : NHL.PittsburghPenguins1Q,
    'NHLPIT1QOU' : NHL.PittsburghPenguins1QOU,
    'NHLPIT2Q' : NHL.PittsburghPenguins2Q,
    'NHLPIT2QOU' : NHL.PittsburghPenguins2QOU,
    'NHLPIT3Q' : NHL.PittsburghPenguins3Q,
    'NHLPIT3QOU' : NHL.PittsburghPenguins3QOU,
}

CARDict = {
    'NHLCARSuperRL' : NHL.CarolinaHurricanesSuperRL,
    'NHLCARRL' : NHL.CarolinaHurricanesRL,
    'NHLCARML' : NHL.CarolinaHurricanesML,
    'NHLCAROU' : NHL.CarolinaHurricanesOU,
    'NHLCARSoloOU' : NHL.CarolinaHurricanesSoloOU,
    'NHLCAR1Q' : NHL.CarolinaHurricanes1Q,
    'NHLCAR1QOU' : NHL.CarolinaHurricanes1QOU,
    'NHLCAR2Q' : NHL.CarolinaHurricanes2Q,
    'NHLCAR2QOU' : NHL.CarolinaHurricanes2QOU,
    'NHLCAR3Q' : NHL.CarolinaHurricanes3Q,
    'NHLCAR3QOU' : NHL.CarolinaHurricanes3QOU,
}

CBJDict = {
    'NHLCBJSuperRL' : NHL.ColumbusBlueJacketsSuperRL,
    'NHLCBJRL' : NHL.ColumbusBlueJacketsRL,
    'NHLCBJML' : NHL.ColumbusBlueJacketsML,
    'NHLCBJOU' : NHL.ColumbusBlueJacketsOU,
    'NHLCBJSoloOU' : NHL.ColumbusBlueJacketsSoloOU,
    'NHLCBJ1Q' : NHL.ColumbusBlueJackets1Q,
    'NHLCBJ1QOU' : NHL.ColumbusBlueJackets1QOU,
    'NHLCBJ2Q' : NHL.ColumbusBlueJackets2Q,
    'NHLCBJ2QOU' : NHL.ColumbusBlueJackets2QOU,
    'NHLCBJ3Q' : NHL.ColumbusBlueJackets3Q,
    'NHLCBJ3QOU' : NHL.ColumbusBlueJackets3QOU,
}

NYIDict = {
    'NHLNYISuperRL' : NHL.NewYorkIslandersSuperRL,
    'NHLNYIRL' : NHL.NewYorkIslandersRL,
    'NHLNYIML' : NHL.NewYorkIslandersML,
    'NHLNYIOU' : NHL.NewYorkIslandersOU,
    'NHLNYISoloOU' : NHL.NewYorkIslandersSoloOU,
    'NHLNYI1Q' : NHL.NewYorkIslanders1Q,
    'NHLNYI1QOU' : NHL.NewYorkIslanders1QOU,
    'NHLNYI2Q' : NHL.NewYorkIslanders2Q,
    'NHLNYI2QOU' : NHL.NewYorkIslanders2QOU,
    'NHLNYI3Q' : NHL.NewYorkIslanders3Q,
    'NHLNYI3QOU' : NHL.NewYorkIslanders3QOU,
}

NYRDict = {
    'NHLNYRSuperRL' : NHL.NewYorkRangersSuperRL,
    'NHLNYRRL' : NHL.NewYorkRangersRL,
    'NHLNYRML' : NHL.NewYorkRangersML,
    'NHLNYROU' : NHL.NewYorkRangersOU,
    'NHLNYRSoloOU' : NHL.NewYorkRangersSoloOU,
    'NHLNYR1Q' : NHL.NewYorkRangers1Q,
    'NHLNYR1QOU' : NHL.NewYorkRangers1QOU,
    'NHLNYR2Q' : NHL.NewYorkRangers2Q,
    'NHLNYR2QOU' : NHL.NewYorkRangers2QOU,
    'NHLNYR3Q' : NHL.NewYorkRangers3Q,
    'NHLNYR3QOU' : NHL.NewYorkRangers3QOU,
}

NJDDict = {
    'NHLNJDSuperRL' : NHL.NewJerseyDevilsSuperRL,
    'NHLNJDRL' : NHL.NewJerseyDevilsRL,
    'NHLNJDML' : NHL.NewJerseyDevilsML,
    'NHLNJDOU' : NHL.NewJerseyDevilsOU,
    'NHLNJDSoloOU' : NHL.NewJerseyDevilsSoloOU,
    'NHLNJD1Q' : NHL.NewJerseyDevils1Q,
    'NHLNJD1QOU' : NHL.NewJerseyDevils1QOU,
    'NHLNJD2Q' : NHL.NewJerseyDevils2Q,
    'NHLNJD2QOU' : NHL.NewJerseyDevils2QOU,
    'NHLNJD3Q' : NHL.NewJerseyDevils3Q,
    'NHLNJD3QOU' : NHL.NewJerseyDevils3QOU,
}

#Pacific Division Teams

VGKDict = {
    'NHLVGKSuperRL' : NHL.VegasGoldenKnightsSuperRL,
    'NHLVGKRL' : NHL.VegasGoldenKnightsRL,
    'NHLVGKML' : NHL.VegasGoldenKnightsML,
    'NHLVGKOU' : NHL.VegasGoldenKnightsOU,
    'NHLVGKSoloOU' : NHL.VegasGoldenKnightsSoloOU,
    'NHLVGK1Q' : NHL.VegasGoldenKnights1Q,
    'NHLVGK1QOU' : NHL.VegasGoldenKnights1QOU,
    'NHLVGK2Q' : NHL.VegasGoldenKnights2Q,
    'NHLVGK2QOU' : NHL.VegasGoldenKnights2QOU,
    'NHLVGK3Q' : NHL.VegasGoldenKnights3Q,
    'NHLVGK3QOU' : NHL.VegasGoldenKnights3QOU,
}

EDMDict = {
    'NHLEDMSuperRL' : NHL.EdmontonOilersSuperRL,
    'NHLEDMRL' : NHL.EdmontonOilersRL,
    'NHLEDMML' : NHL.EdmontonOilersML,
    'NHLEDMOU' : NHL.EdmontonOilersOU,
    'NHLEDMSoloOU' : NHL.EdmontonOilersSoloOU,
    'NHLEDM1Q' : NHL.EdmontonOilers1Q,
    'NHLEDM1QOU' : NHL.EdmontonOilers1QOU,
    'NHLEDM2Q' : NHL.EdmontonOilers2Q,
    'NHLEDM2QOU' : NHL.EdmontonOilers2QOU,
    'NHLEDM3Q' : NHL.EdmontonOilers3Q,
    'NHLEDM3QOU' : NHL.EdmontonOilers3QOU,
}

CGYDict = {
    'NHLCGYSuperRL' : NHL.CalgaryFlamesSuperRL,
    'NHLCGYRL' : NHL.CalgaryFlamesRL,
    'NHLCGYML' : NHL.CalgaryFlamesML,
    'NHLCGYOU' : NHL.CalgaryFlamesOU,
    'NHLCGYSoloOU' : NHL.CalgaryFlamesSoloOU,
    'NHLCGY1Q' : NHL.CalgaryFlames1Q,
    'NHLCGY1QOU' : NHL.CalgaryFlames1QOU,
    'NHLCGY2Q' : NHL.CalgaryFlames2Q,
    'NHLCGY2QOU' : NHL.CalgaryFlames2QOU,
    'NHLCGY3Q' : NHL.CalgaryFlames3Q,
    'NHLCGY3QOU' : NHL.CalgaryFlames3QOU,
}

VANDict = {
    'NHLVANSuperRL' : NHL.VancouverCanucksSuperRL,
    'NHLVANRL' : NHL.VancouverCanucksRL,
    'NHLVANML' : NHL.VancouverCanucksML,
    'NHLVANOU' : NHL.VancouverCanucksOU,
    'NHLVANSoloOU' : NHL.VancouverCanucksSoloOU,
    'NHLVAN1Q' : NHL.VancouverCanucks1Q,
    'NHLVAN1QOU' : NHL.VancouverCanucks1QOU,
    'NHLVAN2Q' : NHL.VancouverCanucks2Q,
    'NHLVAN2QOU' : NHL.VancouverCanucks2QOU,
    'NHLVAN3Q' : NHL.VancouverCanucks3Q,
    'NHLVAN3QOU' : NHL.VancouverCanucks3QOU,
}

ARIDict = {
    'NHLARISuperRL' : NHL.ArizonaCoyotesSuperRL,
    'NHLARIRL' : NHL.ArizonaCoyotesRL,
    'NHLARIML' : NHL.ArizonaCoyotesML,
    'NHLARIOU' : NHL.ArizonaCoyotesOU,
    'NHLARISoloOU' : NHL.ArizonaCoyotesSoloOU,
    'NHLARI1Q' : NHL.ArizonaCoyotes1Q,
    'NHLARI1QOU' : NHL.ArizonaCoyotes1QOU,
    'NHLARI2Q' : NHL.ArizonaCoyotes2Q,
    'NHLARI2QOU' : NHL.ArizonaCoyotes2QOU,
    'NHLARI3Q' : NHL.ArizonaCoyotes3Q,
    'NHLARI3QOU' : NHL.ArizonaCoyotes3QOU,
}

ANADict = {
    'NHLANASuperRL' : NHL.AnaheimDucksSuperRL,
    'NHLANARL' : NHL.AnaheimDucksRL,
    'NHLANAML' : NHL.AnaheimDucksML,
    'NHLANAOU' : NHL.AnaheimDucksOU,
    'NHLANASoloOU' : NHL.AnaheimDucksSoloOU,
    'NHLANA1Q' : NHL.AnaheimDucks1Q,
    'NHLANA1QOU' : NHL.AnaheimDucks1QOU,
    'NHLANA2Q' : NHL.AnaheimDucks2Q,
    'NHLANA2QOU' : NHL.AnaheimDucks2QOU,
    'NHLANA3Q' : NHL.AnaheimDucks3Q,
    'NHLANA3QOU' : NHL.AnaheimDucks3QOU,
}

LAKDict = {
    'NHLLAKSuperRL' : NHL.LosAngelesKingsSuperRL,
    'NHLLAKRL' : NHL.LosAngelesKingsRL,
    'NHLLAKML' : NHL.LosAngelesKingsML,
    'NHLLAKOU' : NHL.LosAngelesKingsOU,
    'NHLLAKSoloOU' : NHL.LosAngelesKingsSoloOU,
    'NHLLAK1Q' : NHL.LosAngelesKings1Q,
    'NHLLAK1QOU' : NHL.LosAngelesKings1QOU,
    'NHLLAK2Q' : NHL.LosAngelesKings2Q,
    'NHLLAK2QOU' : NHL.LosAngelesKings2QOU,
    'NHLLAK3Q' : NHL.LosAngelesKings3Q,
    'NHLLAK3QOU' : NHL.LosAngelesKings3QOU,
}

SJSDict = {
    'NHLSJSSuperRL' : NHL.SanJoseSharksSuperRL,
    'NHLSJSRL' : NHL.SanJoseSharksRL,
    'NHLSJSML' : NHL.SanJoseSharksML,
    'NHLSJSOU' : NHL.SanJoseSharksOU,
    'NHLSJSSoloOU' : NHL.SanJoseSharksSoloOU,
    'NHLSJS1Q' : NHL.SanJoseSharks1Q,
    'NHLSJS1QOU' : NHL.SanJoseSharks1QOU,
    'NHLSJS2Q' : NHL.SanJoseSharks2Q,
    'NHLSJS2QOU' : NHL.SanJoseSharks2QOU,
    'NHLSJS3Q' : NHL.SanJoseSharks3Q,
    'NHLSJS3QOU' : NHL.SanJoseSharks3QOU,
}

AtlanticDivisionDict = {**BOSDict, **TBLDict, **TORDict, **FLADict, **MTLDict, **BUFDict, **OTTDict, **DETDict}
CentralDivisionDict = {**STLDict, **COLDict, **DALDict, **WPGDict, **NSHDict, **MINDict, **CHIDict}
MetropolitanDivisionDict = {**WASDict, **PHIDict, **PITDict, **CARDict, **CBJDict, **NYIDict, **NYRDict, **NJDDict}
PacificDivisionDict = {**VGKDict, **EDMDict, **CGYDict, **VANDict, **ARIDict, **ANADict, **LAKDict, **SJSDict}

NHLDict = {**AtlanticDivisionDict, **CentralDivisionDict, **MetropolitanDivisionDict, **PacificDivisionDict}

OrderedNHLDict = sorted(NHLDict.items(), key=operator.itemgetter(1), reverse = True)[:5]
