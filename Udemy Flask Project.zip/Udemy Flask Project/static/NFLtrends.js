//<![CDATA[
// array of possible teams in the same order as they appear in the team selection list
var teamLists = new Array(32)
teamLists["empty"] = ["Select a Stat"];
teamLists["Arizona Cardinals"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under", "1Q ATS", "1Q Over", "1Q Under", "2Q ATS", "2Q Over", "2Q Under", "3Q ATS", "3Q Over", "3Q Under", "4Q ATS", "4Q Over", "4Q Under"];
teamLists["Atlanta Falcons"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under", "1Q ATS", "1Q Over", "1Q Under", "2Q ATS", "2Q Over", "2Q Under", "3Q ATS", "3Q Over", "3Q Under", "4Q ATS", "4Q Over", "4Q Under"];
teamLists["Baltimore Ravens"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under", "1Q ATS", "1Q Over", "1Q Under", "2Q ATS", "2Q Over", "2Q Under", "3Q ATS", "3Q Over", "3Q Under", "4Q ATS", "4Q Over", "4Q Under"];
teamLists["Buffalo Bills"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under", "1Q ATS", "1Q Over", "1Q Under", "2Q ATS", "2Q Over", "2Q Under", "3Q ATS", "3Q Over", "3Q Under", "4Q ATS", "4Q Over", "4Q Under"];
teamLists["Carolina Panthers"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under", "1Q ATS", "1Q Over", "1Q Under", "2Q ATS", "2Q Over", "2Q Under", "3Q ATS", "3Q Over", "3Q Under", "4Q ATS", "4Q Over", "4Q Under"];
teamLists["Cincinnati Bengals"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under", "1Q ATS", "1Q Over", "1Q Under", "2Q ATS", "2Q Over", "2Q Under", "3Q ATS", "3Q Over", "3Q Under", "4Q ATS", "4Q Over", "4Q Under"];
teamLists["Chicago Bears"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under", "1Q ATS", "1Q Over", "1Q Under", "2Q ATS", "2Q Over", "2Q Under", "3Q ATS", "3Q Over", "3Q Under", "4Q ATS", "4Q Over", "4Q Under"];
teamLists["Cleveland Browns"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under", "1Q ATS", "1Q Over", "1Q Under", "2Q ATS", "2Q Over", "2Q Under", "3Q ATS", "3Q Over", "3Q Under", "4Q ATS", "4Q Over", "4Q Under"];
teamLists["Dallas Cowboys"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under", "1Q ATS", "1Q Over", "1Q Under", "2Q ATS", "2Q Over", "2Q Under", "3Q ATS", "3Q Over", "3Q Under", "4Q ATS", "4Q Over", "4Q Under"];
teamLists["Denver Broncos"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under", "1Q ATS", "1Q Over", "1Q Under", "2Q ATS", "2Q Over", "2Q Under", "3Q ATS", "3Q Over", "3Q Under", "4Q ATS", "4Q Over", "4Q Under"];
teamLists["Detroit Lions"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under", "1Q ATS", "1Q Over", "1Q Under", "2Q ATS", "2Q Over", "2Q Under", "3Q ATS", "3Q Over", "3Q Under", "4Q ATS", "4Q Over", "4Q Under"];
teamLists["Green Bay Packers"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under", "1Q ATS", "1Q Over", "1Q Under", "2Q ATS", "2Q Over", "2Q Under", "3Q ATS", "3Q Over", "3Q Under", "4Q ATS", "4Q Over", "4Q Under"];
teamLists["Houston Texans"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under", "1Q ATS", "1Q Over", "1Q Under", "2Q ATS", "2Q Over", "2Q Under", "3Q ATS", "3Q Over", "3Q Under", "4Q ATS", "4Q Over", "4Q Under"];
teamLists["Indianapolis Colts"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under", "1Q ATS", "1Q Over", "1Q Under", "2Q ATS", "2Q Over", "2Q Under", "3Q ATS", "3Q Over", "3Q Under", "4Q ATS", "4Q Over", "4Q Under"];
teamLists["Kansas City Chiefs"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under", "1Q ATS", "1Q Over", "1Q Under", "2Q ATS", "2Q Over", "2Q Under", "3Q ATS", "3Q Over", "3Q Under", "4Q ATS", "4Q Over", "4Q Under"];
teamLists["Los Angeles Chargers"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under", "1Q ATS", "1Q Over", "1Q Under", "2Q ATS", "2Q Over", "2Q Under", "3Q ATS", "3Q Over", "3Q Under", "4Q ATS", "4Q Over", "4Q Under"];
teamLists["Los Angeles Rams"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under", "1Q ATS", "1Q Over", "1Q Under", "2Q ATS", "2Q Over", "2Q Under", "3Q ATS", "3Q Over", "3Q Under", "4Q ATS", "4Q Over", "4Q Under"];
teamLists["Jacksonville Jaguars"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under", "1Q ATS", "1Q Over", "1Q Under", "2Q ATS", "2Q Over", "2Q Under", "3Q ATS", "3Q Over", "3Q Under", "4Q ATS", "4Q Over", "4Q Under"];
teamLists["Miami Dolphins"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under", "1Q ATS", "1Q Over", "1Q Under", "2Q ATS", "2Q Over", "2Q Under", "3Q ATS", "3Q Over", "3Q Under", "4Q ATS", "4Q Over", "4Q Under"];
teamLists["Minnesota Vikings"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under", "1Q ATS", "1Q Over", "1Q Under", "2Q ATS", "2Q Over", "2Q Under", "3Q ATS", "3Q Over", "3Q Under", "4Q ATS", "4Q Over", "4Q Under"];
teamLists["New England Patriots"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under", "1Q ATS", "1Q Over", "1Q Under", "2Q ATS", "2Q Over", "2Q Under", "3Q ATS", "3Q Over", "3Q Under", "4Q ATS", "4Q Over", "4Q Under"];
teamLists["New Orleans Saints"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under", "1Q ATS", "1Q Over", "1Q Under", "2Q ATS", "2Q Over", "2Q Under", "3Q ATS", "3Q Over", "3Q Under", "4Q ATS", "4Q Over", "4Q Under"];
teamLists["New York Giants"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under", "1Q ATS", "1Q Over", "1Q Under", "2Q ATS", "2Q Over", "2Q Under", "3Q ATS", "3Q Over", "3Q Under", "4Q ATS", "4Q Over", "4Q Under"];
teamLists["New York Jets"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under", "1Q ATS", "1Q Over", "1Q Under", "2Q ATS", "2Q Over", "2Q Under", "3Q ATS", "3Q Over", "3Q Under", "4Q ATS", "4Q Over", "4Q Under"];
teamLists["Oakland Raiders"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under", "1Q ATS", "1Q Over", "1Q Under", "2Q ATS", "2Q Over", "2Q Under", "3Q ATS", "3Q Over", "3Q Under", "4Q ATS", "4Q Over", "4Q Under"];
teamLists["Philadelphia Eagles"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under", "1Q ATS", "1Q Over", "1Q Under", "2Q ATS", "2Q Over", "2Q Under", "3Q ATS", "3Q Over", "3Q Under", "4Q ATS", "4Q Over", "4Q Under"];
teamLists["San Francisco 49ers"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under", "1Q ATS", "1Q Over", "1Q Under", "2Q ATS", "2Q Over", "2Q Under", "3Q ATS", "3Q Over", "3Q Under", "4Q ATS", "4Q Over", "4Q Under"];
teamLists["Seattle Seahawks"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under", "1Q ATS", "1Q Over", "1Q Under", "2Q ATS", "2Q Over", "2Q Under", "3Q ATS", "3Q Over", "3Q Under", "4Q ATS", "4Q Over", "4Q Under"];
teamLists["Pittsburgh Steelers"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under", "1Q ATS", "1Q Over", "1Q Under", "2Q ATS", "2Q Over", "2Q Under", "3Q ATS", "3Q Over", "3Q Under", "4Q ATS", "4Q Over", "4Q Under"];
teamLists["Tampa Bay Buccaneers"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under", "1Q ATS", "1Q Over", "1Q Under", "2Q ATS", "2Q Over", "2Q Under", "3Q ATS", "3Q Over", "3Q Under", "4Q ATS", "4Q Over", "4Q Under"];
teamLists["Tennessee Titans"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under", "1Q ATS", "1Q Over", "1Q Under", "2Q ATS", "2Q Over", "2Q Under", "3Q ATS", "3Q Over", "3Q Under", "4Q ATS", "4Q Over", "4Q Under"];
teamLists["Washington Redskins"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under", "1Q ATS", "1Q Over", "1Q Under", "2Q ATS", "2Q Over", "2Q Under", "3Q ATS", "3Q Over", "3Q Under", "4Q ATS", "4Q Over", "4Q Under"];
/* teamChange() is called from the onchange event of a select element.
* param selectObj - the select object which fired the on change event.
*/

function teamChange(selectObj) {
// get the index of the selected option
  index = selectObj.selectedIndex;
// get the value of the selected option
var which = selectObj.options[index].value;
// use the selected option value to retrieve the list of items from the countryLists array
tList = teamLists[which];
// get the country select element via its known id
var tSelect = document.getElementById("stat-change");
// remove the current options from the country select
var len = tSelect.options.length;

while (tSelect.options.length > 0) {
tSelect.remove(0);
}
var newOption;
// create new options
for (var i=0; i<tList.length; i++) {
newOption = document.createElement("option");
newOption.value = tList[i];  // assumes option string and value are the same
newOption.text=tList[i];
// add the new option
try {
tSelect.add(newOption);  // this will fail in DOM browsers but is needed for IE
}
catch (e) {
tSelect.appendChild(newOption);
}
}
}

function statChange(selectObj) {

  var ariCover = document.getElementById("ARICover").innerHTML;
  var ariML = document.getElementById("ARIML").innerHTML;
  var ariO = document.getElementById("ARIO").innerHTML;
  var ariO = ariO.replace(/[',()]/g, "");
  var ariSoloO = document.getElementById("ARISoloO").innerHTML;
  var ariSoloO = ariSoloO.replace(/[',()]/g, "");
  var ariHalftime = document.getElementById("ARIHalftime").innerHTML;
  var ariHalftimeO = document.getElementById("ARIHalftimeO").innerHTML;
  var ariHalftimeO = ariHalftimeO.replace(/[',()]/g, "");
  var ari1Q = document.getElementById("ARI1Q").innerHTML;
  var ari1QO = document.getElementById("ARI1QOver").innerHTML;
  var ari1QO = ari1QO.replace(/[',()]/g, "");
  var ari2Q = document.getElementById("ARI2Q").innerHTML;
  var ari2QO = document.getElementById("ARI2QOver").innerHTML;
  var ari2QO = ari2Q.replace(/[',()]/g, "");
  var ari3Q = document.getElementById("ARI3Q").innerHTML;
  var ari3QO = document.getElementById("ARI3QOver").innerHTML;
  var ari3QO = ari3QO.replace(/[',()]/g, "");
  var ari4Q = document.getElementById("ARI4Q").innerHTML;
  var ari4QO = document.getElementById("ARI4QOver").innerHTML;
  var ari4QO = ari4QO.replace(/[',()]/g, "");

  var atlCover = document.getElementById("ATLCover").innerHTML;
  var atlML = document.getElementById("ATLML").innerHTML;
  var atlO = document.getElementById("ATLO").innerHTML;
  var atlO = atlO.replace(/[',()]/g, "");
  var atlSoloO = document.getElementById("ATLSoloO").innerHTML;
  var atlSoloO = atlSoloO.replace(/[',()]/g, "");
  var atlHalftime = document.getElementById("ATLHalftime").innerHTML;
  var atlHalftimeO = document.getElementById("ATLHalftimeO").innerHTML;
  var atlHalftimeO = atlHalftimeO.replace(/[',()]/g, "");
  var atl1Q = document.getElementById("ATL1Q").innerHTML;
  var atl1QO = document.getElementById("ATL1QOver").innerHTML;
  var atl1QO = atl1QO.replace(/[',()]/g, "");
  var atl2Q = document.getElementById("ATL2Q").innerHTML;
  var atl2QO = document.getElementById("ATL2QOver").innerHTML;
  var atl2QO = atl2Q.replace(/[',()]/g, "");
  var atl3Q = document.getElementById("ATL3Q").innerHTML;
  var atl3QO = document.getElementById("ATL3QOver").innerHTML;
  var atl3QO = atl3QO.replace(/[',()]/g, "");
  var atl4Q = document.getElementById("ATL4Q").innerHTML;
  var atl4QO = document.getElementById("ATL4QOver").innerHTML;
  var atl4QO = atl4QO.replace(/[',()]/g, "");

  var balCover = document.getElementById("BALCover").innerHTML;
  var balML = document.getElementById("BALML").innerHTML;
  var balO = document.getElementById("BALO").innerHTML;
  var balO = balO.replace(/[',()]/g, "");
  var balSoloO = document.getElementById("BALSoloO").innerHTML;
  var balSoloO = balSoloO.replace(/[',()]/g, "");
  var balHalftime = document.getElementById("BALHalftime").innerHTML;
  var balHalftimeO = document.getElementById("BALHalftimeO").innerHTML;
  var balHalftimeO = balHalftimeO.replace(/[',()]/g, "");
  var bal1Q = document.getElementById("BAL1Q").innerHTML;
  var bal1QO = document.getElementById("BAL1QOver").innerHTML;
  var bal1QO = bal1QO.replace(/[',()]/g, "");
  var bal2Q = document.getElementById("BAL2Q").innerHTML;
  var bal2QO = document.getElementById("BAL2QOver").innerHTML;
  var bal2QO = bal2Q.replace(/[',()]/g, "");
  var bal3Q = document.getElementById("BAL3Q").innerHTML;
  var bal3QO = document.getElementById("BAL3QOver").innerHTML;
  var bal3QO = bal3QO.replace(/[',()]/g, "");
  var bal4Q = document.getElementById("BAL4Q").innerHTML;
  var bal4QO = document.getElementById("BAL4QOver").innerHTML;
  var bal4QO = bal4QO.replace(/[',()]/g, "");

  var bufCover = document.getElementById("BUFCover").innerHTML;
  var bufML = document.getElementById("BUFML").innerHTML;
  var bufO = document.getElementById("BUFO").innerHTML;
  var bufO = bufO.replace(/[',()]/g, "");
  var bufSoloO = document.getElementById("BUFSoloO").innerHTML;
  var bufSoloO = bufSoloO.replace(/[',()]/g, "");
  var bufHalftime = document.getElementById("BUFHalftime").innerHTML;
  var bufHalftimeO = document.getElementById("BUFHalftimeO").innerHTML;
  var bufHalftimeO = bufHalftimeO.replace(/[',()]/g, "");
  var buf1Q = document.getElementById("BUF1Q").innerHTML;
  var buf1QO = document.getElementById("BUF1QOver").innerHTML;
  var buf1QO = buf1QO.replace(/[',()]/g, "");
  var buf2Q = document.getElementById("BUF2Q").innerHTML;
  var buf2QO = document.getElementById("BUF2QOver").innerHTML;
  var buf2QO = buf2Q.replace(/[',()]/g, "");
  var buf3Q = document.getElementById("BUF3Q").innerHTML;
  var buf3QO = document.getElementById("BUF3QOver").innerHTML;
  var buf3QO = buf3QO.replace(/[',()]/g, "");
  var buf4Q = document.getElementById("BUF4Q").innerHTML;
  var buf4QO = document.getElementById("BUF4QOver").innerHTML;
  var buf4QO = buf4QO.replace(/[',()]/g, "");

  var carCover = document.getElementById("CARCover").innerHTML;
  var carML = document.getElementById("CARML").innerHTML;
  var carO = document.getElementById("CARO").innerHTML;
  var carO = carO.replace(/[',()]/g, "");
  var carSoloO = document.getElementById("CARSoloO").innerHTML;
  var carSoloO = carSoloO.replace(/[',()]/g, "");
  var carHalftime = document.getElementById("CARHalftime").innerHTML;
  var carHalftimeO = document.getElementById("CARHalftimeO").innerHTML;
  var carHalftimeO = carHalftimeO.replace(/[',()]/g, "");
  var car1Q = document.getElementById("CAR1Q").innerHTML;
  var car1QO = document.getElementById("CAR1QOver").innerHTML;
  var car1QO = car1QO.replace(/[',()]/g, "");
  var car2Q = document.getElementById("CAR2Q").innerHTML;
  var car2QO = document.getElementById("CAR2QOver").innerHTML;
  var car2QO = car2Q.replace(/[',()]/g, "");
  var car3Q = document.getElementById("CAR3Q").innerHTML;
  var car3QO = document.getElementById("CAR3QOver").innerHTML;
  var car3QO = car3QO.replace(/[',()]/g, "");
  var car4Q = document.getElementById("CAR4Q").innerHTML;
  var car4QO = document.getElementById("CAR4QOver").innerHTML;
  var car4QO = car4QO.replace(/[',()]/g, "");

  var chiCover = document.getElementById("CHICover").innerHTML;
  var chiML = document.getElementById("CHIML").innerHTML;
  var chiO = document.getElementById("CHIO").innerHTML;
  var chiO = chiO.replace(/[',()]/g, "");
  var chiSoloO = document.getElementById("CHISoloO").innerHTML;
  var chiSoloO = chiSoloO.replace(/[',()]/g, "");
  var chiHalftime = document.getElementById("CHIHalftime").innerHTML;
  var chiHalftimeO = document.getElementById("CHIHalftimeO").innerHTML;
  var chiHalftimeO = chiHalftimeO.replace(/[',()]/g, "");
  var chi1Q = document.getElementById("CHI1Q").innerHTML;
  var chi1QO = document.getElementById("CHI1QOver").innerHTML;
  var chi1QO = chi1QO.replace(/[',()]/g, "");
  var chi2Q = document.getElementById("CHI2Q").innerHTML;
  var chi2QO = document.getElementById("CHI2QOver").innerHTML;
  var chi2QO = chi2Q.replace(/[',()]/g, "");
  var chi3Q = document.getElementById("CHI3Q").innerHTML;
  var chi3QO = document.getElementById("CHI3QOver").innerHTML;
  var chi3QO = chi3QO.replace(/[',()]/g, "");
  var chi4Q = document.getElementById("CHI4Q").innerHTML;
  var chi4QO = document.getElementById("CHI4QOver").innerHTML;
  var chi4QO = chi4QO.replace(/[',()]/g, "");

  var cinCover = document.getElementById("CINCover").innerHTML;
  var cinML = document.getElementById("CINML").innerHTML;
  var cinO = document.getElementById("CINO").innerHTML;
  var cinO = cinO.replace(/[',()]/g, "");
  var cinSoloO = document.getElementById("CINSoloO").innerHTML;
  var cinSoloO = cinSoloO.replace(/[',()]/g, "");
  var cinHalftime = document.getElementById("CINHalftime").innerHTML;
  var cinHalftimeO = document.getElementById("CINHalftimeO").innerHTML;
  var cinHalftimeO = cinHalftimeO.replace(/[',()]/g, "");
  var cin1Q = document.getElementById("CIN1Q").innerHTML;
  var cin1QO = document.getElementById("CIN1QOver").innerHTML;
  var cin1QO = cin1QO.replace(/[',()]/g, "");
  var cin2Q = document.getElementById("CIN2Q").innerHTML;
  var cin2QO = document.getElementById("CIN2QOver").innerHTML;
  var cin2QO = cin2Q.replace(/[',()]/g, "");
  var cin3Q = document.getElementById("CIN3Q").innerHTML;
  var cin3QO = document.getElementById("CIN3QOver").innerHTML;
  var cin3QO = cin3QO.replace(/[',()]/g, "");
  var cin4Q = document.getElementById("CIN4Q").innerHTML;
  var cin4QO = document.getElementById("CIN4QOver").innerHTML;
  var cin4QO = cin4QO.replace(/[',()]/g, "");

  var cleCover = document.getElementById("CLECover").innerHTML;
  var cleML = document.getElementById("CLEML").innerHTML;
  var cleO = document.getElementById("CLEO").innerHTML;
  var cleO = cleO.replace(/[',()]/g, "");
  var cleSoloO = document.getElementById("CLESoloO").innerHTML;
  var cleSoloO = cleSoloO.replace(/[',()]/g, "");
  var cleHalftime = document.getElementById("CLEHalftime").innerHTML;
  var cleHalftimeO = document.getElementById("CLEHalftimeO").innerHTML;
  var cleHalftimeO = cleHalftimeO.replace(/[',()]/g, "");
  var cle1Q = document.getElementById("CLE1Q").innerHTML;
  var cle1QO = document.getElementById("CLE1QOver").innerHTML;
  var cle1QO = cle1QO.replace(/[',()]/g, "");
  var cle2Q = document.getElementById("CLE2Q").innerHTML;
  var cle2QO = document.getElementById("CLE2QOver").innerHTML;
  var cle2QO = cle2Q.replace(/[',()]/g, "");
  var cle3Q = document.getElementById("CLE3Q").innerHTML;
  var cle3QO = document.getElementById("CLE3QOver").innerHTML;
  var cle3QO = cle3QO.replace(/[',()]/g, "");
  var cle4Q = document.getElementById("CLE4Q").innerHTML;
  var cle4QO = document.getElementById("CLE4QOver").innerHTML;
  var cle4QO = cle4QO.replace(/[',()]/g, "");

  var dalCover = document.getElementById("DALCover").innerHTML;
  var dalML = document.getElementById("DALML").innerHTML;
  var dalO = document.getElementById("DALO").innerHTML;
  var dalO = dalO.replace(/[',()]/g, "");
  var dalSoloO = document.getElementById("DALSoloO").innerHTML;
  var dalSoloO = dalSoloO.replace(/[',()]/g, "");
  var dalHalftime = document.getElementById("DALHalftime").innerHTML;
  var dalHalftimeO = document.getElementById("DALHalftimeO").innerHTML;
  var dalHalftimeO = dalHalftimeO.replace(/[',()]/g, "");
  var dal1Q = document.getElementById("DAL1Q").innerHTML;
  var dal1QO = document.getElementById("DAL1QOver").innerHTML;
  var dal1QO = dal1QO.replace(/[',()]/g, "");
  var dal2Q = document.getElementById("DAL2Q").innerHTML;
  var dal2QO = document.getElementById("DAL2QOver").innerHTML;
  var dal2QO = dal2Q.replace(/[',()]/g, "");
  var dal3Q = document.getElementById("DAL3Q").innerHTML;
  var dal3QO = document.getElementById("DAL3QOver").innerHTML;
  var dal3QO = dal3QO.replace(/[',()]/g, "");
  var dal4Q = document.getElementById("DAL4Q").innerHTML;
  var dal4QO = document.getElementById("DAL4QOver").innerHTML;
  var dal4QO = dal4QO.replace(/[',()]/g, "");

  var denCover = document.getElementById("DENCover").innerHTML;
  var denML = document.getElementById("DENML").innerHTML;
  var denO = document.getElementById("DENO").innerHTML;
  var denO = denO.replace(/[',()]/g, "");
  var denSoloO = document.getElementById("DENSoloO").innerHTML;
  var denSoloO = denSoloO.replace(/[',()]/g, "");
  var denHalftime = document.getElementById("DENHalftime").innerHTML;
  var denHalftimeO = document.getElementById("DENHalftimeO").innerHTML;
  var denHalftimeO = denHalftimeO.replace(/[',()]/g, "");
  var den1Q = document.getElementById("DEN1Q").innerHTML;
  var den1QO = document.getElementById("DEN1QOver").innerHTML;
  var den1QO = den1QO.replace(/[',()]/g, "");
  var den2Q = document.getElementById("DEN2Q").innerHTML;
  var den2QO = document.getElementById("DEN2QOver").innerHTML;
  var den2QO = den2Q.replace(/[',()]/g, "");
  var den3Q = document.getElementById("DEN3Q").innerHTML;
  var den3QO = document.getElementById("DEN3QOver").innerHTML;
  var den3QO = den3QO.replace(/[',()]/g, "");
  var den4Q = document.getElementById("DEN4Q").innerHTML;
  var den4QO = document.getElementById("DEN4QOver").innerHTML;
  var den4QO = den4QO.replace(/[',()]/g, "");

  var detCover = document.getElementById("DETCover").innerHTML;
  var detML = document.getElementById("DETML").innerHTML;
  var detO = document.getElementById("DETO").innerHTML;
  var detO = detO.replace(/[',()]/g, "");
  var detSoloO = document.getElementById("DETSoloO").innerHTML;
  var detSoloO = detSoloO.replace(/[',()]/g, "");
  var detHalftime = document.getElementById("DETHalftime").innerHTML;
  var detHalftimeO = document.getElementById("DETHalftimeO").innerHTML;
  var detHalftimeO = detHalftimeO.replace(/[',()]/g, "");
  var det1Q = document.getElementById("DET1Q").innerHTML;
  var det1QO = document.getElementById("DET1QOver").innerHTML;
  var det1QO = det1QO.replace(/[',()]/g, "");
  var det2Q = document.getElementById("DET2Q").innerHTML;
  var det2QO = document.getElementById("DET2QOver").innerHTML;
  var det2QO = det2Q.replace(/[',()]/g, "");
  var det3Q = document.getElementById("DET3Q").innerHTML;
  var det3QO = document.getElementById("DET3QOver").innerHTML;
  var det3QO = det3QO.replace(/[',()]/g, "");
  var det4Q = document.getElementById("DET4Q").innerHTML;
  var det4QO = document.getElementById("DET4QOver").innerHTML;
  var det4QO = det4QO.replace(/[',()]/g, "");

  var gbCover = document.getElementById("GBCover").innerHTML;
  var gbML = document.getElementById("GBML").innerHTML;
  var gbO = document.getElementById("GBO").innerHTML;
  var gbO = gbO.replace(/[',()]/g, "");
  var gbSoloO = document.getElementById("GBSoloO").innerHTML;
  var gbSoloO = gbSoloO.replace(/[',()]/g, "");
  var gbHalftime = document.getElementById("GBHalftime").innerHTML;
  var gbHalftimeO = document.getElementById("GBHalftimeO").innerHTML;
  var gbHalftimeO = gbHalftimeO.replace(/[',()]/g, "");
  var gb1Q = document.getElementById("GB1Q").innerHTML;
  var gb1QO = document.getElementById("GB1QOver").innerHTML;
  var gb1QO = gb1QO.replace(/[',()]/g, "");
  var gb2Q = document.getElementById("GB2Q").innerHTML;
  var gb2QO = document.getElementById("GB2QOver").innerHTML;
  var gb2QO = gb2Q.replace(/[',()]/g, "");
  var gb3Q = document.getElementById("GB3Q").innerHTML;
  var gb3QO = document.getElementById("GB3QOver").innerHTML;
  var gb3QO = gb3QO.replace(/[',()]/g, "");
  var gb4Q = document.getElementById("GB4Q").innerHTML;
  var gb4QO = document.getElementById("GB4QOver").innerHTML;
  var gb4QO = gb4QO.replace(/[',()]/g, "");

  var houCover = document.getElementById("HOUCover").innerHTML;
  var houML = document.getElementById("HOUML").innerHTML;
  var houO = document.getElementById("HOUO").innerHTML;
  var houO = houO.replace(/[',()]/g, "");
  var houSoloO = document.getElementById("HOUSoloO").innerHTML;
  var houSoloO = houSoloO.replace(/[',()]/g, "");
  var houHalftime = document.getElementById("HOUHalftime").innerHTML;
  var houHalftimeO = document.getElementById("HOUHalftimeO").innerHTML;
  var houHalftimeO = houHalftimeO.replace(/[',()]/g, "");
  var hou1Q = document.getElementById("HOU1Q").innerHTML;
  var hou1QO = document.getElementById("HOU1QOver").innerHTML;
  var hou1QO = hou1QO.replace(/[',()]/g, "");
  var hou2Q = document.getElementById("HOU2Q").innerHTML;
  var hou2QO = document.getElementById("HOU2QOver").innerHTML;
  var hou2QO = hou2Q.replace(/[',()]/g, "");
  var hou3Q = document.getElementById("HOU3Q").innerHTML;
  var hou3QO = document.getElementById("HOU3QOver").innerHTML;
  var hou3QO = hou3QO.replace(/[',()]/g, "");
  var hou4Q = document.getElementById("HOU4Q").innerHTML;
  var hou4QO = document.getElementById("HOU4QOver").innerHTML;
  var hou4QO = hou4QO.replace(/[',()]/g, "");

  var indCover = document.getElementById("INDCover").innerHTML;
  var indML = document.getElementById("INDML").innerHTML;
  var indO = document.getElementById("INDO").innerHTML;
  var indO = indO.replace(/[',()]/g, "");
  var indSoloO = document.getElementById("INDSoloO").innerHTML;
  var indSoloO = indSoloO.replace(/[',()]/g, "");
  var indHalftime = document.getElementById("INDHalftime").innerHTML;
  var indHalftimeO = document.getElementById("INDHalftimeO").innerHTML;
  var indHalftimeO = indHalftimeO.replace(/[',()]/g, "");
  var ind1Q = document.getElementById("IND1Q").innerHTML;
  var ind1QO = document.getElementById("IND1QOver").innerHTML;
  var ind1QO = ind1QO.replace(/[',()]/g, "");
  var ind2Q = document.getElementById("IND2Q").innerHTML;
  var ind2QO = document.getElementById("IND2QOver").innerHTML;
  var ind2QO = ind2Q.replace(/[',()]/g, "");
  var ind3Q = document.getElementById("IND3Q").innerHTML;
  var ind3QO = document.getElementById("IND3QOver").innerHTML;
  var ind3QO = ind3QO.replace(/[',()]/g, "");
  var ind4Q = document.getElementById("IND4Q").innerHTML;
  var ind4QO = document.getElementById("IND4QOver").innerHTML;
  var ind4QO = ind4QO.replace(/[',()]/g, "");

  var jaxCover = document.getElementById("JAXCover").innerHTML;
  var jaxML = document.getElementById("JAXML").innerHTML;
  var jaxO = document.getElementById("JAXO").innerHTML;
  var jaxO = jaxO.replace(/[',()]/g, "");
  var jaxSoloO = document.getElementById("JAXSoloO").innerHTML;
  var jaxSoloO = jaxSoloO.replace(/[',()]/g, "");
  var jaxHalftime = document.getElementById("JAXHalftime").innerHTML;
  var jaxHalftimeO = document.getElementById("JAXHalftimeO").innerHTML;
  var jaxHalftimeO = jaxHalftimeO.replace(/[',()]/g, "");
  var jax1Q = document.getElementById("JAX1Q").innerHTML;
  var jax1QO = document.getElementById("JAX1QOver").innerHTML;
  var jax1QO = jax1QO.replace(/[',()]/g, "");
  var jax2Q = document.getElementById("JAX2Q").innerHTML;
  var jax2QO = document.getElementById("JAX2QOver").innerHTML;
  var jax2QO = jax2Q.replace(/[',()]/g, "");
  var jax3Q = document.getElementById("JAX3Q").innerHTML;
  var jax3QO = document.getElementById("JAX3QOver").innerHTML;
  var jax3QO = jax3QO.replace(/[',()]/g, "");
  var jax4Q = document.getElementById("JAX4Q").innerHTML;
  var jax4QO = document.getElementById("JAX4QOver").innerHTML;
  var jax4QO = jax4QO.replace(/[',()]/g, "");

  var kcCover = document.getElementById("KCCover").innerHTML;
  var kcML = document.getElementById("KCML").innerHTML;
  var kcO = document.getElementById("KCO").innerHTML;
  var kcO = kcO.replace(/[',()]/g, "");
  var kcSoloO = document.getElementById("KCSoloO").innerHTML;
  var kcSoloO = kcSoloO.replace(/[',()]/g, "");
  var kcHalftime = document.getElementById("KCHalftime").innerHTML;
  var kcHalftimeO = document.getElementById("KCHalftimeO").innerHTML;
  var kcHalftimeO = kcHalftimeO.replace(/[',()]/g, "");
  var kc1Q = document.getElementById("KC1Q").innerHTML;
  var kc1QO = document.getElementById("KC1QOver").innerHTML;
  var kc1QO = kc1QO.replace(/[',()]/g, "");
  var kc2Q = document.getElementById("KC2Q").innerHTML;
  var kc2QO = document.getElementById("KC2QOver").innerHTML;
  var kc2QO = kc2Q.replace(/[',()]/g, "");
  var kc3Q = document.getElementById("KC3Q").innerHTML;
  var kc3QO = document.getElementById("KC3QOver").innerHTML;
  var kc3QO = kc3QO.replace(/[',()]/g, "");
  var kc4Q = document.getElementById("KC4Q").innerHTML;
  var kc4QO = document.getElementById("KC4QOver").innerHTML;
  var kc4QO = kc4QO.replace(/[',()]/g, "");

  var miaCover = document.getElementById("MIACover").innerHTML;
  var miaML = document.getElementById("MIAML").innerHTML;
  var miaO = document.getElementById("MIAO").innerHTML;
  var miaO = miaO.replace(/[',()]/g, "");
  var miaSoloO = document.getElementById("MIASoloO").innerHTML;
  var miaSoloO = miaSoloO.replace(/[',()]/g, "");
  var miaHalftime = document.getElementById("MIAHalftime").innerHTML;
  var miaHalftimeO = document.getElementById("MIAHalftimeO").innerHTML;
  var miaHalftimeO = miaHalftimeO.replace(/[',()]/g, "");
  var mia1Q = document.getElementById("MIA1Q").innerHTML;
  var mia1QO = document.getElementById("MIA1QOver").innerHTML;
  var mia1QO = mia1QO.replace(/[',()]/g, "");
  var mia2Q = document.getElementById("MIA2Q").innerHTML;
  var mia2QO = document.getElementById("MIA2QOver").innerHTML;
  var mia2QO = mia2Q.replace(/[',()]/g, "");
  var mia3Q = document.getElementById("MIA3Q").innerHTML;
  var mia3QO = document.getElementById("MIA3QOver").innerHTML;
  var mia3QO = mia3QO.replace(/[',()]/g, "");
  var mia4Q = document.getElementById("MIA4Q").innerHTML;
  var mia4QO = document.getElementById("MIA4QOver").innerHTML;
  var mia4QO = mia4QO.replace(/[',()]/g, "");

  var minCover = document.getElementById("MINCover").innerHTML;
  var minML = document.getElementById("MINML").innerHTML;
  var minO = document.getElementById("MINO").innerHTML;
  var minO = minO.replace(/[',()]/g, "");
  var minSoloO = document.getElementById("MINSoloO").innerHTML;
  var minSoloO = minSoloO.replace(/[',()]/g, "");
  var minHalftime = document.getElementById("MINHalftime").innerHTML;
  var minHalftimeO = document.getElementById("MINHalftimeO").innerHTML;
  var minHalftimeO = minHalftimeO.replace(/[',()]/g, "");
  var min1Q = document.getElementById("MIN1Q").innerHTML;
  var min1QO = document.getElementById("MIN1QOver").innerHTML;
  var min1QO = min1QO.replace(/[',()]/g, "");
  var min2Q = document.getElementById("MIN2Q").innerHTML;
  var min2QO = document.getElementById("MIN2QOver").innerHTML;
  var min2QO = min2Q.replace(/[',()]/g, "");
  var min3Q = document.getElementById("MIN3Q").innerHTML;
  var min3QO = document.getElementById("MIN3QOver").innerHTML;
  var min3QO = min3QO.replace(/[',()]/g, "");
  var min4Q = document.getElementById("MIN4Q").innerHTML;
  var min4QO = document.getElementById("MIN4QOver").innerHTML;
  var min4QO = min4QO.replace(/[',()]/g, "");

  var neCover = document.getElementById("NECover").innerHTML;
  var neML = document.getElementById("NEML").innerHTML;
  var neO = document.getElementById("NEO").innerHTML;
  var neO = neO.replace(/[',()]/g, "");
  var neSoloO = document.getElementById("NESoloO").innerHTML;
  var neSoloO = neSoloO.replace(/[',()]/g, "");
  var neHalftime = document.getElementById("NEHalftime").innerHTML;
  var neHalftimeO = document.getElementById("NEHalftimeO").innerHTML;
  var neHalftimeO = neHalftimeO.replace(/[',()]/g, "");
  var ne1Q = document.getElementById("NE1Q").innerHTML;
  var ne1QO = document.getElementById("NE1QOver").innerHTML;
  var ne1QO = ne1QO.replace(/[',()]/g, "");
  var ne2Q = document.getElementById("NE2Q").innerHTML;
  var ne2QO = document.getElementById("NE2QOver").innerHTML;
  var ne2QO = ne2Q.replace(/[',()]/g, "");
  var ne3Q = document.getElementById("NE3Q").innerHTML;
  var ne3QO = document.getElementById("NE3QOver").innerHTML;
  var ne3QO = ne3QO.replace(/[',()]/g, "");
  var ne4Q = document.getElementById("NE4Q").innerHTML;
  var ne4QO = document.getElementById("NE4QOver").innerHTML;
  var ne4QO = ne4QO.replace(/[',()]/g, "");

  var noCover = document.getElementById("NOCover").innerHTML;
  var noML = document.getElementById("NOML").innerHTML;
  var noO = document.getElementById("NOO").innerHTML;
  var noO = noO.replace(/[',()]/g, "");
  var noSoloO = document.getElementById("NOSoloO").innerHTML;
  var noSoloO = noSoloO.replace(/[',()]/g, "");
  var noHalftime = document.getElementById("NOHalftime").innerHTML;
  var noHalftimeO = document.getElementById("NOHalftimeO").innerHTML;
  var noHalftimeO = noHalftimeO.replace(/[',()]/g, "");
  var no1Q = document.getElementById("NO1Q").innerHTML;
  var no1QO = document.getElementById("NO1QOver").innerHTML;
  var no1QO = no1QO.replace(/[',()]/g, "");
  var no2Q = document.getElementById("NO2Q").innerHTML;
  var no2QO = document.getElementById("NO2QOver").innerHTML;
  var no2QO = no2Q.replace(/[',()]/g, "");
  var no3Q = document.getElementById("NO3Q").innerHTML;
  var no3QO = document.getElementById("NO3QOver").innerHTML;
  var no3QO = no3QO.replace(/[',()]/g, "");
  var no4Q = document.getElementById("NO4Q").innerHTML;
  var no4QO = document.getElementById("NO4QOver").innerHTML;
  var no4QO = no4QO.replace(/[',()]/g, "");

  var nygCover = document.getElementById("NYGCover").innerHTML;
  var nygML = document.getElementById("NYGML").innerHTML;
  var nygO = document.getElementById("NYGO").innerHTML;
  var nygO = nygO.replace(/[',()]/g, "");
  var nygSoloO = document.getElementById("NYGSoloO").innerHTML;
  var nygSoloO = nygSoloO.replace(/[',()]/g, "");
  var nygHalftime = document.getElementById("NYGHalftime").innerHTML;
  var nygHalftimeO = document.getElementById("NYGHalftimeO").innerHTML;
  var nygHalftimeO = nygHalftimeO.replace(/[',()]/g, "");
  var nyg1Q = document.getElementById("NYG1Q").innerHTML;
  var nyg1QO = document.getElementById("NYG1QOver").innerHTML;
  var nyg1QO = nyg1QO.replace(/[',()]/g, "");
  var nyg2Q = document.getElementById("NYG2Q").innerHTML;
  var nyg2QO = document.getElementById("NYG2QOver").innerHTML;
  var nyg2QO = nyg2Q.replace(/[',()]/g, "");
  var nyg3Q = document.getElementById("NYG3Q").innerHTML;
  var nyg3QO = document.getElementById("NYG3QOver").innerHTML;
  var nyg3QO = nyg3QO.replace(/[',()]/g, "");
  var nyg4Q = document.getElementById("NYG4Q").innerHTML;
  var nyg4QO = document.getElementById("NYG4QOver").innerHTML;
  var nyg4QO = nyg4QO.replace(/[',()]/g, "");

  var nyjCover = document.getElementById("NYJCover").innerHTML;
  var nyjML = document.getElementById("NYJML").innerHTML;
  var nyjO = document.getElementById("NYJO").innerHTML;
  var nyjO = nyjO.replace(/[',()]/g, "");
  var nyjSoloO = document.getElementById("NYJSoloO").innerHTML;
  var nyjSoloO = nyjSoloO.replace(/[',()]/g, "");
  var nyjHalftime = document.getElementById("NYJHalftime").innerHTML;
  var nyjHalftimeO = document.getElementById("NYJHalftimeO").innerHTML;
  var nyjHalftimeO = nyjHalftimeO.replace(/[',()]/g, "");
  var nyj1Q = document.getElementById("NYJ1Q").innerHTML;
  var nyj1QO = document.getElementById("NYJ1QOver").innerHTML;
  var nyj1QO = nyj1QO.replace(/[',()]/g, "");
  var nyj2Q = document.getElementById("NYJ2Q").innerHTML;
  var nyj2QO = document.getElementById("NYJ2QOver").innerHTML;
  var nyj2QO = nyj2Q.replace(/[',()]/g, "");
  var nyj3Q = document.getElementById("NYJ3Q").innerHTML;
  var nyj3QO = document.getElementById("NYJ3QOver").innerHTML;
  var nyj3QO = nyj3QO.replace(/[',()]/g, "");
  var nyj4Q = document.getElementById("NYJ4Q").innerHTML;
  var nyj4QO = document.getElementById("NYJ4QOver").innerHTML;
  var nyj4QO = nyj4QO.replace(/[',()]/g, "");

  var oakCover = document.getElementById("OAKCover").innerHTML;
  var oakML = document.getElementById("OAKML").innerHTML;
  var oakO = document.getElementById("OAKO").innerHTML;
  var oakO = oakO.replace(/[',()]/g, "");
  var oakSoloO = document.getElementById("OAKSoloO").innerHTML;
  var oakSoloO = oakSoloO.replace(/[',()]/g, "");
  var oakHalftime = document.getElementById("OAKHalftime").innerHTML;
  var oakHalftimeO = document.getElementById("OAKHalftimeO").innerHTML;
  var oakHalftimeO = oakHalftimeO.replace(/[',()]/g, "");
  var oak1Q = document.getElementById("OAK1Q").innerHTML;
  var oak1QO = document.getElementById("OAK1QOver").innerHTML;
  var oak1QO = oak1QO.replace(/[',()]/g, "");
  var oak2Q = document.getElementById("OAK2Q").innerHTML;
  var oak2QO = document.getElementById("OAK2QOver").innerHTML;
  var oak2QO = oak2Q.replace(/[',()]/g, "");
  var oak3Q = document.getElementById("OAK3Q").innerHTML;
  var oak3QO = document.getElementById("OAK3QOver").innerHTML;
  var oak3QO = oak3QO.replace(/[',()]/g, "");
  var oak4Q = document.getElementById("OAK4Q").innerHTML;
  var oak4QO = document.getElementById("OAK4QOver").innerHTML;
  var oak4QO = oak4QO.replace(/[',()]/g, "");

  var phiCover = document.getElementById("PHICover").innerHTML;
  var phiML = document.getElementById("PHIML").innerHTML;
  var phiO = document.getElementById("PHIO").innerHTML;
  var phiO = phiO.replace(/[',()]/g, "");
  var phiSoloO = document.getElementById("PHISoloO").innerHTML;
  var phiSoloO = phiSoloO.replace(/[',()]/g, "");
  var phiHalftime = document.getElementById("PHIHalftime").innerHTML;
  var phiHalftimeO = document.getElementById("PHIHalftimeO").innerHTML;
  var phiHalftimeO = phiHalftimeO.replace(/[',()]/g, "");
  var phi1Q = document.getElementById("PHI1Q").innerHTML;
  var phi1QO = document.getElementById("PHI1QOver").innerHTML;
  var phi1QO = phi1QO.replace(/[',()]/g, "");
  var phi2Q = document.getElementById("PHI2Q").innerHTML;
  var phi2QO = document.getElementById("PHI2QOver").innerHTML;
  var phi2QO = phi2Q.replace(/[',()]/g, "");
  var phi3Q = document.getElementById("PHI3Q").innerHTML;
  var phi3QO = document.getElementById("PHI3QOver").innerHTML;
  var phi3QO = phi3QO.replace(/[',()]/g, "");
  var phi4Q = document.getElementById("PHI4Q").innerHTML;
  var phi4QO = document.getElementById("PHI4QOver").innerHTML;
  var phi4QO = phi4QO.replace(/[',()]/g, "");

  var pitCover = document.getElementById("PITCover").innerHTML;
  var pitML = document.getElementById("PITML").innerHTML;
  var pitO = document.getElementById("PITO").innerHTML;
  var pitO = pitO.replace(/[',()]/g, "");
  var pitSoloO = document.getElementById("PITSoloO").innerHTML;
  var pitSoloO = pitSoloO.replace(/[',()]/g, "");
  var pitHalftime = document.getElementById("PITHalftime").innerHTML;
  var pitHalftimeO = document.getElementById("PITHalftimeO").innerHTML;
  var pitHalftimeO = pitHalftimeO.replace(/[',()]/g, "");
  var pit1Q = document.getElementById("PIT1Q").innerHTML;
  var pit1QO = document.getElementById("PIT1QOver").innerHTML;
  var pit1QO = pit1QO.replace(/[',()]/g, "");
  var pit2Q = document.getElementById("PIT2Q").innerHTML;
  var pit2QO = document.getElementById("PIT2QOver").innerHTML;
  var pit2QO = pit2Q.replace(/[',()]/g, "");
  var pit3Q = document.getElementById("PIT3Q").innerHTML;
  var pit3QO = document.getElementById("PIT3QOver").innerHTML;
  var pit3QO = pit3QO.replace(/[',()]/g, "");
  var pit4Q = document.getElementById("PIT4Q").innerHTML;
  var pit4QO = document.getElementById("PIT4QOver").innerHTML;
  var pit4QO = pit4QO.replace(/[',()]/g, "");

  var lacCover = document.getElementById("LACCover").innerHTML;
  var lacML = document.getElementById("LACML").innerHTML;
  var lacO = document.getElementById("LACO").innerHTML;
  var lacO = lacO.replace(/[',()]/g, "");
  var lacSoloO = document.getElementById("LACSoloO").innerHTML;
  var lacSoloO = lacSoloO.replace(/[',()]/g, "");
  var lacHalftime = document.getElementById("LACHalftime").innerHTML;
  var lacHalftimeO = document.getElementById("LACHalftimeO").innerHTML;
  var lacHalftimeO = lacHalftimeO.replace(/[',()]/g, "");
  var lac1Q = document.getElementById("LAC1Q").innerHTML;
  var lac1QO = document.getElementById("LAC1QOver").innerHTML;
  var lac1QO = lac1QO.replace(/[',()]/g, "");
  var lac2Q = document.getElementById("LAC2Q").innerHTML;
  var lac2QO = document.getElementById("LAC2QOver").innerHTML;
  var lac2QO = lac2Q.replace(/[',()]/g, "");
  var lac3Q = document.getElementById("LAC3Q").innerHTML;
  var lac3QO = document.getElementById("LAC3QOver").innerHTML;
  var lac3QO = lac3QO.replace(/[',()]/g, "");
  var lac4Q = document.getElementById("LAC4Q").innerHTML;
  var lac4QO = document.getElementById("LAC4QOver").innerHTML;
  var lac4QO = lac4QO.replace(/[',()]/g, "");

  var seaCover = document.getElementById("SEACover").innerHTML;
  var seaML = document.getElementById("SEAML").innerHTML;
  var seaO = document.getElementById("SEAO").innerHTML;
  var seaO = seaO.replace(/[',()]/g, "");
  var seaSoloO = document.getElementById("SEASoloO").innerHTML;
  var seaSoloO = seaSoloO.replace(/[',()]/g, "");
  var seaHalftime = document.getElementById("SEAHalftime").innerHTML;
  var seaHalftimeO = document.getElementById("SEAHalftimeO").innerHTML;
  var seaHalftimeO = seaHalftimeO.replace(/[',()]/g, "");
  var sea1Q = document.getElementById("SEA1Q").innerHTML;
  var sea1QO = document.getElementById("SEA1QOver").innerHTML;
  var sea1QO = sea1QO.replace(/[',()]/g, "");
  var sea2Q = document.getElementById("SEA2Q").innerHTML;
  var sea2QO = document.getElementById("SEA2QOver").innerHTML;
  var sea2QO = sea2Q.replace(/[',()]/g, "");
  var sea3Q = document.getElementById("SEA3Q").innerHTML;
  var sea3QO = document.getElementById("SEA3QOver").innerHTML;
  var sea3QO = sea3QO.replace(/[',()]/g, "");
  var sea4Q = document.getElementById("SEA4Q").innerHTML;
  var sea4QO = document.getElementById("SEA4QOver").innerHTML;
  var sea4QO = sea4QO.replace(/[',()]/g, "");

  var sfCover = document.getElementById("SFCover").innerHTML;
  var sfML = document.getElementById("SFML").innerHTML;
  var sfO = document.getElementById("SFO").innerHTML;
  var sfO = sfO.replace(/[',()]/g, "");
  var sfSoloO = document.getElementById("SFSoloO").innerHTML;
  var sfSoloO = sfSoloO.replace(/[',()]/g, "");
  var sfHalftime = document.getElementById("SFHalftime").innerHTML;
  var sfHalftimeO = document.getElementById("SFHalftimeO").innerHTML;
  var sfHalftimeO = sfHalftimeO.replace(/[',()]/g, "");
  var sf1Q = document.getElementById("SF1Q").innerHTML;
  var sf1QO = document.getElementById("SF1QOver").innerHTML;
  var sf1QO = sf1QO.replace(/[',()]/g, "");
  var sf2Q = document.getElementById("SF2Q").innerHTML;
  var sf2QO = document.getElementById("SF2QOver").innerHTML;
  var sf2QO = sf2Q.replace(/[',()]/g, "");
  var sf3Q = document.getElementById("SF3Q").innerHTML;
  var sf3QO = document.getElementById("SF3QOver").innerHTML;
  var sf3QO = sf3QO.replace(/[',()]/g, "");
  var sf4Q = document.getElementById("SF4Q").innerHTML;
  var sf4QO = document.getElementById("SF4QOver").innerHTML;
  var sf4QO = sf4QO.replace(/[',()]/g, "");

  var larCover = document.getElementById("LARCover").innerHTML;
  var larML = document.getElementById("LARML").innerHTML;
  var larO = document.getElementById("LARO").innerHTML;
  var larO = larO.replace(/[',()]/g, "");
  var larSoloO = document.getElementById("LARSoloO").innerHTML;
  var larSoloO = larSoloO.replace(/[',()]/g, "");
  var larHalftime = document.getElementById("LARHalftime").innerHTML;
  var larHalftimeO = document.getElementById("LARHalftimeO").innerHTML;
  var larHalftimeO = larHalftimeO.replace(/[',()]/g, "");
  var lar1Q = document.getElementById("LAR1Q").innerHTML;
  var lar1QO = document.getElementById("LAR1QOver").innerHTML;
  var lar1QO = lar1QO.replace(/[',()]/g, "");
  var lar2Q = document.getElementById("LAR2Q").innerHTML;
  var lar2QO = document.getElementById("LAR2QOver").innerHTML;
  var lar2QO = lar2Q.replace(/[',()]/g, "");
  var lar3Q = document.getElementById("LAR3Q").innerHTML;
  var lar3QO = document.getElementById("LAR3QOver").innerHTML;
  var lar3QO = lar3QO.replace(/[',()]/g, "");
  var lar4Q = document.getElementById("LAR4Q").innerHTML;
  var lar4QO = document.getElementById("LAR4QOver").innerHTML;
  var lar4QO = lar4QO.replace(/[',()]/g, "");

  var tbCover = document.getElementById("TBCover").innerHTML;
  var tbML = document.getElementById("TBML").innerHTML;
  var tbO = document.getElementById("TBO").innerHTML;
  var tbO = tbO.replace(/[',()]/g, "");
  var tbSoloO = document.getElementById("TBSoloO").innerHTML;
  var tbSoloO = tbSoloO.replace(/[',()]/g, "");
  var tbHalftime = document.getElementById("TBHalftime").innerHTML;
  var tbHalftimeO = document.getElementById("TBHalftimeO").innerHTML;
  var tbHalftimeO = tbHalftimeO.replace(/[',()]/g, "");
  var tb1Q = document.getElementById("TB1Q").innerHTML;
  var tb1QO = document.getElementById("TB1QOver").innerHTML;
  var tb1QO = tb1QO.replace(/[',()]/g, "");
  var tb2Q = document.getElementById("TB2Q").innerHTML;
  var tb2QO = document.getElementById("TB2QOver").innerHTML;
  var tb2QO = tb2Q.replace(/[',()]/g, "");
  var tb3Q = document.getElementById("TB3Q").innerHTML;
  var tb3QO = document.getElementById("TB3QOver").innerHTML;
  var tb3QO = tb3QO.replace(/[',()]/g, "");
  var tb4Q = document.getElementById("TB4Q").innerHTML;
  var tb4QO = document.getElementById("TB4QOver").innerHTML;
  var tb4QO = tb4QO.replace(/[',()]/g, "");

  var tenCover = document.getElementById("TENCover").innerHTML;
  var tenML = document.getElementById("TENML").innerHTML;
  var tenO = document.getElementById("TENO").innerHTML;
  var tenO = tenO.replace(/[',()]/g, "");
  var tenSoloO = document.getElementById("TENSoloO").innerHTML;
  var tenSoloO = tenSoloO.replace(/[',()]/g, "");
  var tenHalftime = document.getElementById("TENHalftime").innerHTML;
  var tenHalftimeO = document.getElementById("TENHalftimeO").innerHTML;
  var tenHalftimeO = tenHalftimeO.replace(/[',()]/g, "");
  var ten1Q = document.getElementById("TEN1Q").innerHTML;
  var ten1QO = document.getElementById("TEN1QOver").innerHTML;
  var ten1QO = ten1QO.replace(/[',()]/g, "");
  var ten2Q = document.getElementById("TEN2Q").innerHTML;
  var ten2QO = document.getElementById("TEN2QOver").innerHTML;
  var ten2QO = ten2Q.replace(/[',()]/g, "");
  var ten3Q = document.getElementById("TEN3Q").innerHTML;
  var ten3QO = document.getElementById("TEN3QOver").innerHTML;
  var ten3QO = ten3QO.replace(/[',()]/g, "");
  var ten4Q = document.getElementById("TEN4Q").innerHTML;
  var ten4QO = document.getElementById("TEN4QOver").innerHTML;
  var ten4QO = ten4QO.replace(/[',()]/g, "");

  var wasCover = document.getElementById("WASCover").innerHTML;
  var wasML = document.getElementById("WASML").innerHTML;
  var wasO = document.getElementById("WASO").innerHTML;
  var wasO = wasO.replace(/[',()]/g, "");
  var wasSoloO = document.getElementById("WASSoloO").innerHTML;
  var wasSoloO = wasSoloO.replace(/[',()]/g, "");
  var wasHalftime = document.getElementById("WASHalftime").innerHTML;
  var wasHalftimeO = document.getElementById("WASHalftimeO").innerHTML;
  var wasHalftimeO = wasHalftimeO.replace(/[',()]/g, "");
  var was1Q = document.getElementById("WAS1Q").innerHTML;
  var was1QO = document.getElementById("WAS1QOver").innerHTML;
  var was1QO = was1QO.replace(/[',()]/g, "");
  var was2Q = document.getElementById("WAS2Q").innerHTML;
  var was2QO = document.getElementById("WAS2QOver").innerHTML;
  var was2QO = was2Q.replace(/[',()]/g, "");
  var was3Q = document.getElementById("WAS3Q").innerHTML;
  var was3QO = document.getElementById("WAS3QOver").innerHTML;
  var was3QO = was3QO.replace(/[',()]/g, "");
  var was4Q = document.getElementById("WAS4Q").innerHTML;
  var was4QO = document.getElementById("WAS4QOver").innerHTML;
  var was4QO = was4QO.replace(/[',()]/g, "");


  // How to get the under of a team

  // turn the variable into an integer

  var ariUnder = parseFloat(ariO, 10);
  var ariSoloUnder = parseFloat(ariO,10);
  var ariHalftimeUnder = parseFloat(ariHalftimeO,10);
  var ari1QU = parseFloat(ari1QO,10);
  var ari2QU = parseFloat(ari2QO,10);
  var ari3QU = parseFloat(ari3QO,10);
  var ari4QU = parseFloat(ari4QO,10);

  var atlUnder = parseFloat(atlO, 10);
  var atlSoloUnder = parseFloat(atlO,10);
  var atlHalftimeUnder = parseFloat(atlHalftimeO,10);
  var atl1QU = parseFloat(atl1QO,10);
  var atl2QU = parseFloat(atl2QO,10);
  var atl3QU = parseFloat(atl3QO,10);
  var atl4QU = parseFloat(atl4QO,10);

  var balUnder = parseFloat(balO, 10);
  var balSoloUnder = parseFloat(balO,10);
  var balHalftimeUnder = parseFloat(balHalftimeO,10);
  var bal1QU = parseFloat(bal1QO,10);
  var bal2QU = parseFloat(bal2QO,10);
  var bal3QU = parseFloat(bal3QO,10);
  var bal4QU = parseFloat(bal4QO,10);

  var bufUnder = parseFloat(bufO, 10);
  var bufSoloUnder = parseFloat(bufO,10);
  var bufHalftimeUnder = parseFloat(bufHalftimeO,10);
  var buf1QU = parseFloat(buf1QO,10);
  var buf2QU = parseFloat(buf2QO,10);
  var buf3QU = parseFloat(buf3QO,10);
  var buf4QU = parseFloat(buf4QO,10);

  var carUnder = parseFloat(carO, 10);
  var carSoloUnder = parseFloat(carO,10);
  var carHalftimeUnder = parseFloat(carHalftimeO,10);
  var car1QU = parseFloat(car1QO,10);
  var car2QU = parseFloat(car2QO,10);
  var car3QU = parseFloat(car3QO,10);
  var car4QU = parseFloat(car4QO,10);

  var chiUnder = parseFloat(chiO, 10);
  var chiSoloUnder = parseFloat(chiO,10);
  var chiHalftimeUnder = parseFloat(chiHalftimeO,10);
  var chi1QU = parseFloat(chi1QO,10);
  var chi2QU = parseFloat(chi2QO,10);
  var chi3QU = parseFloat(chi3QO,10);
  var chi4QU = parseFloat(chi4QO,10);

  var cinUnder = parseFloat(cinO, 10);
  var cinSoloUnder = parseFloat(cinO,10);
  var cinHalftimeUnder = parseFloat(cinHalftimeO,10);
  var cin1QU = parseFloat(cin1QO,10);
  var cin2QU = parseFloat(cin2QO,10);
  var cin3QU = parseFloat(cin3QO,10);
  var cin4QU = parseFloat(cin4QO,10);

  var cleUnder = parseFloat(cleO, 10);
  var cleSoloUnder = parseFloat(cleO,10);
  var cleHalftimeUnder = parseFloat(cleHalftimeO,10);
  var cle1QU = parseFloat(cle1QO,10);
  var cle2QU = parseFloat(cle2QO,10);
  var cle3QU = parseFloat(cle3QO,10);
  var cle4QU = parseFloat(cle4QO,10);

  var dalUnder = parseFloat(dalO, 10);
  var dalSoloUnder = parseFloat(dalO,10);
  var dalHalftimeUnder = parseFloat(dalHalftimeO,10);
  var dal1QU = parseFloat(dal1QO,10);
  var dal2QU = parseFloat(dal2QO,10);
  var dal3QU = parseFloat(dal3QO,10);
  var dal4QU = parseFloat(dal4QO,10);

  var denUnder = parseFloat(denO, 10);
  var denSoloUnder = parseFloat(denO,10);
  var denHalftimeUnder = parseFloat(denHalftimeO,10);
  var den1QU = parseFloat(den1QO,10);
  var den2QU = parseFloat(den2QO,10);
  var den3QU = parseFloat(den3QO,10);
  var den4QU = parseFloat(den4QO,10);

  var detUnder = parseFloat(detO, 10);
  var detSoloUnder = parseFloat(detO,10);
  var detHalftimeUnder = parseFloat(detHalftimeO,10);
  var det1QU = parseFloat(det1QO,10);
  var det2QU = parseFloat(det2QO,10);
  var det3QU = parseFloat(det3QO,10);
  var det4QU = parseFloat(det4QO,10);

  var gbUnder = parseFloat(gbO, 10);
  var gbSoloUnder = parseFloat(gbO,10);
  var gbHalftimeUnder = parseFloat(gbHalftimeO,10);
  var gb1QU = parseFloat(gb1QO,10);
  var gb2QU = parseFloat(gb2QO,10);
  var gb3QU = parseFloat(gb3QO,10);
  var gb4QU = parseFloat(gb4QO,10);

  var houUnder = parseFloat(houO, 10);
  var houSoloUnder = parseFloat(houO,10);
  var houHalftimeUnder = parseFloat(houHalftimeO,10);
  var hou1QU = parseFloat(hou1QO,10);
  var hou2QU = parseFloat(hou2QO,10);
  var hou3QU = parseFloat(hou3QO,10);
  var hou4QU = parseFloat(hou4QO,10);

  var indUnder = parseFloat(indO, 10);
  var indSoloUnder = parseFloat(indO,10);
  var indHalftimeUnder = parseFloat(indHalftimeO,10);
  var ind1QU = parseFloat(ind1QO,10);
  var ind2QU = parseFloat(ind2QO,10);
  var ind3QU = parseFloat(ind3QO,10);
  var ind4QU = parseFloat(ind4QO,10);

  var jaxUnder = parseFloat(jaxO, 10);
  var jaxSoloUnder = parseFloat(jaxO,10);
  var jaxHalftimeUnder = parseFloat(jaxHalftimeO,10);
  var jax1QU = parseFloat(jax1QO,10);
  var jax2QU = parseFloat(jax2QO,10);
  var jax3QU = parseFloat(jax3QO,10);
  var jax4QU = parseFloat(jax4QO,10);

  var kcUnder = parseFloat(kcO, 10);
  var kcSoloUnder = parseFloat(kcO,10);
  var kcHalftimeUnder = parseFloat(kcHalftimeO,10);
  var kc1QU = parseFloat(kc1QO,10);
  var kc2QU = parseFloat(kc2QO,10);
  var kc3QU = parseFloat(kc3QO,10);
  var kc4QU = parseFloat(kc4QO,10);

  var miaUnder = parseFloat(miaO, 10);
  var miaSoloUnder = parseFloat(miaO,10);
  var miaHalftimeUnder = parseFloat(miaHalftimeO,10);
  var mia1QU = parseFloat(mia1QO,10);
  var mia2QU = parseFloat(mia2QO,10);
  var mia3QU = parseFloat(mia3QO,10);
  var mia4QU = parseFloat(mia4QO,10);

  var minUnder = parseFloat(minO, 10);
  var minSoloUnder = parseFloat(minO,10);
  var minHalftimeUnder = parseFloat(minHalftimeO,10);
  var min1QU = parseFloat(min1QO,10);
  var min2QU = parseFloat(min2QO,10);
  var min3QU = parseFloat(min3QO,10);
  var min4QU = parseFloat(min4QO,10);

  var neUnder = parseFloat(neO, 10);
  var neSoloUnder = parseFloat(neO,10);
  var neHalftimeUnder = parseFloat(neHalftimeO,10);
  var ne1QU = parseFloat(ne1QO,10);
  var ne2QU = parseFloat(ne2QO,10);
  var ne3QU = parseFloat(ne3QO,10);
  var ne4QU = parseFloat(ne4QO,10);

  var noUnder = parseFloat(noO, 10);
  var noSoloUnder = parseFloat(noO,10);
  var noHalftimeUnder = parseFloat(noHalftimeO,10);
  var no1QU = parseFloat(no1QO,10);
  var no2QU = parseFloat(no2QO,10);
  var no3QU = parseFloat(no3QO,10);
  var no4QU = parseFloat(no4QO,10);

  var nygUnder = parseFloat(nygO, 10);
  var nygSoloUnder = parseFloat(nygO,10);
  var nygHalftimeUnder = parseFloat(nygHalftimeO,10);
  var nyg1QU = parseFloat(nyg1QO,10);
  var nyg2QU = parseFloat(nyg2QO,10);
  var nyg3QU = parseFloat(nyg3QO,10);
  var nyg4QU = parseFloat(nyg4QO,10);

  var nyjUnder = parseFloat(nyjO, 10);
  var nyjSoloUnder = parseFloat(nyjO,10);
  var nyjHalftimeUnder = parseFloat(nyjHalftimeO,10);
  var nyj1QU = parseFloat(nyj1QO,10);
  var nyj2QU = parseFloat(nyj2QO,10);
  var nyj3QU = parseFloat(nyj3QO,10);
  var nyj4QU = parseFloat(nyj4QO,10);

  var oakUnder = parseFloat(oakO, 10);
  var oakSoloUnder = parseFloat(oakO,10);
  var oakHalftimeUnder = parseFloat(oakHalftimeO,10);
  var oak1QU = parseFloat(oak1QO,10);
  var oak2QU = parseFloat(oak2QO,10);
  var oak3QU = parseFloat(oak3QO,10);
  var oak4QU = parseFloat(oak4QO,10);

  var phiUnder = parseFloat(phiO, 10);
  var phiSoloUnder = parseFloat(phiO,10);
  var phiHalftimeUnder = parseFloat(phiHalftimeO,10);
  var phi1QU = parseFloat(phi1QO,10);
  var phi2QU = parseFloat(phi2QO,10);
  var phi3QU = parseFloat(phi3QO,10);
  var phi4QU = parseFloat(phi4QO,10);

  var pitUnder = parseFloat(pitO, 10);
  var pitSoloUnder = parseFloat(pitO,10);
  var pitHalftimeUnder = parseFloat(pitHalftimeO,10);
  var pit1QU = parseFloat(pit1QO,10);
  var pit2QU = parseFloat(pit2QO,10);
  var pit3QU = parseFloat(pit3QO,10);
  var pit4QU = parseFloat(pit4QO,10);

  var lacUnder = parseFloat(lacO, 10);
  var lacSoloUnder = parseFloat(lacO,10);
  var lacHalftimeUnder = parseFloat(lacHalftimeO,10);
  var lac1QU = parseFloat(lac1QO,10);
  var lac2QU = parseFloat(lac2QO,10);
  var lac3QU = parseFloat(lac3QO,10);
  var lac4QU = parseFloat(lac4QO,10);

  var seaUnder = parseFloat(seaO, 10);
  var seaSoloUnder = parseFloat(seaO,10);
  var seaHalftimeUnder = parseFloat(seaHalftimeO,10);
  var sea1QU = parseFloat(sea1QO,10);
  var sea2QU = parseFloat(sea2QO,10);
  var sea3QU = parseFloat(sea3QO,10);
  var sea4QU = parseFloat(sea4QO,10);

  var sfUnder = parseFloat(sfO, 10);
  var sfSoloUnder = parseFloat(sfO,10);
  var sfHalftimeUnder = parseFloat(sfHalftimeO,10);
  var sf1QU = parseFloat(sf1QO,10);
  var sf2QU = parseFloat(sf2QO,10);
  var sf3QU = parseFloat(sf3QO,10);
  var sf4QU = parseFloat(sf4QO,10);

  var larUnder = parseFloat(larO, 10);
  var larSoloUnder = parseFloat(larO,10);
  var larHalftimeUnder = parseFloat(larHalftimeO,10);
  var lar1QU = parseFloat(lar1QO,10);
  var lar2QU = parseFloat(lar2QO,10);
  var lar3QU = parseFloat(lar3QO,10);
  var lar4QU = parseFloat(lar4QO,10);

  var tbUnder = parseFloat(tbO, 10);
  var tbSoloUnder = parseFloat(tbO,10);
  var tbHalftimeUnder = parseFloat(tbHalftimeO,10);
  var tb1QU = parseFloat(tb1QO,10);
  var tb2QU = parseFloat(tb2QO,10);
  var tb3QU = parseFloat(tb3QO,10);
  var tb4QU = parseFloat(tb4QO,10);

  var tenUnder = parseFloat(tenO, 10);
  var tenSoloUnder = parseFloat(tenO,10);
  var tenHalftimeUnder = parseFloat(tenHalftimeO,10);
  var ten1QU = parseFloat(ten1QO,10);
  var ten2QU = parseFloat(ten2QO,10);
  var ten3QU = parseFloat(ten3QO,10);
  var ten4QU = parseFloat(ten4QO,10);

  var wasUnder = parseFloat(wasO, 10);
  var wasSoloUnder = parseFloat(wasO,10);
  var wasHalftimeUnder = parseFloat(wasHalftimeO,10);
  var was1QU = parseFloat(was1QO,10);
  var was2QU = parseFloat(was2QO,10);
  var was3QU = parseFloat(was3QO,10);
  var was4QU = parseFloat(was4QO,10);

  // Turn the over into under by subtracting by 100

  var ariU = 100 - ariUnder;
  var ariSoloU = 100 - ariSoloUnder;
  var ariHalftimeU = 100 - ariHalftimeUnder;
  var ari1QUnder = 100 - ari1QU;
  var ari2QUnder = 100 - ari2QU;
  var ari3QUnder = 100 - ari3QU;
  var ari4QUnder = 100 - ari4QU;

  var atlU = 100 - atlUnder;
  var atlSoloU = 100 - atlSoloUnder;
  var atlHalftimeU = 100 - atlHalftimeUnder;
  var atl1QUnder = 100 - atl1QU;
  var atl2QUnder = 100 - atl2QU;
  var atl3QUnder = 100 - atl3QU;
  var atl4QUnder = 100 - atl4QU;

  var balU = 100 - balUnder;
  var balSoloU = 100 - balSoloUnder;
  var balHalftimeU = 100 - balHalftimeUnder;
  var bal1QUnder = 100 - bal1QU;
  var bal2QUnder = 100 - bal2QU;
  var bal3QUnder = 100 - bal3QU;
  var bal4QUnder = 100 - bal4QU;

  var bufU = 100 - bufUnder;
  var bufSoloU = 100 - bufSoloUnder;
  var bufHalftimeU = 100 - bufHalftimeUnder;
  var buf1QUnder = 100 - buf1QU;
  var buf2QUnder = 100 - buf2QU;
  var buf3QUnder = 100 - buf3QU;
  var buf4QUnder = 100 - buf4QU;

  var carU = 100 - carUnder;
  var carSoloU = 100 - carSoloUnder;
  var carHalftimeU = 100 - carHalftimeUnder;
  var car1QUnder = 100 - car1QU;
  var car2QUnder = 100 - car2QU;
  var car3QUnder = 100 - car3QU;
  var car4QUnder = 100 - car4QU;

  var chiU = 100 - chiUnder;
  var chiSoloU = 100 - chiSoloUnder;
  var chiHalftimeU = 100 - chiHalftimeUnder;
  var chi1QUnder = 100 - chi1QU;
  var chi2QUnder = 100 - chi2QU;
  var chi3QUnder = 100 - chi3QU;
  var chi4QUnder = 100 - chi4QU;

  var cinU = 100 - cinUnder;
  var cinSoloU = 100 - cinSoloUnder;
  var cinHalftimeU = 100 - cinHalftimeUnder;
  var cin1QUnder = 100 - cin1QU;
  var cin2QUnder = 100 - cin2QU;
  var cin3QUnder = 100 - cin3QU;
  var cin4QUnder = 100 - cin4QU;

  var cleU = 100 - cleUnder;
  var cleSoloU = 100 - cleSoloUnder;
  var cleHalftimeU = 100 - cleHalftimeUnder;
  var cle1QUnder = 100 - cle1QU;
  var cle2QUnder = 100 - cle2QU;
  var cle3QUnder = 100 - cle3QU;
  var cle4QUnder = 100 - cle4QU;

  var dalU = 100 - dalUnder;
  var dalSoloU = 100 - dalSoloUnder;
  var dalHalftimeU = 100 - dalHalftimeUnder;
  var dal1QUnder = 100 - dal1QU;
  var dal2QUnder = 100 - dal2QU;
  var dal3QUnder = 100 - dal3QU;
  var dal4QUnder = 100 - dal4QU;

  var denU = 100 - denUnder;
  var denSoloU = 100 - denSoloUnder;
  var denHalftimeU = 100 - denHalftimeUnder;
  var den1QUnder = 100 - den1QU;
  var den2QUnder = 100 - den2QU;
  var den3QUnder = 100 - den3QU;
  var den4QUnder = 100 - den4QU;

  var detU = 100 - detUnder;
  var detSoloU = 100 - detSoloUnder;
  var detHalftimeU = 100 - detHalftimeUnder;
  var det1QUnder = 100 - det1QU;
  var det2QUnder = 100 - det2QU;
  var det3QUnder = 100 - det3QU;
  var det4QUnder = 100 - det4QU;

  var gbU = 100 - gbUnder;
  var gbSoloU = 100 - gbSoloUnder;
  var gbHalftimeU = 100 - gbHalftimeUnder;
  var gb1QUnder = 100 - gb1QU;
  var gb2QUnder = 100 - gb2QU;
  var gb3QUnder = 100 - gb3QU;
  var gb4QUnder = 100 - gb4QU;

  var houU = 100 - houUnder;
  var houSoloU = 100 - houSoloUnder;
  var houHalftimeU = 100 - houHalftimeUnder;
  var hou1QUnder = 100 - hou1QU;
  var hou2QUnder = 100 - hou2QU;
  var hou3QUnder = 100 - hou3QU;
  var hou4QUnder = 100 - hou4QU;

  var indU = 100 - indUnder;
  var indSoloU = 100 - indSoloUnder;
  var indHalftimeU = 100 - indHalftimeUnder;
  var ind1QUnder = 100 - ind1QU;
  var ind2QUnder = 100 - ind2QU;
  var ind3QUnder = 100 - ind3QU;
  var ind4QUnder = 100 - ind4QU;

  var jaxU = 100 - jaxUnder;
  var jaxSoloU = 100 - jaxSoloUnder;
  var jaxHalftimeU = 100 - jaxHalftimeUnder;
  var jax1QUnder = 100 - jax1QU;
  var jax2QUnder = 100 - jax2QU;
  var jax3QUnder = 100 - jax3QU;
  var jax4QUnder = 100 - jax4QU;

  var kcU = 100 - kcUnder;
  var kcSoloU = 100 - kcSoloUnder;
  var kcHalftimeU = 100 - kcHalftimeUnder;
  var kc1QUnder = 100 - kc1QU;
  var kc2QUnder = 100 - kc2QU;
  var kc3QUnder = 100 - kc3QU;
  var kc4QUnder = 100 - kc4QU;

  var miaU = 100 - miaUnder;
  var miaSoloU = 100 - miaSoloUnder;
  var miaHalftimeU = 100 - miaHalftimeUnder;
  var mia1QUnder = 100 - mia1QU;
  var mia2QUnder = 100 - mia2QU;
  var mia3QUnder = 100 - mia3QU;
  var mia4QUnder = 100 - mia4QU;

  var minU = 100 - minUnder;
  var minSoloU = 100 - minSoloUnder;
  var minHalftimeU = 100 - minHalftimeUnder;
  var min1QUnder = 100 - min1QU;
  var min2QUnder = 100 - min2QU;
  var min3QUnder = 100 - min3QU;
  var min4QUnder = 100 - min4QU;

  var neU = 100 - neUnder;
  var neSoloU = 100 - neSoloUnder;
  var neHalftimeU = 100 - neHalftimeUnder;
  var ne1QUnder = 100 - ne1QU;
  var ne2QUnder = 100 - ne2QU;
  var ne3QUnder = 100 - ne3QU;
  var ne4QUnder = 100 - ne4QU;

  var noU = 100 - noUnder;
  var noSoloU = 100 - noSoloUnder;
  var noHalftimeU = 100 - noHalftimeUnder;
  var no1QUnder = 100 - no1QU;
  var no2QUnder = 100 - no2QU;
  var no3QUnder = 100 - no3QU;
  var no4QUnder = 100 - no4QU;

  var nygU = 100 - nygUnder;
  var nygSoloU = 100 - nygSoloUnder;
  var nygHalftimeU = 100 - nygHalftimeUnder;
  var nyg1QUnder = 100 - nyg1QU;
  var nyg2QUnder = 100 - nyg2QU;
  var nyg3QUnder = 100 - nyg3QU;
  var nyg4QUnder = 100 - nyg4QU;

  var nyjU = 100 - nyjUnder;
  var nyjSoloU = 100 - nyjSoloUnder;
  var nyjHalftimeU = 100 - nyjHalftimeUnder;
  var nyj1QUnder = 100 - nyj1QU;
  var nyj2QUnder = 100 - nyj2QU;
  var nyj3QUnder = 100 - nyj3QU;
  var nyj4QUnder = 100 - nyj4QU;

  var oakU = 100 - oakUnder;
  var oakSoloU = 100 - oakSoloUnder;
  var oakHalftimeU = 100 - oakHalftimeUnder;
  var oak1QUnder = 100 - oak1QU;
  var oak2QUnder = 100 - oak2QU;
  var oak3QUnder = 100 - oak3QU;
  var oak4QUnder = 100 - oak4QU;

  var phiU = 100 - phiUnder;
  var phiSoloU = 100 - phiSoloUnder;
  var phiHalftimeU = 100 - phiHalftimeUnder;
  var phi1QUnder = 100 - phi1QU;
  var phi2QUnder = 100 - phi2QU;
  var phi3QUnder = 100 - phi3QU;
  var phi4QUnder = 100 - phi4QU;

  var pitU = 100 - pitUnder;
  var pitSoloU = 100 - pitSoloUnder;
  var pitHalftimeU = 100 - pitHalftimeUnder;
  var pit1QUnder = 100 - pit1QU;
  var pit2QUnder = 100 - pit2QU;
  var pit3QUnder = 100 - pit3QU;
  var pit4QUnder = 100 - pit4QU;

  var lacU = 100 - lacUnder;
  var lacSoloU = 100 - lacSoloUnder;
  var lacHalftimeU = 100 - lacHalftimeUnder;
  var lac1QUnder = 100 - lac1QU;
  var lac2QUnder = 100 - lac2QU;
  var lac3QUnder = 100 - lac3QU;
  var lac4QUnder = 100 - lac4QU;

  var seaU = 100 - seaUnder;
  var seaSoloU = 100 - seaSoloUnder;
  var seaHalftimeU = 100 - seaHalftimeUnder;
  var sea1QUnder = 100 - sea1QU;
  var sea2QUnder = 100 - sea2QU;
  var sea3QUnder = 100 - sea3QU;
  var sea4QUnder = 100 - sea4QU;

  var sfU = 100 - sfUnder;
  var sfSoloU = 100 - sfSoloUnder;
  var sfHalftimeU = 100 - sfHalftimeUnder;
  var sf1QUnder = 100 - sf1QU;
  var sf2QUnder = 100 - sf2QU;
  var sf3QUnder = 100 - sf3QU;
  var sf4QUnder = 100 - sf4QU;

  var larU = 100 - larUnder;
  var larSoloU = 100 - larSoloUnder;
  var larHalftimeU = 100 - larHalftimeUnder;
  var lar1QUnder = 100 - lar1QU;
  var lar2QUnder = 100 - lar2QU;
  var lar3QUnder = 100 - lar3QU;
  var lar4QUnder = 100 - lar4QU;

  var tbU = 100 - tbUnder;
  var tbSoloU = 100 - tbSoloUnder;
  var tbHalftimeU = 100 - tbHalftimeUnder;
  var tb1QUnder = 100 - tb1QU;
  var tb2QUnder = 100 - tb2QU;
  var tb3QUnder = 100 - tb3QU;
  var tb4QUnder = 100 - tb4QU;

  var tenU = 100 - tenUnder;
  var tenSoloU = 100 - tenSoloUnder;
  var tenHalftimeU = 100 - tenHalftimeUnder;
  var ten1QUnder = 100 - ten1QU;
  var ten2QUnder = 100 - ten2QU;
  var ten3QUnder = 100 - ten3QU;
  var ten4QUnder = 100 - ten4QU;

  var wasU = 100 - wasUnder;
  var wasSoloU = 100 - wasSoloUnder;
  var wasHalftimeU = 100 - wasHalftimeUnder;
  var was1QUnder = 100 - was1QU;
  var was2QUnder = 100 - was2QU;
  var was3QUnder = 100 - was3QU;
  var was4QUnder = 100 - was4QU;

  // Team stats in order by team index & stat index
  var statLists = new Array(21)
statLists["ATS"] = [ariCover, atlCover, balCover, bufCover,carCover, chiCover, cinCover, cleCover, dalCover, denCover, detCover, gbCover, houCover, indCover, jaxCover, kcCover, lacCover, larCover, miaCover, minCover, neCover, noCover, nygCover, nyjCover, oakCover, phiCover, sfCover, seaCover, pitCover, tbCover, tenCover,wasCover]
statLists["ML"] = [ariML, atlML, balML, bufML,carML, chiML, cinML, cleML, dalML, denML, detML, gbML, houML, indML, jaxML, kcML, lacML, larML, miaML, minML, neML, noML, nygML, nyjML, oakML, phiML, sfML, seaML, pitML, tbML, tenML,wasML]
statLists["Over"] = [ariO, atlO, balO, bufO,carO, chiO, cinO, cleO, dalO, denO, detO, gbO, houO, indO, jaxO, kcO, lacO, larO, miaO, minO, neO, noO, nygO, nyjO, oakO, phiO, sfO, seaO, pitO, tbO, tenO,wasO]
statLists["Under"] = [ariU, atlU, balU, bufU,carU, chiU, cinU, cleU, dalU, denU, detU, gbU, houU, indU, jaxU, kcU, lacU, larU, miaU, minU, neU, noU, nygU, nyjU, oakU, phiU, sfU, seaU, pitU, tbU, tenU,wasU]
statLists["Solo Over"] = [ariSoloO, atlSoloO, balSoloO, bufSoloO,carSoloO, chiSoloO, cinSoloO, cleSoloO, dalSoloO, denSoloO, detSoloO, gbSoloO, houSoloO, indSoloO, jaxSoloO, kcSoloO, lacSoloO, larSoloO, miaSoloO, minSoloO, neSoloO, noSoloO, nygSoloO, nyjSoloO, oakSoloO, phiSoloO, sfSoloO, seaSoloO, pitSoloO, tbSoloO, tenSoloO,wasSoloO]
statLists["Solo Under"] = [ariSoloU, atlSoloU, balSoloU, bufSoloU,carSoloU, chiSoloU, cinSoloU, cleSoloU, dalSoloU, denSoloU, detSoloU, gbSoloU, houSoloU, indSoloU, jaxSoloU, kcSoloU, lacSoloU, larSoloU, miaSoloU, minSoloU, neSoloU, noSoloU, nygSoloU, nyjSoloU, oakSoloU, phiSoloU, sfSoloU, seaSoloU, pitSoloU, tbSoloU, tenSoloU,wasSoloU]
statLists["Halftime ATS"] = [ariHalftime, atlHalftime, balHalftime, bufHalftime,carHalftime, chiHalftime, cinHalftime, cleHalftime, dalHalftime, denHalftime, detHalftime, gbHalftime, houHalftime, indHalftime, jaxHalftime, kcHalftime, lacHalftime, larHalftime, miaHalftime, minHalftime, neHalftime, noHalftime, nygHalftime, nyjHalftime, oakHalftime, phiHalftime, sfHalftime, seaHalftime, pitHalftime, tbHalftime, tenHalftime,wasHalftime]
statLists["Halftime Over"] = [ariHalftimeO, atlHalftimeO, balHalftimeO, bufHalftimeO,carHalftimeO, chiHalftimeO, cinHalftimeO, cleHalftimeO, dalHalftimeO, denHalftimeO, detHalftimeO, gbHalftimeO, houHalftimeO, indHalftimeO, jaxHalftimeO, kcHalftimeO, lacHalftimeO, larHalftimeO, miaHalftimeO, minHalftimeO, neHalftimeO, noHalftimeO, nygHalftimeO, nyjHalftimeO, oakHalftimeO, phiHalftimeO, sfHalftimeO, seaHalftimeO, pitHalftimeO, tbHalftimeO, tenHalftimeO,wasHalftimeO]
statLists["Halftime Under"] = [ariHalftimeU, atlHalftimeU, balHalftimeU, bufHalftimeU,carHalftimeU, chiHalftimeU, cinHalftimeU, cleHalftimeU, dalHalftimeU, denHalftimeU, detHalftimeU, gbHalftimeU, houHalftimeU, indHalftimeU, jaxHalftimeU, kcHalftimeU, lacHalftimeU, larHalftimeU, miaHalftimeU, minHalftimeU, neHalftimeU, noHalftimeU, nygHalftimeU, nyjHalftimeU, oakHalftimeU, phiHalftimeU, sfHalftimeU, seaHalftimeU, pitHalftimeU, tbHalftimeU, tenHalftimeU,wasHalftimeU]
statLists["1Q ATS"] = [ari1Q, atl1Q, bal1Q, buf1Q,car1Q, chi1Q, cin1Q, cle1Q, dal1Q, den1Q, det1Q, gb1Q, hou1Q, ind1Q, jax1Q, kc1Q, lac1Q, lar1Q, mia1Q, min1Q, ne1Q, no1Q, nyg1Q, nyj1Q, oak1Q, phi1Q, sf1Q, sea1Q, pit1Q, tb1Q, ten1Q,was1Q]
statLists["1Q Over"] = [ari1QO, atl1QO, bal1QO, buf1QO,car1QO, chi1QO, cin1QO, cle1QO, dal1QO, den1QO, det1QO, gb1QO, hou1QO, ind1QO, jax1QO, kc1QO, lac1QO, lar1QO, mia1QO, min1QO, ne1QO, no1QO, nyg1QO, nyj1QO, oak1QO, phi1QO, sf1QO, sea1QO, pit1QO, tb1QO, ten1QO,was1QO]
statLists["1Q Under"] = [ari1QUnder, atl1QUnder, bal1QUnder, buf1QUnder,car1QUnder, chi1QUnder, cin1QUnder, cle1QUnder, dal1QUnder, den1QUnder, det1QUnder, gb1QUnder, hou1QUnder, ind1QUnder, jax1QUnder, kc1QUnder, lac1QUnder, lar1QUnder, mia1QUnder, min1QUnder, ne1QUnder, no1QUnder, nyg1QUnder, nyj1QUnder, oak1QUnder, phi1QUnder, sf1QUnder, sea1QUnder, pit1QUnder, tb1QUnder, ten1QUnder,was1QUnder]
statLists["2Q ATS"] = [ari2Q, atl2Q, bal2Q, buf2Q,car2Q, chi2Q, cin2Q, cle2Q, dal2Q, den2Q, det2Q, gb2Q, hou2Q, ind2Q, jax2Q, kc2Q, lac2Q, lar2Q, mia2Q, min2Q, ne2Q, no2Q, nyg2Q, nyj2Q, oak2Q, phi2Q, sf2Q, sea2Q, pit2Q, tb2Q, ten2Q,was2Q]
statLists["2Q Over"] = [ari2QO, atl2QO, bal2QO, buf2QO,car2QO, chi2QO, cin2QO, cle2QO, dal2QO, den2QO, det2QO, gb2QO, hou2QO, ind2QO, jax2QO, kc2QO, lac2QO, lar2QO, mia2QO, min2QO, ne2QO, no2QO, nyg2QO, nyj2QO, oak2QO, phi2QO, sf2QO, sea2QO, pit2QO, tb2QO, ten2QO,was2QO]
statLists["2Q Under"] = [ari2QUnder, atl2QUnder, bal2QUnder, buf2QUnder,car2QUnder, chi2QUnder, cin2QUnder, cle2QUnder, dal2QUnder, den2QUnder, det2QUnder, gb2QUnder, hou2QUnder, ind2QUnder, jax2QUnder, kc2QUnder, lac2QUnder, lar2QUnder, mia2QUnder, min2QUnder, ne2QUnder, no2QUnder, nyg2QUnder, nyj2QUnder, oak2QUnder, phi2QUnder, sf2QUnder, sea2QUnder, pit2QUnder, tb2QUnder, ten2QUnder,was2QUnder]
statLists["3Q ATS"] = [ari3Q, atl3Q, bal3Q, buf3Q,car3Q, chi3Q, cin3Q, cle3Q, dal3Q, den3Q, det3Q, gb3Q, hou3Q, ind3Q, jax3Q, kc3Q, lac3Q, lar3Q, mia3Q, min3Q, ne3Q, no3Q, nyg3Q, nyj3Q, oak3Q, phi3Q, sf3Q, sea3Q, pit3Q, tb3Q, ten3Q,was3Q]
statLists["3Q Over"] = [ari3QO, atl3QO, bal3QO, buf3QO,car3QO, chi3QO, cin3QO, cle3QO, dal3QO, den3QO, det3QO, gb3QO, hou3QO, ind3QO, jax3QO, kc3QO, lac3QO, lar3QO, mia3QO, min3QO, ne3QO, no3QO, nyg3QO, nyj3QO, oak3QO, phi3QO, sf3QO, sea3QO, pit3QO, tb3QO, ten3QO,was3QO]
statLists["3Q Under"] = [ari3QUnder, atl3QUnder, bal3QUnder, buf3QUnder,car3QUnder, chi3QUnder, cin3QUnder, cle3QUnder, dal3QUnder, den3QUnder, det3QUnder, gb3QUnder, hou3QUnder, ind3QUnder, jax3QUnder, kc3QUnder, lac3QUnder, lar3QUnder, mia3QUnder, min3QUnder, ne3QUnder, no3QUnder, nyg3QUnder, nyj3QUnder, oak3QUnder, phi3QUnder, sf3QUnder, sea3QUnder, pit3QUnder, tb3QUnder, ten3QUnder,was3QUnder]
statLists["4Q ATS"] = [ari4Q, atl4Q, bal4Q, buf4Q,car4Q, chi4Q, cin4Q, cle4Q, dal4Q, den4Q, det4Q, gb4Q, hou4Q, ind4Q, jax4Q, kc4Q, lac4Q, lar4Q, mia4Q, min4Q, ne4Q, no4Q, nyg4Q, nyj4Q, oak4Q, phi4Q, sf4Q, sea4Q, pit4Q, tb4Q, ten4Q,was4Q]
statLists["4Q Over"] = [ari4QO, atl4QO, bal4QO, buf4QO,car4QO, chi4QO, cin4QO, cle4QO, dal4QO, den4QO, det4QO, gb4QO, hou4QO, ind4QO, jax4QO, kc4QO, lac4QO, lar4QO, mia4QO, min4QO, ne4QO, no4QO, nyg4QO, nyj4QO, oak4QO, phi4QO, sf4QO, sea4QO, pit4QO, tb4QO, ten4QO,was4QO]
statLists["4Q Under"] = [ari4QUnder, atl4QUnder, bal4QUnder, buf4QUnder,car4QUnder, chi4QUnder, cin4QUnder, cle4QUnder, dal4QUnder, den4QUnder, det4QUnder, gb4QUnder, hou4QUnder, ind4QUnder, jax4QUnder, kc4QUnder, lac4QUnder, lar4QUnder, mia4QUnder, min4QUnder, ne4QUnder, no4QUnder, nyg4QUnder, nyj4QUnder, oak4QUnder, phi4QUnder, sf4QUnder, sea4QUnder, pit4QUnder, tb4QUnder, ten4QUnder,was4QUnder]


  // Stat index clicked by user is logged
  var statIndex = selectObj.selectedIndex;

  // Value of stat index is logged
  var statValue = selectObj.options[statIndex].value;

  // Actual number is retrieved from statList
  stat = statLists[statValue]

  // Remove extra characters extracted from back-end
  finalstat = stat[index - 1]

  finalstat = String(finalstat).replace(/[',()]/g, "");


  // HTML Element that has stat % passed through to front-end user


if (finalstat.includes("%")) {

  document.getElementById("stat").innerHTML = "This happens " + finalstat + " of the time";
  document.getElementById("stat").style.opacity = "1";

} else {

  document.getElementById("stat").innerHTML = "This happens " + finalstat + "% of the time";
  document.getElementById("stat").style.opacity = "1";

}
}

$(document).ready(function() {
    $('.Dropdown').select2({
      width: 'resolve',
});
});
