//<![CDATA[
// array of possible teams in the same order as they appear in the team selection list
var teamLists = new Array(30)
teamLists["empty"] = ["Select a Stat"];
teamLists["Atlanta Hawks"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under", "1Q ATS", "1Q Over", "1Q Under", "2Q ATS", "2Q Over", "2Q Under", "3Q ATS", "3Q Over", "3Q Under", "4Q ATS", "4Q Over", "4Q Under"];
teamLists["Boston Celtics"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under", "1Q ATS", "1Q Over", "1Q Under", "2Q ATS", "2Q Over", "2Q Under", "3Q ATS", "3Q Over", "3Q Under", "4Q ATS", "4Q Over", "4Q Under"];
teamLists["Brooklyn Nets"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under", "1Q ATS", "1Q Over", "1Q Under", "2Q ATS", "2Q Over", "2Q Under", "3Q ATS", "3Q Over", "3Q Under", "4Q ATS", "4Q Over", "4Q Under"];
teamLists["Charlotte Hornets"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under", "1Q ATS", "1Q Over", "1Q Under", "2Q ATS", "2Q Over", "2Q Under", "3Q ATS", "3Q Over", "3Q Under", "4Q ATS", "4Q Over", "4Q Under"];
teamLists["Chicago Bulls"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under", "1Q ATS", "1Q Over", "1Q Under", "2Q ATS", "2Q Over", "2Q Under", "3Q ATS", "3Q Over", "3Q Under", "4Q ATS", "4Q Over", "4Q Under"];
teamLists["Cleveland Cavaliers"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under", "1Q ATS", "1Q Over", "1Q Under", "2Q ATS", "2Q Over", "2Q Under", "3Q ATS", "3Q Over", "3Q Under", "4Q ATS", "4Q Over", "4Q Under"];
teamLists["Dallas Mavericks"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under", "1Q ATS", "1Q Over", "1Q Under", "2Q ATS", "2Q Over", "2Q Under", "3Q ATS", "3Q Over", "3Q Under", "4Q ATS", "4Q Over", "4Q Under"];
teamLists["Denver Nuggets"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under", "1Q ATS", "1Q Over", "1Q Under", "2Q ATS", "2Q Over", "2Q Under", "3Q ATS", "3Q Over", "3Q Under", "4Q ATS", "4Q Over", "4Q Under"];
teamLists["Detroit Pistons"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under", "1Q ATS", "1Q Over", "1Q Under", "2Q ATS", "2Q Over", "2Q Under", "3Q ATS", "3Q Over", "3Q Under", "4Q ATS", "4Q Over", "4Q Under"];
teamLists["Golden State Warriors"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under", "1Q ATS", "1Q Over", "1Q Under", "2Q ATS", "2Q Over", "2Q Under", "3Q ATS", "3Q Over", "3Q Under", "4Q ATS", "4Q Over", "4Q Under"];
teamLists["Houston Rockets"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under", "1Q ATS", "1Q Over", "1Q Under", "2Q ATS", "2Q Over", "2Q Under", "3Q ATS", "3Q Over", "3Q Under", "4Q ATS", "4Q Over", "4Q Under"];
teamLists["Indiana Pacers"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under", "1Q ATS", "1Q Over", "1Q Under", "2Q ATS", "2Q Over", "2Q Under", "3Q ATS", "3Q Over", "3Q Under", "4Q ATS", "4Q Over", "4Q Under"];
teamLists["Los Angeles Clippers"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under", "1Q ATS", "1Q Over", "1Q Under", "2Q ATS", "2Q Over", "2Q Under", "3Q ATS", "3Q Over", "3Q Under", "4Q ATS", "4Q Over", "4Q Under"];
teamLists["Los Angeles Lakers"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under", "1Q ATS", "1Q Over", "1Q Under", "2Q ATS", "2Q Over", "2Q Under", "3Q ATS", "3Q Over", "3Q Under", "4Q ATS", "4Q Over", "4Q Under"];
teamLists["Memphis Grizzlies"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under", "1Q ATS", "1Q Over", "1Q Under", "2Q ATS", "2Q Over", "2Q Under", "3Q ATS", "3Q Over", "3Q Under", "4Q ATS", "4Q Over", "4Q Under"];
teamLists["Miami Heat"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under", "1Q ATS", "1Q Over", "1Q Under", "2Q ATS", "2Q Over", "2Q Under", "3Q ATS", "3Q Over", "3Q Under", "4Q ATS", "4Q Over", "4Q Under"];
teamLists["Milwaukee Bucks"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under", "1Q ATS", "1Q Over", "1Q Under", "2Q ATS", "2Q Over", "2Q Under", "3Q ATS", "3Q Over", "3Q Under", "4Q ATS", "4Q Over", "4Q Under"];
teamLists["Minnesota Timberwolves"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under", "1Q ATS", "1Q Over", "1Q Under", "2Q ATS", "2Q Over", "2Q Under", "3Q ATS", "3Q Over", "3Q Under", "4Q ATS", "4Q Over", "4Q Under"];
teamLists["New Orleans Pelicans"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under", "1Q ATS", "1Q Over", "1Q Under", "2Q ATS", "2Q Over", "2Q Under", "3Q ATS", "3Q Over", "3Q Under", "4Q ATS", "4Q Over", "4Q Under"];
teamLists["New York Knicks"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under", "1Q ATS", "1Q Over", "1Q Under", "2Q ATS", "2Q Over", "2Q Under", "3Q ATS", "3Q Over", "3Q Under", "4Q ATS", "4Q Over", "4Q Under"];
teamLists["Oklahoma City Thunder"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under", "1Q ATS", "1Q Over", "1Q Under", "2Q ATS", "2Q Over", "2Q Under", "3Q ATS", "3Q Over", "3Q Under", "4Q ATS", "4Q Over", "4Q Under"];
teamLists["Orlando Magic"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under", "1Q ATS", "1Q Over", "1Q Under", "2Q ATS", "2Q Over", "2Q Under", "3Q ATS", "3Q Over", "3Q Under", "4Q ATS", "4Q Over", "4Q Under"];
teamLists["Philadelphia 76ers"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under", "1Q ATS", "1Q Over", "1Q Under", "2Q ATS", "2Q Over", "2Q Under", "3Q ATS", "3Q Over", "3Q Under", "4Q ATS", "4Q Over", "4Q Under"];
teamLists["Phoenix Suns"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under", "1Q ATS", "1Q Over", "1Q Under", "2Q ATS", "2Q Over", "2Q Under", "3Q ATS", "3Q Over", "3Q Under", "4Q ATS", "4Q Over", "4Q Under"];
teamLists["Portland Trail Blazers"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under", "1Q ATS", "1Q Over", "1Q Under", "2Q ATS", "2Q Over", "2Q Under", "3Q ATS", "3Q Over", "3Q Under", "4Q ATS", "4Q Over", "4Q Under"];
teamLists["Sacramento Kings"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under", "1Q ATS", "1Q Over", "1Q Under", "2Q ATS", "2Q Over", "2Q Under", "3Q ATS", "3Q Over", "3Q Under", "4Q ATS", "4Q Over", "4Q Under"];
teamLists["San Antonio Spurs"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under", "1Q ATS", "1Q Over", "1Q Under", "2Q ATS", "2Q Over", "2Q Under", "3Q ATS", "3Q Over", "3Q Under", "4Q ATS", "4Q Over", "4Q Under"];
teamLists["Toronto Raptors"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under", "1Q ATS", "1Q Over", "1Q Under", "2Q ATS", "2Q Over", "2Q Under", "3Q ATS", "3Q Over", "3Q Under", "4Q ATS", "4Q Over", "4Q Under"];
teamLists["Utah Jazz"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under", "1Q ATS", "1Q Over", "1Q Under", "2Q ATS", "2Q Over", "2Q Under", "3Q ATS", "3Q Over", "3Q Under", "4Q ATS", "4Q Over", "4Q Under"];
teamLists["Washington Wizards"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under", "1Q ATS", "1Q Over", "1Q Under", "2Q ATS", "2Q Over", "2Q Under", "3Q ATS", "3Q Over", "3Q Under", "4Q ATS", "4Q Over", "4Q Under"];
/* teamChange() is called from the onchange event of a select element.
* param selectObj - the select object which fired the on change event.
*/

function teamChange(selectObj) {
// get the index of the selected option
  index = selectObj.selectedIndex;
// get the value of the selected option
var which = selectObj.options[index].value;
// use the selected option value to retrieve the list of items from the countryLists array
tList = teamLists[which];
// get the country select element via its known id
var tSelect = document.getElementById("stat-change");
// remove the current options from the country select
var len = tSelect.options.length;

while (tSelect.options.length > 0) {
tSelect.remove(0);
}
var newOption;
// create new options
for (var i=0; i<tList.length; i++) {
newOption = document.createElement("option");
newOption.value = tList[i];  // assumes option string and value are the same
newOption.text=tList[i];
// add the new option
try {
tSelect.add(newOption);  // this will fail in DOM browsers but is needed for IE
}
catch (e) {
tSelect.appendChild(newOption);
}
}
}

function statChange(selectObj) {

  var atlCover = document.getElementById("ATLCover").innerHTML;
  var atlML = document.getElementById("ATLML").innerHTML;
  var atlO = document.getElementById("ATLO").innerHTML;
  var atlO = atlO.replace(/[',()]/g, "");
  var atlSoloO = document.getElementById("ATLSoloO").innerHTML;
  var atlSoloO = atlSoloO.replace(/[',()]/g, "");
  var atlHalftime = document.getElementById("ATLHalftime").innerHTML;
  var atlHalftimeO = document.getElementById("ATLHalftimeO").innerHTML;
  var atlHalftimeO = atlHalftimeO.replace(/[',()]/g, "");
  var atl1Q = document.getElementById("ATL1Q").innerHTML;
  var atl1QO = document.getElementById("ATL1QOver").innerHTML;
  var atl1QO = atl1QO.replace(/[',()]/g, "");
  var atl2Q = document.getElementById("ATL2Q").innerHTML;
  var atl2QO = document.getElementById("ATL2QOver").innerHTML;
  var atl2QO = atl2Q.replace(/[',()]/g, "");
  var atl3Q = document.getElementById("ATL3Q").innerHTML;
  var atl3QO = document.getElementById("ATL3QOver").innerHTML;
  var atl3QO = atl3QO.replace(/[',()]/g, "");
  var atl4Q = document.getElementById("ATL4Q").innerHTML;
  var atl4QO = document.getElementById("ATL4QOver").innerHTML;
  var atl4QO = atl4QO.replace(/[',()]/g, "");

  var bosCover = document.getElementById("BOSCover").innerHTML;
  var bosML = document.getElementById("BOSML").innerHTML;
  var bosO = document.getElementById("BOSO").innerHTML;
  var bosO = bosO.replace(/[',()]/g, "");
  var bosSoloO = document.getElementById("BOSSoloO").innerHTML;
  var bosSoloO = bosSoloO.replace(/[',()]/g, "");
  var bosHalftime = document.getElementById("BOSHalftime").innerHTML;
  var bosHalftimeO = document.getElementById("BOSHalftimeO").innerHTML;
  var bosHalftimeO = bosHalftimeO.replace(/[',()]/g, "");
  var bos1Q = document.getElementById("BOS1Q").innerHTML;
  var bos1QO = document.getElementById("BOS1QOver").innerHTML;
  var bos1QO = bos1QO.replace(/[',()]/g, "");
  var bos2Q = document.getElementById("BOS2Q").innerHTML;
  var bos2QO = document.getElementById("BOS2QOver").innerHTML;
  var bos2QO = bos2Q.replace(/[',()]/g, "");
  var bos3Q = document.getElementById("BOS3Q").innerHTML;
  var bos3QO = document.getElementById("BOS3QOver").innerHTML;
  var bos3QO = bos3QO.replace(/[',()]/g, "");
  var bos4Q = document.getElementById("BOS4Q").innerHTML;
  var bos4QO = document.getElementById("BOS4QOver").innerHTML;
  var bos4QO = bos4QO.replace(/[',()]/g, "");

  var bknCover = document.getElementById("BKNCover").innerHTML;
  var bknML = document.getElementById("BKNML").innerHTML;
  var bknO = document.getElementById("BKNO").innerHTML;
  var bknO = bknO.replace(/[',()]/g, "");
  var bknSoloO = document.getElementById("BKNSoloO").innerHTML;
  var bknSoloO = bknSoloO.replace(/[',()]/g, "");
  var bknHalftime = document.getElementById("BKNHalftime").innerHTML;
  var bknHalftimeO = document.getElementById("BKNHalftimeO").innerHTML;
  var bknHalftimeO = bknHalftimeO.replace(/[',()]/g, "");
  var bkn1Q = document.getElementById("BKN1Q").innerHTML;
  var bkn1QO = document.getElementById("BKN1QOver").innerHTML;
  var bkn1QO = bkn1QO.replace(/[',()]/g, "");
  var bkn2Q = document.getElementById("BKN2Q").innerHTML;
  var bkn2QO = document.getElementById("BKN2QOver").innerHTML;
  var bkn2QO = bkn2Q.replace(/[',()]/g, "");
  var bkn3Q = document.getElementById("BKN3Q").innerHTML;
  var bkn3QO = document.getElementById("BKN3QOver").innerHTML;
  var bkn3QO = bkn3QO.replace(/[',()]/g, "");
  var bkn4Q = document.getElementById("BKN4Q").innerHTML;
  var bkn4QO = document.getElementById("BKN4QOver").innerHTML;
  var bkn4QO = bkn4QO.replace(/[',()]/g, "");

  var chaCover = document.getElementById("CHACover").innerHTML;
  var chaML = document.getElementById("CHAML").innerHTML;
  var chaO = document.getElementById("CHAO").innerHTML;
  var chaO = chaO.replace(/[',()]/g, "");
  var chaSoloO = document.getElementById("CHASoloO").innerHTML;
  var chaSoloO = chaSoloO.replace(/[',()]/g, "");
  var chaHalftime = document.getElementById("CHAHalftime").innerHTML;
  var chaHalftimeO = document.getElementById("CHAHalftimeO").innerHTML;
  var chaHalftimeO = chaHalftimeO.replace(/[',()]/g, "");
  var cha1Q = document.getElementById("CHA1Q").innerHTML;
  var cha1QO = document.getElementById("CHA1QOver").innerHTML;
  var cha1QO = cha1QO.replace(/[',()]/g, "");
  var cha2Q = document.getElementById("CHA2Q").innerHTML;
  var cha2QO = document.getElementById("CHA2QOver").innerHTML;
  var cha2QO = cha2Q.replace(/[',()]/g, "");
  var cha3Q = document.getElementById("CHA3Q").innerHTML;
  var cha3QO = document.getElementById("CHA3QOver").innerHTML;
  var cha3QO = cha3QO.replace(/[',()]/g, "");
  var cha4Q = document.getElementById("CHA4Q").innerHTML;
  var cha4QO = document.getElementById("CHA4QOver").innerHTML;
  var cha4QO = cha4QO.replace(/[',()]/g, "");

  var chiCover = document.getElementById("CHICover").innerHTML;
  var chiML = document.getElementById("CHIML").innerHTML;
  var chiO = document.getElementById("CHIO").innerHTML;
  var chiO = chiO.replace(/[',()]/g, "");
  var chiSoloO = document.getElementById("CHISoloO").innerHTML;
  var chiSoloO = chiSoloO.replace(/[',()]/g, "");
  var chiHalftime = document.getElementById("CHIHalftime").innerHTML;
  var chiHalftimeO = document.getElementById("CHIHalftimeO").innerHTML;
  var chiHalftimeO = chiHalftimeO.replace(/[',()]/g, "");
  var chi1Q = document.getElementById("CHI1Q").innerHTML;
  var chi1QO = document.getElementById("CHI1QOver").innerHTML;
  var chi1QO = chi1QO.replace(/[',()]/g, "");
  var chi2Q = document.getElementById("CHI2Q").innerHTML;
  var chi2QO = document.getElementById("CHI2QOver").innerHTML;
  var chi2QO = chi2Q.replace(/[',()]/g, "");
  var chi3Q = document.getElementById("CHI3Q").innerHTML;
  var chi3QO = document.getElementById("CHI3QOver").innerHTML;
  var chi3QO = chi3QO.replace(/[',()]/g, "");
  var chi4Q = document.getElementById("CHI4Q").innerHTML;
  var chi4QO = document.getElementById("CHI4QOver").innerHTML;
  var chi4QO = chi4QO.replace(/[',()]/g, "");

  var cleCover = document.getElementById("CLECover").innerHTML;
  var cleML = document.getElementById("CLEML").innerHTML;
  var cleO = document.getElementById("CLEO").innerHTML;
  var cleO = cleO.replace(/[',()]/g, "");
  var cleSoloO = document.getElementById("CLESoloO").innerHTML;
  var cleSoloO = cleSoloO.replace(/[',()]/g, "");
  var cleHalftime = document.getElementById("CLEHalftime").innerHTML;
  var cleHalftimeO = document.getElementById("CLEHalftimeO").innerHTML;
  var cleHalftimeO = cleHalftimeO.replace(/[',()]/g, "");
  var cle1Q = document.getElementById("CLE1Q").innerHTML;
  var cle1QO = document.getElementById("CLE1QOver").innerHTML;
  var cle1QO = cle1QO.replace(/[',()]/g, "");
  var cle2Q = document.getElementById("CLE2Q").innerHTML;
  var cle2QO = document.getElementById("CLE2QOver").innerHTML;
  var cle2QO = cle2Q.replace(/[',()]/g, "");
  var cle3Q = document.getElementById("CLE3Q").innerHTML;
  var cle3QO = document.getElementById("CLE3QOver").innerHTML;
  var cle3QO = cle3QO.replace(/[',()]/g, "");
  var cle4Q = document.getElementById("CLE4Q").innerHTML;
  var cle4QO = document.getElementById("CLE4QOver").innerHTML;
  var cle4QO = cle4QO.replace(/[',()]/g, "");

  var dalCover = document.getElementById("DALCover").innerHTML;
  var dalML = document.getElementById("DALML").innerHTML;
  var dalO = document.getElementById("DALO").innerHTML;
  var dalO = dalO.replace(/[',()]/g, "");
  var dalSoloO = document.getElementById("DALSoloO").innerHTML;
  var dalSoloO = dalSoloO.replace(/[',()]/g, "");
  var dalHalftime = document.getElementById("DALHalftime").innerHTML;
  var dalHalftimeO = document.getElementById("DALHalftimeO").innerHTML;
  var dalHalftimeO = dalHalftimeO.replace(/[',()]/g, "");
  var dal1Q = document.getElementById("DAL1Q").innerHTML;
  var dal1QO = document.getElementById("DAL1QOver").innerHTML;
  var dal1QO = dal1QO.replace(/[',()]/g, "");
  var dal2Q = document.getElementById("DAL2Q").innerHTML;
  var dal2QO = document.getElementById("DAL2QOver").innerHTML;
  var dal2QO = dal2Q.replace(/[',()]/g, "");
  var dal3Q = document.getElementById("DAL3Q").innerHTML;
  var dal3QO = document.getElementById("DAL3QOver").innerHTML;
  var dal3QO = dal3QO.replace(/[',()]/g, "");
  var dal4Q = document.getElementById("DAL4Q").innerHTML;
  var dal4QO = document.getElementById("DAL4QOver").innerHTML;
  var dal4QO = dal4QO.replace(/[',()]/g, "");

  var denCover = document.getElementById("DENCover").innerHTML;
  var denML = document.getElementById("DENML").innerHTML;
  var denO = document.getElementById("DENO").innerHTML;
  var denO = denO.replace(/[',()]/g, "");
  var denSoloO = document.getElementById("DENSoloO").innerHTML;
  var denSoloO = denSoloO.replace(/[',()]/g, "");
  var denHalftime = document.getElementById("DENHalftime").innerHTML;
  var denHalftimeO = document.getElementById("DENHalftimeO").innerHTML;
  var denHalftimeO = denHalftimeO.replace(/[',()]/g, "");
  var den1Q = document.getElementById("DEN1Q").innerHTML;
  var den1QO = document.getElementById("DEN1QOver").innerHTML;
  var den1QO = den1QO.replace(/[',()]/g, "");
  var den2Q = document.getElementById("DEN2Q").innerHTML;
  var den2QO = document.getElementById("DEN2QOver").innerHTML;
  var den2QO = den2Q.replace(/[',()]/g, "");
  var den3Q = document.getElementById("DEN3Q").innerHTML;
  var den3QO = document.getElementById("DEN3QOver").innerHTML;
  var den3QO = den3QO.replace(/[',()]/g, "");
  var den4Q = document.getElementById("DEN4Q").innerHTML;
  var den4QO = document.getElementById("DEN4QOver").innerHTML;
  var den4QO = den4QO.replace(/[',()]/g, "");

  var detCover = document.getElementById("DETCover").innerHTML;
  var detML = document.getElementById("DETML").innerHTML;
  var detO = document.getElementById("DETO").innerHTML;
  var detO = detO.replace(/[',()]/g, "");
  var detSoloO = document.getElementById("DETSoloO").innerHTML;
  var detSoloO = detSoloO.replace(/[',()]/g, "");
  var detHalftime = document.getElementById("DETHalftime").innerHTML;
  var detHalftimeO = document.getElementById("DETHalftimeO").innerHTML;
  var detHalftimeO = detHalftimeO.replace(/[',()]/g, "");
  var det1Q = document.getElementById("DET1Q").innerHTML;
  var det1QO = document.getElementById("DET1QOver").innerHTML;
  var det1QO = det1QO.replace(/[',()]/g, "");
  var det2Q = document.getElementById("DET2Q").innerHTML;
  var det2QO = document.getElementById("DET2QOver").innerHTML;
  var det2QO = det2Q.replace(/[',()]/g, "");
  var det3Q = document.getElementById("DET3Q").innerHTML;
  var det3QO = document.getElementById("DET3QOver").innerHTML;
  var det3QO = det3QO.replace(/[',()]/g, "");
  var det4Q = document.getElementById("DET4Q").innerHTML;
  var det4QO = document.getElementById("DET4QOver").innerHTML;
  var det4QO = det4QO.replace(/[',()]/g, "");

  var gswCover = document.getElementById("GSWCover").innerHTML;
  var gswML = document.getElementById("GSWML").innerHTML;
  var gswO = document.getElementById("GSWO").innerHTML;
  var gswO = gswO.replace(/[',()]/g, "");
  var gswSoloO = document.getElementById("GSWSoloO").innerHTML;
  var gswSoloO = gswSoloO.replace(/[',()]/g, "");
  var gswHalftime = document.getElementById("GSWHalftime").innerHTML;
  var gswHalftimeO = document.getElementById("GSWHalftimeO").innerHTML;
  var gswHalftimeO = gswHalftimeO.replace(/[',()]/g, "");
  var gsw1Q = document.getElementById("GSW1Q").innerHTML;
  var gsw1QO = document.getElementById("GSW1QOver").innerHTML;
  var gsw1QO = gsw1QO.replace(/[',()]/g, "");
  var gsw2Q = document.getElementById("GSW2Q").innerHTML;
  var gsw2QO = document.getElementById("GSW2QOver").innerHTML;
  var gsw2QO = gsw2Q.replace(/[',()]/g, "");
  var gsw3Q = document.getElementById("GSW3Q").innerHTML;
  var gsw3QO = document.getElementById("GSW3QOver").innerHTML;
  var gsw3QO = gsw3QO.replace(/[',()]/g, "");
  var gsw4Q = document.getElementById("GSW4Q").innerHTML;
  var gsw4QO = document.getElementById("GSW4QOver").innerHTML;
  var gsw4QO = gsw4QO.replace(/[',()]/g, "");

  var houCover = document.getElementById("HOUCover").innerHTML;
  var houML = document.getElementById("HOUML").innerHTML;
  var houO = document.getElementById("HOUO").innerHTML;
  var houO = houO.replace(/[',()]/g, "");
  var houSoloO = document.getElementById("HOUSoloO").innerHTML;
  var houSoloO = houSoloO.replace(/[',()]/g, "");
  var houHalftime = document.getElementById("HOUHalftime").innerHTML;
  var houHalftimeO = document.getElementById("HOUHalftimeO").innerHTML;
  var houHalftimeO = houHalftimeO.replace(/[',()]/g, "");
  var hou1Q = document.getElementById("HOU1Q").innerHTML;
  var hou1QO = document.getElementById("HOU1QOver").innerHTML;
  var hou1QO = hou1QO.replace(/[',()]/g, "");
  var hou2Q = document.getElementById("HOU2Q").innerHTML;
  var hou2QO = document.getElementById("HOU2QOver").innerHTML;
  var hou2QO = hou2Q.replace(/[',()]/g, "");
  var hou3Q = document.getElementById("HOU3Q").innerHTML;
  var hou3QO = document.getElementById("HOU3QOver").innerHTML;
  var hou3QO = hou3QO.replace(/[',()]/g, "");
  var hou4Q = document.getElementById("HOU4Q").innerHTML;
  var hou4QO = document.getElementById("HOU4QOver").innerHTML;
  var hou4QO = hou4QO.replace(/[',()]/g, "");

  var indCover = document.getElementById("INDCover").innerHTML;
  var indML = document.getElementById("INDML").innerHTML;
  var indO = document.getElementById("INDO").innerHTML;
  var indO = indO.replace(/[',()]/g, "");
  var indSoloO = document.getElementById("INDSoloO").innerHTML;
  var indSoloO = indSoloO.replace(/[',()]/g, "");
  var indHalftime = document.getElementById("INDHalftime").innerHTML;
  var indHalftimeO = document.getElementById("INDHalftimeO").innerHTML;
  var indHalftimeO = indHalftimeO.replace(/[',()]/g, "");
  var ind1Q = document.getElementById("IND1Q").innerHTML;
  var ind1QO = document.getElementById("IND1QOver").innerHTML;
  var ind1QO = ind1QO.replace(/[',()]/g, "");
  var ind2Q = document.getElementById("IND2Q").innerHTML;
  var ind2QO = document.getElementById("IND2QOver").innerHTML;
  var ind2QO = ind2Q.replace(/[',()]/g, "");
  var ind3Q = document.getElementById("IND3Q").innerHTML;
  var ind3QO = document.getElementById("IND3QOver").innerHTML;
  var ind3QO = ind3QO.replace(/[',()]/g, "");
  var ind4Q = document.getElementById("IND4Q").innerHTML;
  var ind4QO = document.getElementById("IND4QOver").innerHTML;
  var ind4QO = ind4QO.replace(/[',()]/g, "");

  var lacCover = document.getElementById("LACCover").innerHTML;
  var lacML = document.getElementById("LACML").innerHTML;
  var lacO = document.getElementById("LACO").innerHTML;
  var lacO = lacO.replace(/[',()]/g, "");
  var lacSoloO = document.getElementById("LACSoloO").innerHTML;
  var lacSoloO = lacSoloO.replace(/[',()]/g, "");
  var lacHalftime = document.getElementById("LACHalftime").innerHTML;
  var lacHalftimeO = document.getElementById("LACHalftimeO").innerHTML;
  var lacHalftimeO = lacHalftimeO.replace(/[',()]/g, "");
  var lac1Q = document.getElementById("LAC1Q").innerHTML;
  var lac1QO = document.getElementById("LAC1QOver").innerHTML;
  var lac1QO = lac1QO.replace(/[',()]/g, "");
  var lac2Q = document.getElementById("LAC2Q").innerHTML;
  var lac2QO = document.getElementById("LAC2QOver").innerHTML;
  var lac2QO = lac2Q.replace(/[',()]/g, "");
  var lac3Q = document.getElementById("LAC3Q").innerHTML;
  var lac3QO = document.getElementById("LAC3QOver").innerHTML;
  var lac3QO = lac3QO.replace(/[',()]/g, "");
  var lac4Q = document.getElementById("LAC4Q").innerHTML;
  var lac4QO = document.getElementById("LAC4QOver").innerHTML;
  var lac4QO = lac4QO.replace(/[',()]/g, "");

  var lalCover = document.getElementById("LALCover").innerHTML;
  var lalML = document.getElementById("LALML").innerHTML;
  var lalO = document.getElementById("LALO").innerHTML;
  var lalO = lalO.replace(/[',()]/g, "");
  var lalSoloO = document.getElementById("LALSoloO").innerHTML;
  var lalSoloO = lalSoloO.replace(/[',()]/g, "");
  var lalHalftime = document.getElementById("LALHalftime").innerHTML;
  var lalHalftimeO = document.getElementById("LALHalftimeO").innerHTML;
  var lalHalftimeO = lalHalftimeO.replace(/[',()]/g, "");
  var lal1Q = document.getElementById("LAL1Q").innerHTML;
  var lal1QO = document.getElementById("LAL1QOver").innerHTML;
  var lal1QO = lal1QO.replace(/[',()]/g, "");
  var lal2Q = document.getElementById("LAL2Q").innerHTML;
  var lal2QO = document.getElementById("LAL2QOver").innerHTML;
  var lal2QO = lal2Q.replace(/[',()]/g, "");
  var lal3Q = document.getElementById("LAL3Q").innerHTML;
  var lal3QO = document.getElementById("LAL3QOver").innerHTML;
  var lal3QO = lal3QO.replace(/[',()]/g, "");
  var lal4Q = document.getElementById("LAL4Q").innerHTML;
  var lal4QO = document.getElementById("LAL4QOver").innerHTML;
  var lal4QO = lal4QO.replace(/[',()]/g, "");

  var memCover = document.getElementById("MEMCover").innerHTML;
  var memML = document.getElementById("MEMML").innerHTML;
  var memO = document.getElementById("MEMO").innerHTML;
  var memO = memO.replace(/[',()]/g, "");
  var memSoloO = document.getElementById("MEMSoloO").innerHTML;
  var memSoloO = memSoloO.replace(/[',()]/g, "");
  var memHalftime = document.getElementById("MEMHalftime").innerHTML;
  var memHalftimeO = document.getElementById("MEMHalftimeO").innerHTML;
  var memHalftimeO = memHalftimeO.replace(/[',()]/g, "");
  var mem1Q = document.getElementById("MEM1Q").innerHTML;
  var mem1QO = document.getElementById("MEM1QOver").innerHTML;
  var mem1QO = mem1QO.replace(/[',()]/g, "");
  var mem2Q = document.getElementById("MEM2Q").innerHTML;
  var mem2QO = document.getElementById("MEM2QOver").innerHTML;
  var mem2QO = mem2Q.replace(/[',()]/g, "");
  var mem3Q = document.getElementById("MEM3Q").innerHTML;
  var mem3QO = document.getElementById("MEM3QOver").innerHTML;
  var mem3QO = mem3QO.replace(/[',()]/g, "");
  var mem4Q = document.getElementById("MEM4Q").innerHTML;
  var mem4QO = document.getElementById("MEM4QOver").innerHTML;
  var mem4QO = mem4QO.replace(/[',()]/g, "");

  var miaCover = document.getElementById("MIACover").innerHTML;
  var miaML = document.getElementById("MIAML").innerHTML;
  var miaO = document.getElementById("MIAO").innerHTML;
  var miaO = miaO.replace(/[',()]/g, "");
  var miaSoloO = document.getElementById("MIASoloO").innerHTML;
  var miaSoloO = miaSoloO.replace(/[',()]/g, "");
  var miaHalftime = document.getElementById("MIAHalftime").innerHTML;
  var miaHalftimeO = document.getElementById("MIAHalftimeO").innerHTML;
  var miaHalftimeO = miaHalftimeO.replace(/[',()]/g, "");
  var mia1Q = document.getElementById("MIA1Q").innerHTML;
  var mia1QO = document.getElementById("MIA1QOver").innerHTML;
  var mia1QO = mia1QO.replace(/[',()]/g, "");
  var mia2Q = document.getElementById("MIA2Q").innerHTML;
  var mia2QO = document.getElementById("MIA2QOver").innerHTML;
  var mia2QO = mia2Q.replace(/[',()]/g, "");
  var mia3Q = document.getElementById("MIA3Q").innerHTML;
  var mia3QO = document.getElementById("MIA3QOver").innerHTML;
  var mia3QO = mia3QO.replace(/[',()]/g, "");
  var mia4Q = document.getElementById("MIA4Q").innerHTML;
  var mia4QO = document.getElementById("MIA4QOver").innerHTML;
  var mia4QO = mia4QO.replace(/[',()]/g, "");

  var milCover = document.getElementById("MILCover").innerHTML;
  var milML = document.getElementById("MILML").innerHTML;
  var milO = document.getElementById("MILO").innerHTML;
  var milO = milO.replace(/[',()]/g, "");
  var milSoloO = document.getElementById("MILSoloO").innerHTML;
  var milSoloO = milSoloO.replace(/[',()]/g, "");
  var milHalftime = document.getElementById("MILHalftime").innerHTML;
  var milHalftimeO = document.getElementById("MILHalftimeO").innerHTML;
  var milHalftimeO = milHalftimeO.replace(/[',()]/g, "");
  var mil1Q = document.getElementById("MIL1Q").innerHTML;
  var mil1QO = document.getElementById("MIL1QOver").innerHTML;
  var mil1QO = mil1QO.replace(/[',()]/g, "");
  var mil2Q = document.getElementById("MIL2Q").innerHTML;
  var mil2QO = document.getElementById("MIL2QOver").innerHTML;
  var mil2QO = mil2Q.replace(/[',()]/g, "");
  var mil3Q = document.getElementById("MIL3Q").innerHTML;
  var mil3QO = document.getElementById("MIL3QOver").innerHTML;
  var mil3QO = mil3QO.replace(/[',()]/g, "");
  var mil4Q = document.getElementById("MIL4Q").innerHTML;
  var mil4QO = document.getElementById("MIL4QOver").innerHTML;
  var mil4QO = mil4QO.replace(/[',()]/g, "");

  var minCover = document.getElementById("MINCover").innerHTML;
  var minML = document.getElementById("MINML").innerHTML;
  var minO = document.getElementById("MINO").innerHTML;
  var minO = minO.replace(/[',()]/g, "");
  var minSoloO = document.getElementById("MINSoloO").innerHTML;
  var minSoloO = minSoloO.replace(/[',()]/g, "");
  var minHalftime = document.getElementById("MINHalftime").innerHTML;
  var minHalftimeO = document.getElementById("MINHalftimeO").innerHTML;
  var minHalftimeO = minHalftimeO.replace(/[',()]/g, "");
  var min1Q = document.getElementById("MIN1Q").innerHTML;
  var min1QO = document.getElementById("MIN1QOver").innerHTML;
  var min1QO = min1QO.replace(/[',()]/g, "");
  var min2Q = document.getElementById("MIN2Q").innerHTML;
  var min2QO = document.getElementById("MIN2QOver").innerHTML;
  var min2QO = min2Q.replace(/[',()]/g, "");
  var min3Q = document.getElementById("MIN3Q").innerHTML;
  var min3QO = document.getElementById("MIN3QOver").innerHTML;
  var min3QO = min3QO.replace(/[',()]/g, "");
  var min4Q = document.getElementById("MIN4Q").innerHTML;
  var min4QO = document.getElementById("MIN4QOver").innerHTML;
  var min4QO = min4QO.replace(/[',()]/g, "");

  var nopCover = document.getElementById("NOPCover").innerHTML;
  var nopML = document.getElementById("NOPML").innerHTML;
  var nopO = document.getElementById("NOPO").innerHTML;
  var nopO = nopO.replace(/[',()]/g, "");
  var nopSoloO = document.getElementById("NOPSoloO").innerHTML;
  var nopSoloO = nopSoloO.replace(/[',()]/g, "");
  var nopHalftime = document.getElementById("NOPHalftime").innerHTML;
  var nopHalftimeO = document.getElementById("NOPHalftimeO").innerHTML;
  var nopHalftimeO = nopHalftimeO.replace(/[',()]/g, "");
  var nop1Q = document.getElementById("NOP1Q").innerHTML;
  var nop1QO = document.getElementById("NOP1QOver").innerHTML;
  var nop1QO = nop1QO.replace(/[',()]/g, "");
  var nop2Q = document.getElementById("NOP2Q").innerHTML;
  var nop2QO = document.getElementById("NOP2QOver").innerHTML;
  var nop2QO = nop2Q.replace(/[',()]/g, "");
  var nop3Q = document.getElementById("NOP3Q").innerHTML;
  var nop3QO = document.getElementById("NOP3QOver").innerHTML;
  var nop3QO = nop3QO.replace(/[',()]/g, "");
  var nop4Q = document.getElementById("NOP4Q").innerHTML;
  var nop4QO = document.getElementById("NOP4QOver").innerHTML;
  var nop4QO = nop4QO.replace(/[',()]/g, "");

  var nykCover = document.getElementById("NYKCover").innerHTML;
  var nykML = document.getElementById("NYKML").innerHTML;
  var nykO = document.getElementById("NYKO").innerHTML;
  var nykO = nykO.replace(/[',()]/g, "");
  var nykSoloO = document.getElementById("NYKSoloO").innerHTML;
  var nykSoloO = nykSoloO.replace(/[',()]/g, "");
  var nykHalftime = document.getElementById("NYKHalftime").innerHTML;
  var nykHalftimeO = document.getElementById("NYKHalftimeO").innerHTML;
  var nykHalftimeO = nykHalftimeO.replace(/[',()]/g, "");
  var nyk1Q = document.getElementById("NYK1Q").innerHTML;
  var nyk1QO = document.getElementById("NYK1QOver").innerHTML;
  var nyk1QO = nyk1QO.replace(/[',()]/g, "");
  var nyk2Q = document.getElementById("NYK2Q").innerHTML;
  var nyk2QO = document.getElementById("NYK2QOver").innerHTML;
  var nyk2QO = nyk2Q.replace(/[',()]/g, "");
  var nyk3Q = document.getElementById("NYK3Q").innerHTML;
  var nyk3QO = document.getElementById("NYK3QOver").innerHTML;
  var nyk3QO = nyk3QO.replace(/[',()]/g, "");
  var nyk4Q = document.getElementById("NYK4Q").innerHTML;
  var nyk4QO = document.getElementById("NYK4QOver").innerHTML;
  var nyk4QO = nyk4QO.replace(/[',()]/g, "");

  var okcCover = document.getElementById("OKCCover").innerHTML;
  var okcML = document.getElementById("OKCML").innerHTML;
  var okcO = document.getElementById("OKCO").innerHTML;
  var okcO = okcO.replace(/[',()]/g, "");
  var okcSoloO = document.getElementById("OKCSoloO").innerHTML;
  var okcSoloO = okcSoloO.replace(/[',()]/g, "");
  var okcHalftime = document.getElementById("OKCHalftime").innerHTML;
  var okcHalftimeO = document.getElementById("OKCHalftimeO").innerHTML;
  var okcHalftimeO = okcHalftimeO.replace(/[',()]/g, "");
  var okc1Q = document.getElementById("OKC1Q").innerHTML;
  var okc1QO = document.getElementById("OKC1QOver").innerHTML;
  var okc1QO = okc1QO.replace(/[',()]/g, "");
  var okc2Q = document.getElementById("OKC2Q").innerHTML;
  var okc2QO = document.getElementById("OKC2QOver").innerHTML;
  var okc2QO = okc2Q.replace(/[',()]/g, "");
  var okc3Q = document.getElementById("OKC3Q").innerHTML;
  var okc3QO = document.getElementById("OKC3QOver").innerHTML;
  var okc3QO = okc3QO.replace(/[',()]/g, "");
  var okc4Q = document.getElementById("OKC4Q").innerHTML;
  var okc4QO = document.getElementById("OKC4QOver").innerHTML;
  var okc4QO = okc4QO.replace(/[',()]/g, "");

  var orlCover = document.getElementById("ORLCover").innerHTML;
  var orlML = document.getElementById("ORLML").innerHTML;
  var orlO = document.getElementById("ORLO").innerHTML;
  var orlO = orlO.replace(/[',()]/g, "");
  var orlSoloO = document.getElementById("ORLSoloO").innerHTML;
  var orlSoloO = orlSoloO.replace(/[',()]/g, "");
  var orlHalftime = document.getElementById("ORLHalftime").innerHTML;
  var orlHalftimeO = document.getElementById("ORLHalftimeO").innerHTML;
  var orlHalftimeO = orlHalftimeO.replace(/[',()]/g, "");
  var orl1Q = document.getElementById("ORL1Q").innerHTML;
  var orl1QO = document.getElementById("ORL1QOver").innerHTML;
  var orl1QO = orl1QO.replace(/[',()]/g, "");
  var orl2Q = document.getElementById("ORL2Q").innerHTML;
  var orl2QO = document.getElementById("ORL2QOver").innerHTML;
  var orl2QO = orl2Q.replace(/[',()]/g, "");
  var orl3Q = document.getElementById("ORL3Q").innerHTML;
  var orl3QO = document.getElementById("ORL3QOver").innerHTML;
  var orl3QO = orl3QO.replace(/[',()]/g, "");
  var orl4Q = document.getElementById("ORL4Q").innerHTML;
  var orl4QO = document.getElementById("ORL4QOver").innerHTML;
  var orl4QO = orl4QO.replace(/[',()]/g, "");

  var phiCover = document.getElementById("PHICover").innerHTML;
  var phiML = document.getElementById("PHIML").innerHTML;
  var phiO = document.getElementById("PHIO").innerHTML;
  var phiO = phiO.replace(/[',()]/g, "");
  var phiSoloO = document.getElementById("PHISoloO").innerHTML;
  var phiSoloO = phiSoloO.replace(/[',()]/g, "");
  var phiHalftime = document.getElementById("PHIHalftime").innerHTML;
  var phiHalftimeO = document.getElementById("PHIHalftimeO").innerHTML;
  var phiHalftimeO = phiHalftimeO.replace(/[',()]/g, "");
  var phi1Q = document.getElementById("PHI1Q").innerHTML;
  var phi1QO = document.getElementById("PHI1QOver").innerHTML;
  var phi1QO = phi1QO.replace(/[',()]/g, "");
  var phi2Q = document.getElementById("PHI2Q").innerHTML;
  var phi2QO = document.getElementById("PHI2QOver").innerHTML;
  var phi2QO = phi2Q.replace(/[',()]/g, "");
  var phi3Q = document.getElementById("PHI3Q").innerHTML;
  var phi3QO = document.getElementById("PHI3QOver").innerHTML;
  var phi3QO = phi3QO.replace(/[',()]/g, "");
  var phi4Q = document.getElementById("PHI4Q").innerHTML;
  var phi4QO = document.getElementById("PHI4QOver").innerHTML;
  var phi4QO = phi4QO.replace(/[',()]/g, "");

  var phxCover = document.getElementById("PHXCover").innerHTML;
  var phxML = document.getElementById("PHXML").innerHTML;
  var phxO = document.getElementById("PHXO").innerHTML;
  var phxO = phxO.replace(/[',()]/g, "");
  var phxSoloO = document.getElementById("PHXSoloO").innerHTML;
  var phxSoloO = phxSoloO.replace(/[',()]/g, "");
  var phxHalftime = document.getElementById("PHXHalftime").innerHTML;
  var phxHalftimeO = document.getElementById("PHXHalftimeO").innerHTML;
  var phxHalftimeO = phxHalftimeO.replace(/[',()]/g, "");
  var phx1Q = document.getElementById("PHX1Q").innerHTML;
  var phx1QO = document.getElementById("PHX1QOver").innerHTML;
  var phx1QO = phx1QO.replace(/[',()]/g, "");
  var phx2Q = document.getElementById("PHX2Q").innerHTML;
  var phx2QO = document.getElementById("PHX2QOver").innerHTML;
  var phx2QO = phx2Q.replace(/[',()]/g, "");
  var phx3Q = document.getElementById("PHX3Q").innerHTML;
  var phx3QO = document.getElementById("PHX3QOver").innerHTML;
  var phx3QO = phx3QO.replace(/[',()]/g, "");
  var phx4Q = document.getElementById("PHX4Q").innerHTML;
  var phx4QO = document.getElementById("PHX4QOver").innerHTML;
  var phx4QO = phx4QO.replace(/[',()]/g, "");

  var porCover = document.getElementById("PORCover").innerHTML;
  var porML = document.getElementById("PORML").innerHTML;
  var porO = document.getElementById("PORO").innerHTML;
  var porO = porO.replace(/[',()]/g, "");
  var porSoloO = document.getElementById("PORSoloO").innerHTML;
  var porSoloO = porSoloO.replace(/[',()]/g, "");
  var porHalftime = document.getElementById("PORHalftime").innerHTML;
  var porHalftimeO = document.getElementById("PORHalftimeO").innerHTML;
  var porHalftimeO = porHalftimeO.replace(/[',()]/g, "");
  var por1Q = document.getElementById("POR1Q").innerHTML;
  var por1QO = document.getElementById("POR1QOver").innerHTML;
  var por1QO = por1QO.replace(/[',()]/g, "");
  var por2Q = document.getElementById("POR2Q").innerHTML;
  var por2QO = document.getElementById("POR2QOver").innerHTML;
  var por2QO = por2Q.replace(/[',()]/g, "");
  var por3Q = document.getElementById("POR3Q").innerHTML;
  var por3QO = document.getElementById("POR3QOver").innerHTML;
  var por3QO = por3QO.replace(/[',()]/g, "");
  var por4Q = document.getElementById("POR4Q").innerHTML;
  var por4QO = document.getElementById("POR4QOver").innerHTML;
  var por4QO = por4QO.replace(/[',()]/g, "");

  var sacCover = document.getElementById("SACCover").innerHTML;
  var sacML = document.getElementById("SACML").innerHTML;
  var sacO = document.getElementById("SACO").innerHTML;
  var sacO = sacO.replace(/[',()]/g, "");
  var sacSoloO = document.getElementById("SACSoloO").innerHTML;
  var sacSoloO = sacSoloO.replace(/[',()]/g, "");
  var sacHalftime = document.getElementById("SACHalftime").innerHTML;
  var sacHalftimeO = document.getElementById("SACHalftimeO").innerHTML;
  var sacHalftimeO = sacHalftimeO.replace(/[',()]/g, "");
  var sac1Q = document.getElementById("SAC1Q").innerHTML;
  var sac1QO = document.getElementById("SAC1QOver").innerHTML;
  var sac1QO = sac1QO.replace(/[',()]/g, "");
  var sac2Q = document.getElementById("SAC2Q").innerHTML;
  var sac2QO = document.getElementById("SAC2QOver").innerHTML;
  var sac2QO = sac2Q.replace(/[',()]/g, "");
  var sac3Q = document.getElementById("SAC3Q").innerHTML;
  var sac3QO = document.getElementById("SAC3QOver").innerHTML;
  var sac3QO = sac3QO.replace(/[',()]/g, "");
  var sac4Q = document.getElementById("SAC4Q").innerHTML;
  var sac4QO = document.getElementById("SAC4QOver").innerHTML;
  var sac4QO = sac4QO.replace(/[',()]/g, "");

  var sasCover = document.getElementById("SASCover").innerHTML;
  var sasML = document.getElementById("SASML").innerHTML;
  var sasO = document.getElementById("SASO").innerHTML;
  var sasO = sasO.replace(/[',()]/g, "");
  var sasSoloO = document.getElementById("SASSoloO").innerHTML;
  var sasSoloO = sasSoloO.replace(/[',()]/g, "");
  var sasHalftime = document.getElementById("SASHalftime").innerHTML;
  var sasHalftimeO = document.getElementById("SASHalftimeO").innerHTML;
  var sasHalftimeO = sasHalftimeO.replace(/[',()]/g, "");
  var sas1Q = document.getElementById("SAS1Q").innerHTML;
  var sas1QO = document.getElementById("SAS1QOver").innerHTML;
  var sas1QO = sas1QO.replace(/[',()]/g, "");
  var sas2Q = document.getElementById("SAS2Q").innerHTML;
  var sas2QO = document.getElementById("SAS2QOver").innerHTML;
  var sas2QO = sas2Q.replace(/[',()]/g, "");
  var sas3Q = document.getElementById("SAS3Q").innerHTML;
  var sas3QO = document.getElementById("SAS3QOver").innerHTML;
  var sas3QO = sas3QO.replace(/[',()]/g, "");
  var sas4Q = document.getElementById("SAS4Q").innerHTML;
  var sas4QO = document.getElementById("SAS4QOver").innerHTML;
  var sas4QO = sas4QO.replace(/[',()]/g, "");

  var torCover = document.getElementById("TORCover").innerHTML;
  var torML = document.getElementById("TORML").innerHTML;
  var torO = document.getElementById("TORO").innerHTML;
  var torO = torO.replace(/[',()]/g, "");
  var torSoloO = document.getElementById("TORSoloO").innerHTML;
  var torSoloO = torSoloO.replace(/[',()]/g, "");
  var torHalftime = document.getElementById("TORHalftime").innerHTML;
  var torHalftimeO = document.getElementById("TORHalftimeO").innerHTML;
  var torHalftimeO = torHalftimeO.replace(/[',()]/g, "");
  var tor1Q = document.getElementById("TOR1Q").innerHTML;
  var tor1QO = document.getElementById("TOR1QOver").innerHTML;
  var tor1QO = tor1QO.replace(/[',()]/g, "");
  var tor2Q = document.getElementById("TOR2Q").innerHTML;
  var tor2QO = document.getElementById("TOR2QOver").innerHTML;
  var tor2QO = tor2Q.replace(/[',()]/g, "");
  var tor3Q = document.getElementById("TOR3Q").innerHTML;
  var tor3QO = document.getElementById("TOR3QOver").innerHTML;
  var tor3QO = tor3QO.replace(/[',()]/g, "");
  var tor4Q = document.getElementById("TOR4Q").innerHTML;
  var tor4QO = document.getElementById("TOR4QOver").innerHTML;
  var tor4QO = tor4QO.replace(/[',()]/g, "");

  var utaCover = document.getElementById("UTACover").innerHTML;
  var utaML = document.getElementById("UTAML").innerHTML;
  var utaO = document.getElementById("UTAO").innerHTML;
  var utaO = utaO.replace(/[',()]/g, "");
  var utaSoloO = document.getElementById("UTASoloO").innerHTML;
  var utaSoloO = utaSoloO.replace(/[',()]/g, "");
  var utaHalftime = document.getElementById("UTAHalftime").innerHTML;
  var utaHalftimeO = document.getElementById("UTAHalftimeO").innerHTML;
  var utaHalftimeO = utaHalftimeO.replace(/[',()]/g, "");
  var uta1Q = document.getElementById("UTA1Q").innerHTML;
  var uta1QO = document.getElementById("UTA1QOver").innerHTML;
  var uta1QO = uta1QO.replace(/[',()]/g, "");
  var uta2Q = document.getElementById("UTA2Q").innerHTML;
  var uta2QO = document.getElementById("UTA2QOver").innerHTML;
  var uta2QO = uta2Q.replace(/[',()]/g, "");
  var uta3Q = document.getElementById("UTA3Q").innerHTML;
  var uta3QO = document.getElementById("UTA3QOver").innerHTML;
  var uta3QO = uta3QO.replace(/[',()]/g, "");
  var uta4Q = document.getElementById("UTA4Q").innerHTML;
  var uta4QO = document.getElementById("UTA4QOver").innerHTML;
  var uta4QO = uta4QO.replace(/[',()]/g, "");

  var wasCover = document.getElementById("WASCover").innerHTML;
  var wasML = document.getElementById("WASML").innerHTML;
  var wasO = document.getElementById("WASO").innerHTML;
  var wasO = wasO.replace(/[',()]/g, "");
  var wasSoloO = document.getElementById("WASSoloO").innerHTML;
  var wasSoloO = wasSoloO.replace(/[',()]/g, "");
  var wasHalftime = document.getElementById("WASHalftime").innerHTML;
  var wasHalftimeO = document.getElementById("WASHalftimeO").innerHTML;
  var wasHalftimeO = wasHalftimeO.replace(/[',()]/g, "");
  var was1Q = document.getElementById("WAS1Q").innerHTML;
  var was1QO = document.getElementById("WAS1QOver").innerHTML;
  var was1QO = was1QO.replace(/[',()]/g, "");
  var was2Q = document.getElementById("WAS2Q").innerHTML;
  var was2QO = document.getElementById("WAS2QOver").innerHTML;
  var was2QO = was2Q.replace(/[',()]/g, "");
  var was3Q = document.getElementById("WAS3Q").innerHTML;
  var was3QO = document.getElementById("WAS3QOver").innerHTML;
  var was3QO = was3QO.replace(/[',()]/g, "");
  var was4Q = document.getElementById("WAS4Q").innerHTML;
  var was4QO = document.getElementById("WAS4QOver").innerHTML;
  var was4QO = was4QO.replace(/[',()]/g, "");

  // How to get the under of a team

  // turn the variable into an integer

  var atlUnder = parseFloat(atlO, 10);
  var atlSoloUnder = parseFloat(atlSoloO,10);
  var atlHalftimeUnder = parseFloat(atlHalftimeO,10);
  var atl1QU = parseFloat(atl1QO,10);
  var atl2QU = parseFloat(atl2QO,10);
  var atl3QU = parseFloat(atl3QO,10);
  var atl4QU = parseFloat(atl4QO,10);

  var bosUnder = parseFloat(bosO, 10);
  var bosSoloUnder = parseFloat(bosSoloO,10);
  var bosHalftimeUnder = parseFloat(bosHalftimeO,10);
  var bos1QU = parseFloat(bos1QO,10);
  var bos2QU = parseFloat(bos2QO,10);
  var bos3QU = parseFloat(bos3QO,10);
  var bos4QU = parseFloat(bos4QO,10);

  var bknUnder = parseFloat(bknO, 10);
  var bknSoloUnder = parseFloat(bknSoloO,10);
  var bknHalftimeUnder = parseFloat(bknHalftimeO,10);
  var bkn1QU = parseFloat(bkn1QO,10);
  var bkn2QU = parseFloat(bkn2QO,10);
  var bkn3QU = parseFloat(bkn3QO,10);
  var bkn4QU = parseFloat(bkn4QO,10);

  var chaUnder = parseFloat(chaO, 10);
  var chaSoloUnder = parseFloat(chaSoloO,10);
  var chaHalftimeUnder = parseFloat(chaHalftimeO,10);
  var cha1QU = parseFloat(cha1QO,10);
  var cha2QU = parseFloat(cha2QO,10);
  var cha3QU = parseFloat(cha3QO,10);
  var cha4QU = parseFloat(cha4QO,10);

  var chiUnder = parseFloat(chiO, 10);
  var chiSoloUnder = parseFloat(chiSoloO,10);
  var chiHalftimeUnder = parseFloat(chiHalftimeO,10);
  var chi1QU = parseFloat(chi1QO,10);
  var chi2QU = parseFloat(chi2QO,10);
  var chi3QU = parseFloat(chi3QO,10);
  var chi4QU = parseFloat(chi4QO,10);

  var cleUnder = parseFloat(cleO, 10);
  var cleSoloUnder = parseFloat(cleSoloO,10);
  var cleHalftimeUnder = parseFloat(cleHalftimeO,10);
  var cle1QU = parseFloat(cle1QO,10);
  var cle2QU = parseFloat(cle2QO,10);
  var cle3QU = parseFloat(cle3QO,10);
  var cle4QU = parseFloat(cle4QO,10);

  var dalUnder = parseFloat(dalO, 10);
  var dalSoloUnder = parseFloat(dalSoloO,10);
  var dalHalftimeUnder = parseFloat(dalHalftimeO,10);
  var dal1QU = parseFloat(dal1QO,10);
  var dal2QU = parseFloat(dal2QO,10);
  var dal3QU = parseFloat(dal3QO,10);
  var dal4QU = parseFloat(dal4QO,10);

  var denUnder = parseFloat(denO, 10);
  var denSoloUnder = parseFloat(denSoloO,10);
  var denHalftimeUnder = parseFloat(denHalftimeO,10);
  var den1QU = parseFloat(den1QO,10);
  var den2QU = parseFloat(den2QO,10);
  var den3QU = parseFloat(den3QO,10);
  var den4QU = parseFloat(den4QO,10);

  var detUnder = parseFloat(detO, 10);
  var detSoloUnder = parseFloat(detSoloO,10);
  var detHalftimeUnder = parseFloat(detHalftimeO,10);
  var det1QU = parseFloat(det1QO,10);
  var det2QU = parseFloat(det2QO,10);
  var det3QU = parseFloat(det3QO,10);
  var det4QU = parseFloat(det4QO,10);

  var gswUnder = parseFloat(gswO, 10);
  var gswSoloUnder = parseFloat(gswSoloO,10);
  var gswHalftimeUnder = parseFloat(gswHalftimeO,10);
  var gsw1QU = parseFloat(gsw1QO,10);
  var gsw2QU = parseFloat(gsw2QO,10);
  var gsw3QU = parseFloat(gsw3QO,10);
  var gsw4QU = parseFloat(gsw4QO,10);

  var houUnder = parseFloat(houO, 10);
  var houSoloUnder = parseFloat(houSoloO,10);
  var houHalftimeUnder = parseFloat(houHalftimeO,10);
  var hou1QU = parseFloat(hou1QO,10);
  var hou2QU = parseFloat(hou2QO,10);
  var hou3QU = parseFloat(hou3QO,10);
  var hou4QU = parseFloat(hou4QO,10);

  var indUnder = parseFloat(indO, 10);
  var indSoloUnder = parseFloat(indSoloO,10);
  var indHalftimeUnder = parseFloat(indHalftimeO,10);
  var ind1QU = parseFloat(ind1QO,10);
  var ind2QU = parseFloat(ind2QO,10);
  var ind3QU = parseFloat(ind3QO,10);
  var ind4QU = parseFloat(ind4QO,10);

  var lacUnder = parseFloat(lacO, 10);
  var lacSoloUnder = parseFloat(lacSoloO,10);
  var lacHalftimeUnder = parseFloat(lacHalftimeO,10);
  var lac1QU = parseFloat(lac1QO,10);
  var lac2QU = parseFloat(lac2QO,10);
  var lac3QU = parseFloat(lac3QO,10);
  var lac4QU = parseFloat(lac4QO,10);

  var lalUnder = parseFloat(lalO, 10);
  var lalSoloUnder = parseFloat(lalSoloO,10);
  var lalHalftimeUnder = parseFloat(lalHalftimeO,10);
  var lal1QU = parseFloat(lal1QO,10);
  var lal2QU = parseFloat(lal2QO,10);
  var lal3QU = parseFloat(lal3QO,10);
  var lal4QU = parseFloat(lal4QO,10);

  var memUnder = parseFloat(memO, 10);
  var memSoloUnder = parseFloat(memSoloO,10);
  var memHalftimeUnder = parseFloat(memHalftimeO,10);
  var mem1QU = parseFloat(mem1QO,10);
  var mem2QU = parseFloat(mem2QO,10);
  var mem3QU = parseFloat(mem3QO,10);
  var mem4QU = parseFloat(mem4QO,10);

  var miaUnder = parseFloat(miaO, 10);
  var miaSoloUnder = parseFloat(miaSoloO,10);
  var miaHalftimeUnder = parseFloat(miaHalftimeO,10);
  var mia1QU = parseFloat(mia1QO,10);
  var mia2QU = parseFloat(mia2QO,10);
  var mia3QU = parseFloat(mia3QO,10);
  var mia4QU = parseFloat(mia4QO,10);

  var milUnder = parseFloat(milO, 10);
  var milSoloUnder = parseFloat(milSoloO,10);
  var milHalftimeUnder = parseFloat(milHalftimeO,10);
  var mil1QU = parseFloat(mil1QO,10);
  var mil2QU = parseFloat(mil2QO,10);
  var mil3QU = parseFloat(mil3QO,10);
  var mil4QU = parseFloat(mil4QO,10);

  var minUnder = parseFloat(minO, 10);
  var minSoloUnder = parseFloat(minSoloO,10);
  var minHalftimeUnder = parseFloat(minHalftimeO,10);
  var min1QU = parseFloat(min1QO,10);
  var min2QU = parseFloat(min2QO,10);
  var min3QU = parseFloat(min3QO,10);
  var min4QU = parseFloat(min4QO,10);

  var nopUnder = parseFloat(nopO, 10);
  var nopSoloUnder = parseFloat(nopSoloO,10);
  var nopHalftimeUnder = parseFloat(nopHalftimeO,10);
  var nop1QU = parseFloat(nop1QO,10);
  var nop2QU = parseFloat(nop2QO,10);
  var nop3QU = parseFloat(nop3QO,10);
  var nop4QU = parseFloat(nop4QO,10);

  var nykUnder = parseFloat(nykO, 10);
  var nykSoloUnder = parseFloat(nykSoloO,10);
  var nykHalftimeUnder = parseFloat(nykHalftimeO,10);
  var nyk1QU = parseFloat(nyk1QO,10);
  var nyk2QU = parseFloat(nyk2QO,10);
  var nyk3QU = parseFloat(nyk3QO,10);
  var nyk4QU = parseFloat(nyk4QO,10);

  var okcUnder = parseFloat(okcO, 10);
  var okcSoloUnder = parseFloat(okcSoloO,10);
  var okcHalftimeUnder = parseFloat(okcHalftimeO,10);
  var okc1QU = parseFloat(okc1QO,10);
  var okc2QU = parseFloat(okc2QO,10);
  var okc3QU = parseFloat(okc3QO,10);
  var okc4QU = parseFloat(okc4QO,10);

  var orlUnder = parseFloat(orlO, 10);
  var orlSoloUnder = parseFloat(orlSoloO,10);
  var orlHalftimeUnder = parseFloat(orlHalftimeO,10);
  var orl1QU = parseFloat(orl1QO,10);
  var orl2QU = parseFloat(orl2QO,10);
  var orl3QU = parseFloat(orl3QO,10);
  var orl4QU = parseFloat(orl4QO,10);

  var phiUnder = parseFloat(phiO, 10);
  var phiSoloUnder = parseFloat(phiSoloO,10);
  var phiHalftimeUnder = parseFloat(phiHalftimeO,10);
  var phi1QU = parseFloat(phi1QO,10);
  var phi2QU = parseFloat(phi2QO,10);
  var phi3QU = parseFloat(phi3QO,10);
  var phi4QU = parseFloat(phi4QO,10);

  var phxUnder = parseFloat(phxO, 10);
  var phxSoloUnder = parseFloat(phxSoloO,10);
  var phxHalftimeUnder = parseFloat(phxHalftimeO,10);
  var phx1QU = parseFloat(phx1QO,10);
  var phx2QU = parseFloat(phx2QO,10);
  var phx3QU = parseFloat(phx3QO,10);
  var phx4QU = parseFloat(phx4QO,10);

  var porUnder = parseFloat(porO, 10);
  var porSoloUnder = parseFloat(porSoloO,10);
  var porHalftimeUnder = parseFloat(porHalftimeO,10);
  var por1QU = parseFloat(por1QO,10);
  var por2QU = parseFloat(por2QO,10);
  var por3QU = parseFloat(por3QO,10);
  var por4QU = parseFloat(por4QO,10);

  var sacUnder = parseFloat(sacO, 10);
  var sacSoloUnder = parseFloat(sacSoloO,10);
  var sacHalftimeUnder = parseFloat(sacHalftimeO,10);
  var sac1QU = parseFloat(sac1QO,10);
  var sac2QU = parseFloat(sac2QO,10);
  var sac3QU = parseFloat(sac3QO,10);
  var sac4QU = parseFloat(sac4QO,10);

  var sasUnder = parseFloat(sasO, 10);
  var sasSoloUnder = parseFloat(sasSoloO,10);
  var sasHalftimeUnder = parseFloat(sasHalftimeO,10);
  var sas1QU = parseFloat(sas1QO,10);
  var sas2QU = parseFloat(sas2QO,10);
  var sas3QU = parseFloat(sas3QO,10);
  var sas4QU = parseFloat(sas4QO,10);

  var torUnder = parseFloat(torO, 10);
  var torSoloUnder = parseFloat(torSoloO,10);
  var torHalftimeUnder = parseFloat(torHalftimeO,10);
  var tor1QU = parseFloat(tor1QO,10);
  var tor2QU = parseFloat(tor2QO,10);
  var tor3QU = parseFloat(tor3QO,10);
  var tor4QU = parseFloat(tor4QO,10);

  var utaUnder = parseFloat(utaO, 10);
  var utaSoloUnder = parseFloat(utaSoloO,10);
  var utaHalftimeUnder = parseFloat(utaHalftimeO,10);
  var uta1QU = parseFloat(uta1QO,10);
  var uta2QU = parseFloat(uta2QO,10);
  var uta3QU = parseFloat(uta3QO,10);
  var uta4QU = parseFloat(uta4QO,10);

  var wasUnder = parseFloat(wasO, 10);
  var wasSoloUnder = parseFloat(wasSoloO,10);
  var wasHalftimeUnder = parseFloat(wasHalftimeO,10);
  var was1QU = parseFloat(was1QO,10);
  var was2QU = parseFloat(was2QO,10);
  var was3QU = parseFloat(was3QO,10);
  var was4QU = parseFloat(was4QO,10);

  // Turn the over into under by subtracting by 100

  var atlU = 100 - atlUnder;
  var atlSoloU = 100 - atlSoloUnder;
  var atlHalftimeU = 100 - atlHalftimeUnder;
  var atl1QUnder = 100 - atl1QU;
  var atl2QUnder = 100 - atl2QU;
  var atl3QUnder = 100 - atl3QU;
  var atl4QUnder = 100 - atl4QU;

  var bosU = 100 - bosUnder;
  var bosSoloU = 100 - bosSoloUnder;
  var bosHalftimeU = 100 - bosHalftimeUnder;
  var bos1QUnder = 100 - bos1QU;
  var bos2QUnder = 100 - bos2QU;
  var bos3QUnder = 100 - bos3QU;
  var bos4QUnder = 100 - bos4QU;

  var bknU = 100 - bknUnder;
  var bknSoloU = 100 - bknSoloUnder;
  var bknHalftimeU = 100 - bknHalftimeUnder;
  var bkn1QUnder = 100 - bkn1QU;
  var bkn2QUnder = 100 - bkn2QU;
  var bkn3QUnder = 100 - bkn3QU;
  var bkn4QUnder = 100 - bkn4QU;

  var chaU = 100 - chaUnder;
  var chaSoloU = 100 - chaSoloUnder;
  var chaHalftimeU = 100 - chaHalftimeUnder;
  var cha1QUnder = 100 - cha1QU;
  var cha2QUnder = 100 - cha2QU;
  var cha3QUnder = 100 - cha3QU;
  var cha4QUnder = 100 - cha4QU;

  var chiU = 100 - chiUnder;
  var chiSoloU = 100 - chiSoloUnder;
  var chiHalftimeU = 100 - chiHalftimeUnder;
  var chi1QUnder = 100 - chi1QU;
  var chi2QUnder = 100 - chi2QU;
  var chi3QUnder = 100 - chi3QU;
  var chi4QUnder = 100 - chi4QU;

  var cleU = 100 - cleUnder;
  var cleSoloU = 100 - cleSoloUnder;
  var cleHalftimeU = 100 - cleHalftimeUnder;
  var cle1QUnder = 100 - cle1QU;
  var cle2QUnder = 100 - cle2QU;
  var cle3QUnder = 100 - cle3QU;
  var cle4QUnder = 100 - cle4QU;

  var dalU = 100 - dalUnder;
  var dalSoloU = 100 - dalSoloUnder;
  var dalHalftimeU = 100 - dalHalftimeUnder;
  var dal1QUnder = 100 - dal1QU;
  var dal2QUnder = 100 - dal2QU;
  var dal3QUnder = 100 - dal3QU;
  var dal4QUnder = 100 - dal4QU;

  var denU = 100 - denUnder;
  var denSoloU = 100 - denSoloUnder;
  var denHalftimeU = 100 - denHalftimeUnder;
  var den1QUnder = 100 - den1QU;
  var den2QUnder = 100 - den2QU;
  var den3QUnder = 100 - den3QU;
  var den4QUnder = 100 - den4QU;

  var detU = 100 - detUnder;
  var detSoloU = 100 - detSoloUnder;
  var detHalftimeU = 100 - detHalftimeUnder;
  var det1QUnder = 100 - det1QU;
  var det2QUnder = 100 - det2QU;
  var det3QUnder = 100 - det3QU;
  var det4QUnder = 100 - det4QU;

  var gswU = 100 - gswUnder;
  var gswSoloU = 100 - gswSoloUnder;
  var gswHalftimeU = 100 - gswHalftimeUnder;
  var gsw1QUnder = 100 - gsw1QU;
  var gsw2QUnder = 100 - gsw2QU;
  var gsw3QUnder = 100 - gsw3QU;
  var gsw4QUnder = 100 - gsw4QU;

  var houU = 100 - houUnder;
  var houSoloU = 100 - houSoloUnder;
  var houHalftimeU = 100 - houHalftimeUnder;
  var hou1QUnder = 100 - hou1QU;
  var hou2QUnder = 100 - hou2QU;
  var hou3QUnder = 100 - hou3QU;
  var hou4QUnder = 100 - hou4QU;

  var indU = 100 - indUnder;
  var indSoloU = 100 - indSoloUnder;
  var indHalftimeU = 100 - indHalftimeUnder;
  var ind1QUnder = 100 - ind1QU;
  var ind2QUnder = 100 - ind2QU;
  var ind3QUnder = 100 - ind3QU;
  var ind4QUnder = 100 - ind4QU;

  var lacU = 100 - lacUnder;
  var lacSoloU = 100 - lacSoloUnder;
  var lacHalftimeU = 100 - lacHalftimeUnder;
  var lac1QUnder = 100 - lac1QU;
  var lac2QUnder = 100 - lac2QU;
  var lac3QUnder = 100 - lac3QU;
  var lac4QUnder = 100 - lac4QU;

  var lalU = 100 - lalUnder;
  var lalSoloU = 100 - lalSoloUnder;
  var lalHalftimeU = 100 - lalHalftimeUnder;
  var lal1QUnder = 100 - lal1QU;
  var lal2QUnder = 100 - lal2QU;
  var lal3QUnder = 100 - lal3QU;
  var lal4QUnder = 100 - lal4QU;

  var memU = 100 - memUnder;
  var memSoloU = 100 - memSoloUnder;
  var memHalftimeU = 100 - memHalftimeUnder;
  var mem1QUnder = 100 - mem1QU;
  var mem2QUnder = 100 - mem2QU;
  var mem3QUnder = 100 - mem3QU;
  var mem4QUnder = 100 - mem4QU;

  var miaU = 100 - miaUnder;
  var miaSoloU = 100 - miaSoloUnder;
  var miaHalftimeU = 100 - miaHalftimeUnder;
  var mia1QUnder = 100 - mia1QU;
  var mia2QUnder = 100 - mia2QU;
  var mia3QUnder = 100 - mia3QU;
  var mia4QUnder = 100 - mia4QU;

  var milU = 100 - milUnder;
  var milSoloU = 100 - milSoloUnder;
  var milHalftimeU = 100 - milHalftimeUnder;
  var mil1QUnder = 100 - mil1QU;
  var mil2QUnder = 100 - mil2QU;
  var mil3QUnder = 100 - mil3QU;
  var mil4QUnder = 100 - mil4QU;

  var minU = 100 - minUnder;
  var minSoloU = 100 - minSoloUnder;
  var minHalftimeU = 100 - minHalftimeUnder;
  var min1QUnder = 100 - min1QU;
  var min2QUnder = 100 - min2QU;
  var min3QUnder = 100 - min3QU;
  var min4QUnder = 100 - min4QU;

  var nopU = 100 - nopUnder;
  var nopSoloU = 100 - nopSoloUnder;
  var nopHalftimeU = 100 - nopHalftimeUnder;
  var nop1QUnder = 100 - nop1QU;
  var nop2QUnder = 100 - nop2QU;
  var nop3QUnder = 100 - nop3QU;
  var nop4QUnder = 100 - nop4QU;

  var nykU = 100 - nykUnder;
  var nykSoloU = 100 - nykSoloUnder;
  var nykHalftimeU = 100 - nykHalftimeUnder;
  var nyk1QUnder = 100 - nyk1QU;
  var nyk2QUnder = 100 - nyk2QU;
  var nyk3QUnder = 100 - nyk3QU;
  var nyk4QUnder = 100 - nyk4QU;

  var okcU = 100 - okcUnder;
  var okcSoloU = 100 - okcSoloUnder;
  var okcHalftimeU = 100 - okcHalftimeUnder;
  var okc1QUnder = 100 - okc1QU;
  var okc2QUnder = 100 - okc2QU;
  var okc3QUnder = 100 - okc3QU;
  var okc4QUnder = 100 - okc4QU;

  var orlU = 100 - orlUnder;
  var orlSoloU = 100 - orlSoloUnder;
  var orlHalftimeU = 100 - orlHalftimeUnder;
  var orl1QUnder = 100 - orl1QU;
  var orl2QUnder = 100 - orl2QU;
  var orl3QUnder = 100 - orl3QU;
  var orl4QUnder = 100 - orl4QU;

  var phiU = 100 - phiUnder;
  var phiSoloU = 100 - phiSoloUnder;
  var phiHalftimeU = 100 - phiHalftimeUnder;
  var phi1QUnder = 100 - phi1QU;
  var phi2QUnder = 100 - phi2QU;
  var phi3QUnder = 100 - phi3QU;
  var phi4QUnder = 100 - phi4QU;

  var phxU = 100 - phxUnder;
  var phxSoloU = 100 - phxSoloUnder;
  var phxHalftimeU = 100 - phxHalftimeUnder;
  var phx1QUnder = 100 - phx1QU;
  var phx2QUnder = 100 - phx2QU;
  var phx3QUnder = 100 - phx3QU;
  var phx4QUnder = 100 - phx4QU;

  var porU = 100 - porUnder;
  var porSoloU = 100 - porSoloUnder;
  var porHalftimeU = 100 - porHalftimeUnder;
  var por1QUnder = 100 - por1QU;
  var por2QUnder = 100 - por2QU;
  var por3QUnder = 100 - por3QU;
  var por4QUnder = 100 - por4QU;

  var sacU = 100 - sacUnder;
  var sacSoloU = 100 - sacSoloUnder;
  var sacHalftimeU = 100 - sacHalftimeUnder;
  var sac1QUnder = 100 - sac1QU;
  var sac2QUnder = 100 - sac2QU;
  var sac3QUnder = 100 - sac3QU;
  var sac4QUnder = 100 - sac4QU;

  var sasU = 100 - sasUnder;
  var sasSoloU = 100 - sasSoloUnder;
  var sasHalftimeU = 100 - sasHalftimeUnder;
  var sas1QUnder = 100 - sas1QU;
  var sas2QUnder = 100 - sas2QU;
  var sas3QUnder = 100 - sas3QU;
  var sas4QUnder = 100 - sas4QU;

  var torU = 100 - torUnder;
  var torSoloU = 100 - torSoloUnder;
  var torHalftimeU = 100 - torHalftimeUnder;
  var tor1QUnder = 100 - tor1QU;
  var tor2QUnder = 100 - tor2QU;
  var tor3QUnder = 100 - tor3QU;
  var tor4QUnder = 100 - tor4QU;

  var utaU = 100 - utaUnder;
  var utaSoloU = 100 - utaSoloUnder;
  var utaHalftimeU = 100 - utaHalftimeUnder;
  var uta1QUnder = 100 - uta1QU;
  var uta2QUnder = 100 - uta2QU;
  var uta3QUnder = 100 - uta3QU;
  var uta4QUnder = 100 - uta4QU;

  var wasU = 100 - wasUnder;
  var wasSoloU = 100 - wasSoloUnder;
  var wasHalftimeU = 100 - wasHalftimeUnder;
  var was1QUnder = 100 - was1QU;
  var was2QUnder = 100 - was2QU;
  var was3QUnder = 100 - was3QU;
  var was4QUnder = 100 - was4QU;

  // Team stats in order by team index & stat index
  var statLists = new Array(21)
statLists["ATS"] = [atlCover, bosCover, bknCover, chaCover,chiCover, cleCover, dalCover, denCover, detCover, gswCover, houCover, indCover, lacCover, lalCover, memCover, miaCover, milCover, minCover, nopCover, nykCover, okcCover, orlCover, phiCover, phxCover, porCover, sacCover, sasCover, torCover, utaCover, wasCover]
statLists["ML"] = [atlML, bosML, bknML, chaML,chiML, cleML, dalML, denML, detML, gswML, houML, indML, lacML, lalML, memML, miaML, milML, minML, nopML, nykML, okcML, orlML, phiML, phxML, porML, sacML, sasML, torML, utaML, wasML]
statLists["Over"] = [atlO, bosO, bknO, chaO,chiO, cleO, dalO, denO, detO, gswO, houO, indO, lacO, lalO, memO, miaO, milO, minO, nopO, nykO, okcO, orlO, phiO, phxO, porO, sacO, sasO, torO, utaO, wasO]
statLists["Under"] = [atlU, bosU, bknU, chaU,chiU, cleU, dalU, denU, detU, gswU, houU, indU, lacU, lalU, memU, miaU, milU, minU, nopU, nykU, okcU, orlU, phiU, phxU, porU, sacU, sasU, torU, utaU, wasU]
statLists["Solo Over"] = [atlSoloO, bosSoloO, bknSoloO, chaSoloO,chiSoloO, cleSoloO, dalSoloO, denSoloO, detSoloO, gswSoloO, houSoloO, indSoloO, lacSoloO, lalSoloO, memSoloO, miaSoloO, milSoloO, minSoloO, nopSoloO, nykSoloO, okcSoloO, orlSoloO, phiSoloO, phxSoloO, porSoloO, sacSoloO, sasSoloO, torSoloO, utaSoloO, wasSoloO]
statLists["Solo Under"] = [atlSoloU, bosSoloU, bknSoloU, chaSoloU,chiSoloU, cleSoloU, dalSoloU, denSoloU, detSoloU, gswSoloU, houSoloU, indSoloU, lacSoloU, lalSoloU, memSoloU, miaSoloU, milSoloU, minSoloU, nopSoloU, nykSoloU, okcSoloU, orlSoloU, phiSoloU, phxSoloU, porSoloU, sacSoloU, sasSoloU, torSoloU, utaSoloU, wasSoloU]
statLists["Halftime ATS"] = [atlHalftime, bosHalftime, bknHalftime, chaHalftime,chiHalftime, cleHalftime, dalHalftime, denHalftime, detHalftime, gswHalftime, houHalftime, indHalftime, lacHalftime, lalHalftime, memHalftime, miaHalftime, milHalftime, minHalftime, nopHalftime, nykHalftime, okcHalftime, orlHalftime, phiHalftime, phxHalftime, porHalftime, sacHalftime, sasHalftime, torHalftime, utaHalftime, wasHalftime]
statLists["Halftime Over"] = [atlHalftimeO, bosHalftimeO, bknHalftimeO, chaHalftimeO,chiHalftimeO, cleHalftimeO, dalHalftimeO, denHalftimeO, detHalftimeO, gswHalftimeO, houHalftimeO, indHalftimeO, lacHalftimeO, lalHalftimeO, memHalftimeO, miaHalftimeO, milHalftimeO, minHalftimeO, nopHalftimeO, nykHalftimeO, okcHalftimeO, orlHalftimeO, phiHalftimeO, phxHalftimeO, porHalftimeO, sacHalftimeO, sasHalftimeO, torHalftimeO, utaHalftimeO, wasHalftimeO]
statLists["Halftime Under"] = [atlHalftimeU, bosHalftimeU, bknHalftimeU, chaHalftimeU,chiHalftimeU, cleHalftimeU, dalHalftimeU, denHalftimeU, detHalftimeU, gswHalftimeU, houHalftimeU, indHalftimeU, lacHalftimeU, lalHalftimeU, memHalftimeU, miaHalftimeU, milHalftimeU, minHalftimeU, nopHalftimeU, nykHalftimeU, okcHalftimeU, orlHalftimeU, phiHalftimeU, phxHalftimeU, porHalftimeU, sacHalftimeU, sasHalftimeU, torHalftimeU, utaHalftimeU, wasHalftimeU]
statLists["1Q ATS"] = [atl1Q, bos1Q, bkn1Q, cha1Q,chi1Q, cle1Q, dal1Q, den1Q, det1Q, gsw1Q, hou1Q, ind1Q, lac1Q, lal1Q, mem1Q, mia1Q, mil1Q, min1Q, nop1Q, nyk1Q, okc1Q, orl1Q, phi1Q, phx1Q, por1Q, sac1Q, sas1Q, tor1Q, uta1Q, was1Q]
statLists["1Q Over"] = [atl1QO, bos1QO, bkn1QO, cha1QO,chi1QO, cle1QO, dal1QO, den1QO, det1QO, gsw1QO, hou1QO, ind1QO, lac1QO, lal1QO, mem1QO, mia1QO, mil1QO, min1QO, nop1QO, nyk1QO, okc1QO, orl1QO, phi1QO, phx1QO, por1QO, sac1QO, sas1QO, tor1QO, uta1QO, was1QO]
statLists["1Q Under"] = [atl1QUnder, bos1QUnder, bkn1QUnder, cha1QUnder,chi1QUnder, cle1QUnder, dal1QUnder, den1QUnder, det1QUnder, gsw1QUnder, hou1QUnder, ind1QUnder, lac1QUnder, lal1QUnder, mem1QUnder, mia1QUnder, mil1QUnder, min1QUnder, nop1QUnder, nyk1QUnder, okc1QUnder, orl1QUnder, phi1QUnder, phx1QUnder, por1QUnder, sac1QUnder, sas1QUnder, tor1QUnder, uta1QUnder, was1QUnder]
statLists["2Q ATS"] = [atl2Q, bos2Q, bkn2Q, cha2Q,chi2Q, cle2Q, dal2Q, den2Q, det2Q, gsw2Q, hou2Q, ind2Q, lac2Q, lal2Q, mem2Q, mia2Q, mil2Q, min2Q, nop2Q, nyk2Q, okc2Q, orl2Q, phi2Q, phx2Q, por2Q, sac2Q, sas2Q, tor2Q, uta2Q, was2Q]
statLists["2Q Over"] = [atl2QO, bos2QO, bkn2QO, cha2QO,chi2QO, cle2QO, dal2QO, den2QO, det2QO, gsw2QO, hou2QO, ind2QO, lac2QO, lal2QO, mem2QO, mia2QO, mil2QO, min2QO, nop2QO, nyk2QO, okc2QO, orl2QO, phi2QO, phx2QO, por2QO, sac2QO, sas2QO, tor2QO, uta2QO, was2QO]
statLists["2Q Under"] = [atl2QUnder, bos2QUnder, bkn2QUnder, cha2QUnder,chi2QUnder, cle2QUnder, dal2QUnder, den2QUnder, det2QUnder, gsw2QUnder, hou2QUnder, ind2QUnder, lac2QUnder, lal2QUnder, mem2QUnder, mia2QUnder, mil2QUnder, min2QUnder, nop2QUnder, nyk2QUnder, okc2QUnder, orl2QUnder, phi2QUnder, phx2QUnder, por2QUnder, sac2QUnder, sas2QUnder, tor2QUnder, uta2QUnder, was2QUnder]
statLists["3Q ATS"] = [atl3Q, bos3Q, bkn3Q, cha3Q,chi3Q, cle3Q, dal3Q, den3Q, det3Q, gsw3Q, hou3Q, ind3Q, lac3Q, lal3Q, mem3Q, mia3Q, mil3Q, min3Q, nop3Q, nyk3Q, okc3Q, orl3Q, phi3Q, phx3Q, por3Q, sac3Q, sas3Q, tor3Q, uta3Q, was3Q]
statLists["3Q Over"] = [atl3QO, bos3QO, bkn3QO, cha3QO,chi3QO, cle3QO, dal3QO, den3QO, det3QO, gsw3QO, hou3QO, ind3QO, lac3QO, lal3QO, mem3QO, mia3QO, mil3QO, min3QO, nop3QO, nyk3QO, okc3QO, orl3QO, phi3QO, phx3QO, por3QO, sac3QO, sas3QO, tor3QO, uta3QO, was3QO]
statLists["3Q Under"] = [atl3QUnder, bos3QUnder, bkn3QUnder, cha3QUnder,chi3QUnder, cle3QUnder, dal3QUnder, den3QUnder, det3QUnder, gsw3QUnder, hou3QUnder, ind3QUnder, lac3QUnder, lal3QUnder, mem3QUnder, mia3QUnder, mil3QUnder, min3QUnder, nop3QUnder, nyk3QUnder, okc3QUnder, orl3QUnder, phi3QUnder, phx3QUnder, por3QUnder, sac3QUnder, sas3QUnder, tor3QUnder, uta3QUnder, was3QUnder]
statLists["4Q ATS"] = [atl4Q, bos4Q, bkn4Q, cha4Q,chi4Q, cle4Q, dal4Q, den4Q, det4Q, gsw4Q, hou4Q, ind4Q, lac4Q, lal4Q, mem4Q, mia4Q, mil4Q, min4Q, nop4Q, nyk4Q, okc4Q, orl4Q, phi4Q, phx4Q, por4Q, sac4Q, sas4Q, tor4Q, uta4Q, was4Q]
statLists["4Q Over"] = [atl4QO, bos4QO, bkn4QO, cha4QO,chi4QO, cle4QO, dal4QO, den4QO, det4QO, gsw4QO, hou4QO, ind4QO, lac4QO, lal4QO, mem4QO, mia4QO, mil4QO, min4QO, nop4QO, nyk4QO, okc4QO, orl4QO, phi4QO, phx4QO, por4QO, sac4QO, sas4QO, tor4QO, uta4QO, was4QO]
statLists["4Q Under"] = [atl4QUnder, bos4QUnder, bkn4QUnder, cha4QUnder,chi4QUnder, cle4QUnder, dal4QUnder, den4QUnder, det4QUnder, gsw4QUnder, hou4QUnder, ind4QUnder, lac4QUnder, lal4QUnder, mem4QUnder, mia4QUnder, mil4QUnder, min4QUnder, nop4QUnder, nyk4QUnder, okc4QUnder, orl4QUnder, phi4QUnder, phx4QUnder, por4QUnder, sac4QUnder, sas4QUnder, tor4QUnder, uta4QUnder, was4QUnder]


  // Stat index clicked by user is logged
  var statIndex = selectObj.selectedIndex;

  // Value of stat index is logged
  var statValue = selectObj.options[statIndex].value;

  // Actual number is retrieved from statList
  stat = statLists[statValue]

  // Remove extra characters extracted from back-end
  finalstat = stat[index - 1]

  finalstat = String(finalstat).replace(/[',()]/g, "");



  // HTML Element that has stat % passed through to front-end user


if (finalstat.includes("%")) {

  document.getElementById("stat").innerHTML = "This happens " + finalstat + " of the time";
  document.getElementById("stat").style.opacity = "1";

} else {

  document.getElementById("stat").innerHTML = "This happens " + finalstat + "% of the time";
  document.getElementById("stat").style.opacity = "1";
}
}
$(document).ready(function() {
    $('.Dropdown').select2({
      width: 'resolve',
});
});
